# DARK KOMBAT

Jogo de luta 3D futurista para Android. Kotlin (app nativa + Bluetooth Classic) · JavaScript + Three.js (jogo) · WebView · Gradle.
Funciona 100 % offline. Modo a solo contra IA (3 dificuldades) e multijogador Bluetooth entre dois telemóveis.

## Compilar no GitHub (sem instalar nada)
1. Cria um repositório no GitHub e envia **todo o conteúdo desta pasta** (não o ZIP em si): `git add . && git commit -m "Dark Kombat" && git push`
   (ou no site: *Add file → Upload files* e arrasta o conteúdo extraído; confirma que a pasta `.github` foi incluída).
2. Abre o separador **Actions → Build Dark Kombat APK**. Corre sozinho a cada push (ou carrega em *Run workflow*).
3. Quando terminar (verde), abre a execução e descarrega o artefacto **DarkKombat-debug-apk** → dentro está `app-debug.apk`.
4. Copia o APK para o telemóvel e instala (permitir "instalar de fontes desconhecidas").

O workflow corre primeiro os testes automáticos (Node) e só depois compila o APK. O Gradle descarrega o `three.min.js` (r149) uma vez durante a compilação e fica dentro do APK; em execução o jogo não usa Internet.

## Compilar localmente
Android Studio (Hedgehog+) → *Open* nesta pasta → *Run*. Ou, com Gradle 8.5 e JDK 17: `gradle :app:assembleDebug`.
Teste da lógica: `node tests/run.js`.

## Documentação
`docs/MANUAL_INSTALACAO.md` · `docs/MANUAL_UTILIZACAO.md` · `docs/MANUAL_TESTES_BLUETOOTH.md` · `docs/PROTOCOLO.md` · `docs/MODELOS.md` · `docs/ESTADO_E_LIMITACOES.md` · `docs/LICENCAS.md`

## Estrutura
```
app/src/main/java/com/darkkombat/   Kotlin: MainActivity, BluetoothManager(BtManager), BluetoothDiscovery,
                                    BluetoothConnection, GameBridge, PermissionManager, GameSettings
app/src/main/assets/game/           index.html, css/, js/ (sim, ai, models, model, scene, app, net, protocol...), audio/, models/ (GLB)
tools/gen_audio.py                  gera os sons e músicas
tools/build_glb.py                  reduz e articula os GLB (originais em tools/source_models/)
tests/                              testes automáticos
.github/workflows/build.yml         CI: testes + APK
```

## Alterações (abertura, realismo)
- **Ecrã "Toque para iniciar"**: os dois lutadores vêm a caminhar de frente para o ecrã (passada natural, braços a balançar), param, fazem a vénia de karaté (rei) e acenam. Estados `stroll` e `greet` em `js/model.js`; sequência em `introStep` (`js/app.js`); câmara frontal `intro` em `js/scene.js`.
- **Aspeto**: tone mapping ACES, luz principal quente + contraluz azul, vinheta suave. Tudo sem custo extra relevante de GPU.

## Alterações (novos lutadores: LIAM e SARAY)
- **LIAM** (karatê clássico, mais forte e resistente) e **SARAY** (boxe ágil, mais rápida) vêm dos modelos 3D enviados (`tools/source_models/LIAM_scan.glb`, `SARAY_scan.glb`, ~180 mil triângulos, sem esqueleto).
- `python3 tools/build_scanned_glb.py [liam|saray]`: reconstrói uma superfície limpa (voxels + marching cubes), reduz para **2 500 triângulos**, cria o esqueleto de 22 ossos com pesos, e **coze uma textura nova** (a original estava partida em milhares de ilhas e não aguentava a redução). GLB de ~0,6 MB cada.
- No menu há agora 4 cartões; em partida solo o adversário é sorteado. Rede/Bluetooth aceitam os 4 lutadores.
- Ajustes de articulações (tabela `CONFIG` do script) foram medidos nas vistas do modelo e verificados por cinemática, não em WebGL.

## Alterações (22 ossos, 3 chutes de karaté, cidade com vida)
- **Novo osso `spine` (lombar)**: esqueleto de **22 ossos** (pelvis → spine → torso → chest). A flexão do tronco reparte-se por lombar/dorsal/peito, e há inclinação lateral (`ln`) para equilibrar os chutes. Coxas com **abdução da anca** (`rAb`/`lAb`).
- **3 chutes**: parado = **mae-geri** (frontal); a avançar = **mawashi-geri** (circular, joelho abre para o lado e a anca roda); em combo ou a recuar = **meia-volta** (ushiro-mawashi, 360°). Novo estado `kickM` (no fim da lista de estados, compatível com a rede).
- **Cidade**: montras com toldo e néon nas avenidas, cabos aéreos, semáforos, bancos na praça, hidrantes e chaminés de vapor.
- Nota: não foi possível renderizar em WebGL neste ambiente; as poses foram verificadas por cinemática nos testes (`node tests/run.js`).

## Alterações (leveza, polígonos, movimento humano, controlos)
- **Polígonos**: lutadores reduzidos de 5 226 / 6 638 para **2 436 / 2 824 triângulos** (`tools/decimate.py`, colapso de arestas QEM que preserva as costuras de UV e o esqueleto de 21 ossos; `python3 tools/build_textured_glb.py`). Material de pele/tecido sem brilho metálico + contraluz azul barato.
- **Leveza**: níveis de qualidade refeitos (`Q` em `js/scene.js`): resolução de render mais baixa (BAIXO 0,8×, MÉDIO ≤1,15×, ALTO ≤1,6×), sem anti-aliasing do WebGL, sem luzes de ponto/ambiente/chuva fora do nível ALTO, chão da cidade em Lambert e textura 1024, carros voadores, painéis, halos e poças só no ALTO, edifícios a 35 % / 60 % / 100 %. Arranca leve e sobe sozinho se o FPS sobrar.
- **Movimento humano**: cadeia cinética nos golpes (soco: anca → tronco → braço; chute: tronco/anca → perna), curvas de aceleração/travagem, respiração e balanço de peso em guarda (`lerpStag` em `js/model.js`).
- **Controlos**: soco grande no canto, chute ao lado, especial e defesa em arco por cima, esquiva pequena; joystick mais alto; pausa passou para o topo (centro). O botão duplicado de soco foi removido.

## Alterações (ritmo rápido, karaté, cidade, câmara e som)
- **Ritmo tipo Free Fire**: golpes, recuperações, esquiva, levantar e contagem decorrem ~40 % mais depressa; andar a 5,2 m/s com corrida de combate (`js/sim.js`, `js/model.js`).
- **Pontapés de karateca**: `kickF` = *mawashi-geri* (joelho sobe e abre, anca roda, tronco inclina-se para trás, avanço do corpo); `kickH` = *ushiro-mawashi-geri* com **meia-volta de 360°** (acontece em combo, ou carregando em chute enquanto se recua). Alturas verificadas nos GLB (pé ao nível do tronco / da cabeça).
- **Efeitos**: golpes normais têm um impacto pequeno (0,1 s, com teste de profundidade, à frente do corpo) e poucas faíscas; o clarão grande com raios só aparece no **especial**.
- **Câmara**: arrastar o dedo no ecrã gira/inclina a câmara à volta dos lutadores; volta sozinha ao fim de 4 s (`initOrbit` em `js/scene.js`).
- **Cidade**: sem plateia. Nova cidade cyberpunk low-poly em `js/city.js`: praça no cruzamento de duas avenidas, quarteirões com edifícios escalonados, passeios e passadeiras, candeeiros, carros estacionados, letreiros néon, painéis holográficos, carros voadores, luzes de aviso e céu com luas. Tudo em ~15 chamadas de desenho; a qualidade BAIXA corta edifícios e efeitos.
- **Som**: `python3 tools/gen_audio.py` (numpy + scipy) gera efeitos em camadas (grave + estalo + ruído + reverberação), novo som de meia-volta (`spin`) e duas músicas synthwave estéreo (bateria, baixo com sidechain, pads, arpejo com eco, melodia).
- Testes novos: `tests/smoke_city.js`. **Não foi possível ver o jogo em WebGL neste ambiente** (sem three.js/rede): valida no telemóvel e ajusta `fog`, `Q` em `scene.js` e as poses em `js/model.js` se necessário.

## Alterações recentes (visual e controlos)
- Ecrã "Toque para iniciar" mostra os mesmos lutadores 3D (GLB) da arena; os retratos (cartões e HUD) são renderizados a partir desses modelos.
- Animação das articulações com molas amortecidas, limites anatómicos (cotovelos/joelhos), cabeça a compensar a torção do tronco, cotovelos ligeiramente afastados na guarda, balanço de braços e inclinação ao andar.
- Efeitos de golpe: partículas redondas e suaves + clarão em estrela no ponto de impacto (acabaram os quadrados).
- Controlos: joystick menor (só esquerda/direita) e quatro botões redondos separados, com ícones (soco, chute, especial, defesa).
- Ícone da app: adaptativo (Android 8+, com versão monocromática para ícones temáticos) + PNG para versões antigas; `app/icon-512.png` serve para a Play Store. Gerado por `python3 tools/build_icon.py`.

## Alterações (esqueleto, controlos e efeito do golpe)
- **Esqueleto de 21 ossos** (antes 11): além de pelvis, torso, cabeça, ombros, cotovelos, coxas e joelhos, há agora `chest` (coluna em 2 partes), `neck`, `clavicle_R/L`, `hand_R/L` (pulsos), `foot_R/L` (tornozelos) e `toe_R/L` (dedos dos pés). Gerados por `python3 tools/build_textured_glb.py`; pesos de skinning recalculados.
- Movimento secundário por molas amortecidas (`js/model.js`): peito, pescoço e cabeça atrasam-se em relação ao tronco, ombros sobem/avançam nos golpes (com contra-giro para manter o alcance), pulsos arrastam-se atrás do antebraço, pés ficam planos no chão e acompanham a perna no ar, anca e peito contra-rodam ao andar, peito respira em guarda.
- **Controlos** na disposição da captura de referência (joystick com 4 setas em baixo à esquerda; SP, soco, chute, soco grande, defesa e esquiva à direita; pausa ao centro em baixo). Posições e tamanhos em `vh`, ancorados aos cantos. Joystick: baixo = defesa, cima = esquiva. Botão fraco = esquiva (defesa + sentido para trás).
- **Efeito do golpe**: clarão azul-branco com núcleo branco, halo azul e raios finos (`emitBlast` em `js/scene.js`); mais forte em pontapés e no especial; pequeno e ciano quando o golpe é defendido.
