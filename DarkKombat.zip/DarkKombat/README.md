# DARK KOMBAT

Jogo de luta 3D futurista para Android. Kotlin (app nativa + Bluetooth Classic) · JavaScript + Three.js (jogo) · WebView · Gradle.
Funciona 100 % offline. Modo a solo contra IA (3 dificuldades) e multijogador Bluetooth entre dois telemóveis.

## Compilar no GitHub (sem instalar nada)
1. Cria um repositório no GitHub e envia **todo o conteúdo desta pasta** (não o ZIP em si): `git add . && git commit -m "Dark Kombat" && git push`
   (ou no site: *Add file → Upload files* e arrasta o conteúdo extraído; confirma que a pasta `.github` foi incluída).
2. Abre o separador **Actions → Build Dark Kombat APK**. Corre sozinho a cada push (ou carrega em *Run workflow*).
3. Quando terminar (verde), abre a execução e descarrega o artefacto **DarkKombat-debug-apk** → dentro está `app-debug.apk`.
4. Copia o APK para o telemóvel e instala (permitir "instalar de fontes desconhecidas").

O workflow corre primeiro os testes automáticos (Node) e só depois compila o APK. O Gradle descarrega o `three.min.js` (r149) uma vez durante a compilação e fica dentro do APK; em execução o jogo não usa Internet.

## Compilar localmente
Android Studio (Hedgehog+) → *Open* nesta pasta → *Run*. Ou, com Gradle 8.5 e JDK 17: `gradle :app:assembleDebug`.
Teste da lógica: `node tests/run.js`.

## Documentação
`docs/MANUAL_INSTALACAO.md` · `docs/MANUAL_UTILIZACAO.md` · `docs/MANUAL_TESTES_BLUETOOTH.md` · `docs/PROTOCOLO.md` · `docs/MODELOS.md` · `docs/ESTADO_E_LIMITACOES.md` · `docs/LICENCAS.md`

## Estrutura
```
app/src/main/java/com/darkkombat/   Kotlin: MainActivity, BluetoothManager(BtManager), BluetoothDiscovery,
                                    BluetoothConnection, GameBridge, PermissionManager, GameSettings
app/src/main/assets/game/           index.html, css/, js/ (sim, ai, models, model, scene, app, net, protocol...), audio/, models/ (GLB)
tools/gen_audio.py                  gera os sons e músicas
tools/build_glb.py                  reduz e articula os GLB (originais em tools/source_models/)
tests/                              testes automáticos
.github/workflows/build.yml         CI: testes + APK
```
