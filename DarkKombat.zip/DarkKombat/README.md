# DARK KOMBAT

Jogo de luta 3D futurista para Android. Kotlin (app nativa + Bluetooth Classic) · JavaScript + Three.js (jogo) · WebView · Gradle.
Funciona 100 % offline. Modo a solo contra IA (3 dificuldades) e multijogador Bluetooth entre dois telemóveis.

## Compilar no GitHub (sem instalar nada)
1. Cria um repositório no GitHub e envia **todo o conteúdo desta pasta** (não o ZIP em si): `git add . && git commit -m "Dark Kombat" && git push`
   (ou no site: *Add file → Upload files* e arrasta o conteúdo extraído; confirma que a pasta `.github` foi incluída).
2. Abre o separador **Actions → Build Dark Kombat APK**. Corre sozinho a cada push (ou carrega em *Run workflow*).
3. Quando terminar (verde), abre a execução e descarrega o artefacto **DarkKombat-debug-apk** → dentro está `app-debug.apk`.
4. Copia o APK para o telemóvel e instala (permitir "instalar de fontes desconhecidas").

O workflow corre primeiro os testes automáticos (Node) e só depois compila o APK. O Gradle descarrega o `three.min.js` (r149) uma vez durante a compilação e fica dentro do APK; em execução o jogo não usa Internet.

## Compilar localmente
Android Studio (Hedgehog+) → *Open* nesta pasta → *Run*. Ou, com Gradle 8.5 e JDK 17: `gradle :app:assembleDebug`.
Teste da lógica: `node tests/run.js`.

## Documentação
`docs/MANUAL_INSTALACAO.md` · `docs/MANUAL_UTILIZACAO.md` · `docs/MANUAL_TESTES_BLUETOOTH.md` · `docs/PROTOCOLO.md` · `docs/MODELOS.md` · `docs/ESTADO_E_LIMITACOES.md` · `docs/LICENCAS.md`

## Estrutura
```
app/src/main/java/com/darkkombat/   Kotlin: MainActivity, BluetoothManager(BtManager), BluetoothDiscovery,
                                    BluetoothConnection, GameBridge, PermissionManager, GameSettings
app/src/main/assets/game/           index.html, css/, js/ (sim, ai, models, model, scene, app, net, protocol...), audio/, models/ (GLB)
tools/gen_audio.py                  gera os sons e músicas
tools/build_glb.py                  reduz e articula os GLB (originais em tools/source_models/)
tests/                              testes automáticos
.github/workflows/build.yml         CI: testes + APK
```

## Alterações recentes (visual e controlos)
- Ecrã "Toque para iniciar" mostra os mesmos lutadores 3D (GLB) da arena; os retratos (cartões e HUD) são renderizados a partir desses modelos.
- Animação das articulações com molas amortecidas, limites anatómicos (cotovelos/joelhos), cabeça a compensar a torção do tronco, cotovelos ligeiramente afastados na guarda, balanço de braços e inclinação ao andar.
- Efeitos de golpe: partículas redondas e suaves + clarão em estrela no ponto de impacto (acabaram os quadrados).
- Controlos: joystick menor (só esquerda/direita) e quatro botões redondos separados, com ícones (soco, chute, especial, defesa).
- Ícone da app: adaptativo (Android 8+, com versão monocromática para ícones temáticos) + PNG para versões antigas; `app/icon-512.png` serve para a Play Store. Gerado por `python3 tools/build_icon.py`.

## Alterações (esqueleto, controlos e efeito do golpe)
- **Esqueleto de 21 ossos** (antes 11): além de pelvis, torso, cabeça, ombros, cotovelos, coxas e joelhos, há agora `chest` (coluna em 2 partes), `neck`, `clavicle_R/L`, `hand_R/L` (pulsos), `foot_R/L` (tornozelos) e `toe_R/L` (dedos dos pés). Gerados por `python3 tools/build_textured_glb.py`; pesos de skinning recalculados.
- Movimento secundário por molas amortecidas (`js/model.js`): peito, pescoço e cabeça atrasam-se em relação ao tronco, ombros sobem/avançam nos golpes (com contra-giro para manter o alcance), pulsos arrastam-se atrás do antebraço, pés ficam planos no chão e acompanham a perna no ar, anca e peito contra-rodam ao andar, peito respira em guarda.
- **Controlos** na disposição da captura de referência (joystick com 4 setas em baixo à esquerda; SP, soco, chute, soco grande, defesa e esquiva à direita; pausa ao centro em baixo). Posições e tamanhos em `vh`, ancorados aos cantos. Joystick: baixo = defesa, cima = esquiva. Botão fraco = esquiva (defesa + sentido para trás).
- **Efeito do golpe**: clarão azul-branco com núcleo branco, halo azul e raios finos (`emitBlast` em `js/scene.js`); mais forte em pontapés e no especial; pequeno e ciano quando o golpe é defendido.
