/* Teste de fumo da aplicação completa com DOM e THREE falsos: arranca, abre menus, joga uma partida a solo,
   pausa, abre definições e volta ao menu, à procura de erros de código (não valida gráficos reais). */
const path = require('path');
const base = path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'game', 'js');
const any = () => new Proxy(function () {}, {
  get: (t, p) => (p === Symbol.toPrimitive ? () => 0 : p === 'then' ? undefined : (p in t ? t[p] : (t[p] = any()))),
  apply: () => any(), construct: () => any(), set: (t, p, v) => { t[p] = v; return true }
});
class El {
  constructor(id) {
    this.id = id; this.cls = new Set(); this.style = {}; this.dataset = {}; this.children = []; this.l = {}; this.hidden = true; this.value = ''; this.textContent = ''; this.innerHTML = '';
    const self = this; this.classList = { add: (c) => self.cls.add(c), remove: (c) => self.cls.delete(c), toggle: (c, f) => { if (f === undefined ? !self.cls.has(c) : f) self.cls.add(c); else self.cls.delete(c); }, contains: (c) => self.cls.has(c) };
    this.offsetWidth = 1; this.firstChild = null; this.lastChild = null;
  }
  set className(v) { this.cls = new Set(String(v).split(' ').filter(Boolean)); } get className() { return [...this.cls].join(' '); }
  addEventListener(t, f) { (this.l[t] = this.l[t] || []).push(f); }
  fire(t, ev) { (this.l[t] || []).forEach((f) => f(Object.assign({ preventDefault() {}, target: this, pointerId: 1, clientX: 0, clientY: 0 }, ev))); }
  appendChild(c) { this.children.push(c); this.firstChild = this.firstChild || c; this.lastChild = c; return c; }
  insertBefore(c) { this.children.unshift(c); return c; }
  querySelector() { return new El('q'); } querySelectorAll() { return []; }
  getBoundingClientRect() { return { left: 0, top: 0, width: 200, height: 200 }; } setPointerCapture() {} getContext() { return any(); }
  get disabled() { return !!this._d; } set disabled(v) { this._d = v; }
}
const store = {}; const rafs = [];
const els = new Proxy(store, { get: (o, id) => (o[id] = o[id] || new El(id)) });
globalThis.window = globalThis;
globalThis.document = {
  readyState: 'complete', body: new El('body'), documentElement: { style: { setProperty() {} } },
  getElementById: (id) => els[id], createElement: (t) => new El(t),
  querySelectorAll: () => [], addEventListener() {}
};
globalThis.navigator = { hardwareConcurrency: 8, deviceMemory: 4, vibrate() {} };
globalThis.innerWidth = 1280; globalThis.innerHeight = 600; globalThis.devicePixelRatio = 2;
globalThis.addEventListener = () => {}; globalThis.requestAnimationFrame = (f) => { rafs.push(f); };
globalThis.localStorage = { _: {}, getItem(k) { return this._[k] || null; }, setItem(k, v) { this._[k] = v; } };
globalThis.THREE = any();
const sent = []; let hosted = 0, scanned = 0, connectedTo = null;
globalThis.AndroidBridge = { btHost() { hosted++; }, btScan() { scanned++; }, btStopScan() {}, btConnect(a) { connectedTo = a; }, btSend(s) { sent.push(s); return true; }, btDisconnect() {}, getSettings() { return ''; }, saveSettings() { return true; }, vibrate() {}, exitApp() {} };
const errors = []; const ce = console.error; console.error = (...a) => { errors.push(a.join(' ')); ce(...a); };
for (const f of ['settings', 'audio', 'protocol', 'sim', 'ai', 'model', 'city', 'scene', 'input', 'net', 'app']) require(path.join(base, f + '.js'));
const DK = globalThis.DK; let t = 0;
const frames = (n, hook) => { for (let i = 0; i < n; i++) { const cb = rafs.splice(0); t += 16.7; cb.forEach((f) => f(t)); if (hook) hook(i); } };
const click = (id) => els[id].fire('click', {});
(async () => {
  const P = DK.Proto, native = (o) => globalThis.NativeBT.on(o), msg = (type, f, q) => native({ e: 'msg', d: P.build(type, f, q) });
  frames(3); els.splash.fire('pointerdown', {}); await new Promise((r) => setTimeout(r, 50)); frames(5);
  // ---- anfitrião ----
  click('mBt'); frames(2); click('btCreate'); if (!hosted) throw new Error('btHost não chamado');
  native({ e: 'state', s: 'hosting', role: 'host', name: 'Telemovel A', msg: 'à espera' }); frames(2);
  native({ e: 'state', s: 'connected', role: 'host', name: 'Telemovel B', addr: 'AA:BB:CC:DD:EE:FF' }); frames(2);
  if (!sent.some((x) => JSON.parse(x).t === 'HELLO')) throw new Error('HELLO não enviado');
  if (!els.lbGo.disabled) throw new Error('INICIAR devia estar desactivado até o cliente estar pronto');
  msg('READY', { f: 'ren', r: 1 }, 1); frames(1);
  if (els.lbGo.disabled) throw new Error('INICIAR devia ficar activo');
  click('lbGo'); frames(2);
  if (!els.hud.cls.has('show')) throw new Error('partida de anfitrião não iniciou');
  if (!sent.some((x) => JSON.parse(x).t === 'START')) throw new Error('START não enviado');
  sent.length = 0; let q = 2;
  frames(60 * 8, (i) => { if (i % 10 === 0) msg('INPUT', { mx: i % 120 < 60 ? -1 : 0, a: i % 30 === 0 ? 1 : 0, b: 0 }, q++); });
  const states = sent.map((x) => P.validate(x)).filter(Boolean);
  if (states.filter((m) => m.t === 'STATE').length < 20) throw new Error('poucos STATE enviados');
  if (sent.some((x) => !P.validate(x))) throw new Error('mensagem enviada inválida');
  // mensagens inválidas não podem rebentar nada
  native({ e: 'msg', d: '{"t":"INPUT","q":99,"mx":9}' }); native({ e: 'msg', d: 'lixo' }); native({ e: 'nada' }); native(null); frames(2);
  // desconexão
  native({ e: 'state', s: 'closed', role: 'host', msg: 'Ligação perdida' }); frames(2);
  if (!els.disc.cls.has('show')) throw new Error('ecrã de ligação perdida não apareceu');
  click('discMenu'); frames(2); if (!els.menu.cls.has('show')) throw new Error('não voltou ao menu');
  // ---- cliente ----
  click('mBt'); click('btSearch'); if (!scanned) throw new Error('btScan não chamado');
  native({ e: 'state', s: 'scanning', role: 'client' }); native({ e: 'device', name: 'Host', addr: 'AA:BB:CC:DD:EE:01', bonded: false }); frames(1);
  native({ e: 'state', s: 'connected', role: 'client', name: 'Host', addr: 'AA:BB:CC:DD:EE:01' }); frames(1);
  click('lbGo'); // PRONTO
  const ready = sent.map((x) => JSON.parse(x)).filter((m) => m.t === 'READY').pop(); if (!ready || ready.r !== 1) throw new Error('READY r=1 não enviado');
  msg('START', { hf: 'kira', cf: 'ren' }, 1); frames(2);
  if (!els.hud.cls.has('show')) throw new Error('partida de cliente não iniciou');
  const m = new DK.Sim.Match(DK.Sim.FIGHTERS.kira, DK.Sim.FIGHTERS.ren); sent.length = 0;
  frames(60 * 6, (i) => { m.step(1 / 60, { mx: 1, p: i % 40 === 0 ? 1 : 0, k: 0, s: 0, b: 0 }, { mx: 0, p: 0, k: 0, s: 0, b: 0 }); if (i % 3 === 0) msg('STATE', m.snapshot(), 100 + i); });
  if (!sent.some((x) => JSON.parse(x).t === 'INPUT')) throw new Error('cliente não enviou INPUT');
  native({ e: 'state', s: 'closed', role: 'client', msg: 'perdida' }); frames(2);
  if (!els.disc.cls.has('show')) throw new Error('cliente: ecrã de desconexão em falta');
  if (errors.length) throw new Error('erros de execução: ' + errors[0]);
  console.log('smoke_bt OK — fluxo anfitrião/cliente, lobby, START, INPUT/STATE, mensagens inválidas e desconexão (ponte simulada, SEM rádio Bluetooth real)');
  process.exit(0);
})().catch((e) => { console.error('FALHOU: ' + e.stack); process.exit(1); });
