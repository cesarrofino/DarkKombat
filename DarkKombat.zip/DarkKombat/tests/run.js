/* Testes automáticos da lógica (protocolo, combate, IA). Executar: node tests/run.js */
const path = require('path');
const base = path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'game', 'js');
require(path.join(base, 'protocol.js'));
require(path.join(base, 'sim.js'));
require(path.join(base, 'ai.js'));
const DK = globalThis.DK;
const F = DK.Sim.FIGHTERS;

let pass = 0, fail = 0;
function test(name, fn) {
  try { fn(); pass++; console.log('  OK   ' + name); }
  catch (e) { fail++; console.log('  FALHA ' + name + '\n        ' + e.message); }
}
function eq(a, b, m) { if (a !== b) throw new Error((m || '') + ' esperado ' + b + ' obteve ' + a); }
function ok(c, m) { if (!c) throw new Error(m || 'condição falsa'); }
const IDLE = { mx: 0, p: 0, k: 0, s: 0, b: 0 };
const DT = 1 / 60;

function fightMatch(a = 'kira', b = 'ren') {
  const m = new DK.Sim.Match(F[a], F[b]);
  let n = 0; while (m.phase !== 'fight' && n++ < 1000) m.step(DT, IDLE, IDLE);
  m.drain(); return m;
}
function run(m, secs, in0, in1) { for (let i = 0; i < secs / DT; i++) m.step(DT, typeof in0 === 'function' ? in0(i) : in0 || IDLE, typeof in1 === 'function' ? in1(i) : in1 || IDLE); }
function press(key) { const o = Object.assign({}, IDLE); o[key] = 1; return o; }

console.log('A. Protocolo');
test('mensagens válidas', () => {
  ok(DK.Proto.validate(DK.Proto.build('INPUT', { mx: 1, a: 3, b: 0 }, 5)));
  ok(DK.Proto.validate(DK.Proto.build('HELLO', { name: 'Ana', v: 1 }, 1)));
  ok(DK.Proto.validate(DK.Proto.build('PING', { ts: 123, r: 0 }, 2)));
  ok(DK.Proto.validate(DK.Proto.build('DISCONNECT', {}, 9)));
});
test('mensagens inválidas rejeitadas', () => {
  eq(DK.Proto.validate('not json'), null);
  eq(DK.Proto.validate('{"t":"INPUT","q":1,"mx":5,"a":0,"b":0}'), null, 'mx fora do intervalo');
  eq(DK.Proto.validate('{"t":"HACK","q":1}'), null, 'tipo desconhecido');
  eq(DK.Proto.validate('{"t":"INPUT","mx":0,"a":0,"b":0}'), null, 'sem q');
  eq(DK.Proto.validate('{"t":"READY","q":1,"f":"zzz","r":1}'), null, 'lutador desconhecido');
  eq(DK.Proto.validate('{"t":"STATE","q":1,"ph":1,"cd":0,"tm":50,"r":1,"w":[0,0],"f":[[0,100,0,0,0]]}'), null, 'estado incompleto');
  eq(DK.Proto.validate('x'.repeat(5000)), null, 'mensagem demasiado grande');
  eq(DK.Proto.validate('[1,2]'), null);
  eq(DK.Proto.validate('{"t":"INPUT","q":1,"mx":NaN}'), null);
});
test('STATE e HIT round-trip', () => {
  const m = fightMatch(); const s = DK.Proto.build('STATE', m.snapshot(), 7);
  const v = DK.Proto.validate(s); ok(v, 'STATE do motor deve validar'); eq(v.f[0][1], 100);
  ok(DK.Proto.validate(DK.Proto.build('HIT', { v: 1, d: 6.5, b: 0, k: 0, c: 1 }, 8)));
});

console.log('C/E. Movimentação e colisões');
test('limites da arena', () => {
  const m = fightMatch(); run(m, 8, { mx: -1, p: 0, k: 0, s: 0, b: 0 }, IDLE);
  ok(m.f[0].x >= -DK.Sim.ARENA - 1e-6, 'x=' + m.f[0].x); ok(m.f[0].x <= -DK.Sim.ARENA + 0.01, 'devia estar na parede');
});
test('lutadores não se atravessam e mantêm distância mínima', () => {
  const m = fightMatch(); run(m, 6, { mx: 1, p: 0, k: 0, s: 0, b: 0 }, { mx: -1, p: 0, k: 0, s: 0, b: 0 });
  ok(m.f[0].x < m.f[1].x, 'ordem trocada'); ok(m.f[1].x - m.f[0].x >= DK.Sim.MIN_DIST - 1e-6, 'distância ' + (m.f[1].x - m.f[0].x));
});

console.log('D/F. Ataques, vida e dano');
test('soco fora de alcance não causa dano', () => {
  const m = fightMatch(); run(m, 1, press('p'), IDLE); eq(m.f[1].hp, m.f[1].maxHp);
});
test('soco ao alcance causa dano e reacção', () => {
  const m = fightMatch(); run(m, 1.2, { mx: 1, p: 0, k: 0, s: 0, b: 0 }, IDLE);
  const hp = m.f[1].hp; run(m, 0.01, press('p'), IDLE); run(m, 0.5, IDLE, IDLE);
  ok(m.f[1].hp < hp, 'sem dano'); ok(m.drain().some((e) => e.t === 'hit' && e.who === 1));
});
test('cada ataque só acerta uma vez', () => {
  const m = fightMatch(); run(m, 1.2, { mx: 1, p: 0, k: 0, s: 0, b: 0 }, IDLE);
  run(m, 0.01, press('k'), IDLE); run(m, 1, IDLE, IDLE);
  eq(m.drain().filter((e) => e.t === 'hit').length, 1);
});
test('tempo de recuperação impede ataques seguidos instantâneos', () => {
  const m = fightMatch(); run(m, 1.2, { mx: 1, p: 0, k: 0, s: 0, b: 0 }, IDLE);
  m.f[0].x = -0.6; m.f[1].x = 0.6; // perto
  // carregar muitas vezes no chute seguidas: falha de ataque não cancela (só acertar permite cancelar)
  m.f[1].state = 'dodge'; m.f[1].st = 0; // adversário invulnerável → whiff
  const sw = []; for (let i = 0; i < 30; i++) { m.step(DT, press('k'), IDLE); }
  const swings = m.drain().filter((e) => e.t === 'swing' && e.who === 0).length;
  ok(swings <= 2, 'demasiados golpes em 0.5s: ' + swings);
});

console.log('G. Defesa');
test('defesa reduz o dano', () => {
  const a = fightMatch(), b = fightMatch();
  for (const m of [a, b]) { m.f[0].x = -0.5; m.f[1].x = 0.5; }
  run(a, 0.8, press('k'), IDLE);
  run(b, 0.8, press('k'), { mx: 0, p: 0, k: 0, s: 0, b: 1 });
  const da = a.f[1].maxHp - a.f[1].hp, db = b.f[1].maxHp - b.f[1].hp;
  ok(da > 0 && db >= 0 && db < da * 0.4, 'sem defesa ' + da + ' com defesa ' + db);
  ok(b.f[1].stats.blocks >= 1);
});

console.log('H. Especial e combos');
test('especial consome energia e sem energia não dispara', () => {
  const m = fightMatch(); m.f[0].x = -0.6; m.f[1].x = 0.6;
  run(m, 0.3, press('s'), IDLE); eq(m.f[0].state === 'special', false, 'sem energia não pode lançar');
  m.f[0].en = 100; run(m, 0.01, press('s'), IDLE); run(m, 0.8, IDLE, IDLE);
  eq(Math.round(m.f[0].en), Math.round(100 - DK.Sim.SPECIAL_COST + 0.8 * 2.2 + 0.0), 'energia');
  ok(m.f[1].hp < m.f[1].maxHp - 15, 'especial devia causar muito dano');
});
test('combo Soco+Soco aumenta o dano do 2.º golpe', () => {
  const m = fightMatch(); m.f[0].x = -0.4; m.f[1].x = 0.4;
  run(m, 0.01, press('p'), IDLE); run(m, 0.12, IDLE, IDLE); // 1.º soco em recuperação após acertar
  run(m, 0.01, press('p'), IDLE); run(m, 0.6, IDLE, IDLE);
  const hits = m.drain().filter((e) => e.t === 'hit');
  ok(hits.length >= 2, 'esperava 2 golpes: ' + hits.length); ok(hits[1].dmg > hits[0].dmg * 0.95 && hits[1].c === 2, 'combo x2');
  eq(hits[1].name, 'DUPLO SOCO');
});

console.log('J. Rondas, vitória e derrota');
test('KO termina a ronda e dá ponto', () => {
  const m = fightMatch(); m.f[1].hp = 1; m.f[0].x = -0.5; m.f[1].x = 0.5;
  run(m, 0.01, press('p'), IDLE); run(m, 0.5, IDLE, IDLE);
  eq(m.phase, 'roundEnd'); eq(m.wins[0], 1); ok(m.drain().some((e) => e.t === 'round' && e.win === 0 && e.ko === 1));
});
test('tempo esgotado: vence quem tem mais vida', () => {
  const m = fightMatch(); m.f[1].hp = 60; m.time = 0.05; run(m, 0.2, IDLE, IDLE);
  eq(m.phase, 'roundEnd'); eq(m.wins[0], 1); eq(m.wins[1], 0);
});
test('empate por tempo dá ponto a ambos', () => {
  const m = fightMatch(); m.time = 0.05; run(m, 0.2, IDLE, IDLE); eq(m.wins[0], 1); eq(m.wins[1], 1);
});
test('partida termina à 2.ª vitória com estatísticas', () => {
  const m = fightMatch(); let ev = [];
  for (let r = 0; r < 2; r++) {
    m.f[1].hp = 0.5; m.f[0].x = -0.5; m.f[1].x = 0.5;
    run(m, 0.01, press('p'), IDLE); run(m, 5, IDLE, IDLE); ev = ev.concat(m.drain());
    let n = 0; while (m.phase !== 'fight' && m.phase !== 'matchEnd' && n++ < 2000) { m.step(DT, IDLE, IDLE); ev = ev.concat(m.drain()); }
  }
  eq(m.phase, 'matchEnd'); eq(m.matchWinner, 0); const me = ev.find((e) => e.t === 'match'); ok(me, 'evento match'); ok(me.st[0][0] >= 2);
  ok(DK.Proto.validate(DK.Proto.build('MATCH_END', { win: me.win, dur: me.dur, st: me.st }, 3)), 'MATCH_END válido');
});

console.log('I. Inteligência artificial');
for (const lvl of ['easy', 'normal', 'hard']) {
  test('IA ' + lvl + ' joga uma partida completa sem erros e respeita regras', () => {
    const m = new DK.Sim.Match(F.kira, F.ren); let seed = 12345;
    const rng = () => { seed = (seed * 1664525 + 1013904223) % 4294967296; return seed / 4294967296; };
    const ai = new DK.AI(lvl, rng), human = new DK.AI('normal', rng);
    let steps = 0, swings = 0, hits = 0;
    while (m.phase !== 'matchEnd' && steps++ < 60 * 60 * 6) {
      const i1 = human.think(m.f[0], m.f[1], m, DT), i2 = ai.think(m.f[1], m.f[0], m, DT);
      m.step(DT, i1, i2);
      for (const f of m.f) { if (!isFinite(f.x) || !isFinite(f.hp) || f.hp < 0 || f.hp > f.maxHp + 1e-9 || f.en < 0 || f.en > 100.0001) throw new Error('valor inválido'); }
      if (m.f[1].x - m.f[0].x < DK.Sim.MIN_DIST - 1e-6 && m.phase === 'fight') throw new Error('atravessou');
      for (const e of m.drain()) { if (e.t === 'swing') swings++; if (e.t === 'hit') hits++; }
    }
    eq(m.phase, 'matchEnd', 'a partida devia terminar'); ok(swings > 5, 'IA/jogador quase não atacaram'); ok(hits > 0, 'sem golpes');
  });
}
test('IA difícil reage mais depressa do que a fácil', () => { ok(DK.AI_LEVELS.hard.react < DK.AI_LEVELS.easy.react); });

console.log('N. Sincronização (Mirror)');
test('Mirror reproduz o estado autoritativo', () => {
  const m = fightMatch(); m.f[0].x = -0.5; m.f[1].x = 0.5; run(m, 0.01, press('p'), IDLE); run(m, 0.1, IDLE, IDLE);
  const mir = new DK.Sim.Mirror(F.kira, F.ren), snap = DK.Proto.validate(DK.Proto.build('STATE', m.snapshot(), 1));
  mir.apply(snap); for (let i = 0; i < 20; i++) mir.step(DT);
  eq(mir.f[1].hp, m.f[1].hp); ok(Math.abs(mir.f[0].x - m.f[0].x) < 0.05); eq(mir.f[0].state, m.f[0].state);
});


console.log('\nCSS/HTML (regressão do ecrã preso)');
test('nenhuma classe de ecrã redefine "display" (só .screen.show)', () => {
  const fs = require('fs'), g = path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'game');
  const html = fs.readFileSync(path.join(g, 'index.html'), 'utf8'), css = fs.readFileSync(path.join(g, 'css', 'style.css'), 'utf8');
  const classes = new Set(); let m; const re = /<section[^>]*class="([^"]+)"/g;
  while ((m = re.exec(html))) m[1].split(/\s+/).forEach((c) => { if (c !== 'screen' && c !== 'show') classes.add(c); });
  const bad = []; const rr = /([^{}]+)\{([^{}]*)\}/g;
  while ((m = rr.exec(css))) {
    const sels = m[1].split(',').map((x) => x.trim()), body = m[2];
    if (!/(^|;)\s*display\s*:/.test(body)) continue;
    for (const sel of sels) { if (/\.show\b/.test(sel)) continue; const mm = sel.match(/^\.([\w-]+)(\.[\w-]+)*$/); if (mm) { sel.split('.').filter(Boolean).forEach((c) => { if (classes.has(c)) bad.push(sel); }); } }
  }
  if (bad.length) throw new Error('regras com display em classes de ecrã: ' + bad.join(' | '));
});

console.log('\nResultado (lógica): ' + pass + ' passaram, ' + fail + ' falharam');
const cp = require('child_process');
for (const f of ['smoke_model.js', 'smoke_app.js', 'smoke_bt.js']) {
  const r = cp.spawnSync(process.execPath, [path.join(__dirname, f)], { encoding: 'utf8' });
  const out = (r.stdout + r.stderr).trim().split('\n').slice(-3).join('\n');
  if (r.status === 0) { pass++; console.log('  OK   ' + out); } else { fail++; console.log('  FALHA ' + f + '\n' + out); }
}
console.log('\nTOTAL: ' + pass + ' passaram, ' + fail + ' falharam');
process.exit(fail ? 1 : 0);
