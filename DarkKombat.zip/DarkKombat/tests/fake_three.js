/* THREE falso para testes sem WebGL. Tem matemática de transformações real (posição, rotação Euler XYZ, escala,
   hierarquia), por isso permite verificar poses (para onde aponta um braço, se a perna levanta, se o corpo cai).
   Uso: const F = require('./fake_three.js'); // define globalThis.THREE e globalThis.document; F.toWorld(obj, [x,y,z]) */
class V {
  constructor() { this.x = 0; this.y = 0; this.z = 0; }
  set(x, y, z) { this.x = x; this.y = y; this.z = z; return this; }
  setScalar(s) { this.x = this.y = this.z = s; return this; }
}
class Obj {
  constructor() { this.name = ''; this.children = []; this.position = new V(); this.rotation = new V(); this.scale = new V().set(1, 1, 1); this.visible = true; this.parent = null; this.geometry = null; this.material = null; }
  add(o) { this.children.push(o); o.parent = this; return this; }
  remove(o) { this.children = this.children.filter((c) => c !== o); o.parent = null; }
  traverse(cb) { cb(this); this.children.forEach((c) => c.traverse(cb)); }
  updateMatrixWorld() {}
}
class Mesh extends Obj { constructor(g, m) { super(); this.geometry = g; this.material = m; this.isMesh = true; } }
class Bone extends Obj { constructor() { super(); this.isBone = true; } }
class Skeleton { constructor(bones) { this.bones = bones; } }
class SkinnedMesh extends Mesh { constructor(g, m) { super(g, m); this.isSkinnedMesh = true; this.skeleton = null; } bind(sk) { this.skeleton = sk; } }
class Texture { constructor(img) { this.image = img; } dispose() { Texture.disposed++; } }
Texture.disposed = 0;
class Geo { dispose() { Geo.disposed++; } }
Geo.disposed = 0;
class BufferAttribute { constructor(array, itemSize) { this.array = array; this.itemSize = itemSize; this.count = array.length / itemSize; } }
class BufferGeometry extends Geo {
  constructor() { super(); this.attributes = {}; this.index = null; }
  setAttribute(n, a) { this.attributes[n] = a; return this; }
  setIndex(a) { this.index = a; return this; }
  computeBoundingSphere() {}
}
class Mat { constructor(o) { Object.assign(this, o); } dispose() { Mat.disposed++; } }
Mat.disposed = 0;

/** aplica a transformação local de `o` (escala -> rotação XYZ -> translação) a um ponto */
function local(o, p) {
  let [x, y, z] = [p[0] * o.scale.x, p[1] * o.scale.y, p[2] * o.scale.z];
  const r = o.rotation;
  // Euler 'XYZ' do three.js: matriz = Rx · Ry · Rz  (aplica Rz primeiro)
  let c = Math.cos(r.z), s = Math.sin(r.z); [x, y] = [c * x - s * y, s * x + c * y];
  if (r.order === 'YXZ') {   // matriz = Ry · Rx · Rz (Y é a rotação mais exterior)
    c = Math.cos(r.x); s = Math.sin(r.x); [y, z] = [c * y - s * z, s * y + c * z];
    c = Math.cos(r.y); s = Math.sin(r.y); [x, z] = [c * x + s * z, -s * x + c * z];
  } else {
    c = Math.cos(r.y); s = Math.sin(r.y); [x, z] = [c * x + s * z, -s * x + c * z];
    c = Math.cos(r.x); s = Math.sin(r.x); [y, z] = [c * y - s * z, s * y + c * z];
  }
  return [x + o.position.x, y + o.position.y, z + o.position.z];
}
/** ponto do espaço local de `o` -> espaço do mundo */
function toWorld(o, p) { let q = p; for (let n = o; n; n = n.parent) q = local(n, q); return q; }

const T = {
  Group: Obj, Mesh, Bone, Skeleton, SkinnedMesh, Texture, BufferGeometry, BufferAttribute, CapsuleGeometry: Geo, BoxGeometry: Geo, SphereGeometry: Geo, CylinderGeometry: Geo, PlaneGeometry: Geo,
  MeshStandardMaterial: class extends Mat { get isMeshStandardMaterial() { return true; } }, MeshBasicMaterial: Mat,
  CanvasTexture: class { dispose() {} }, AdditiveBlending: 2
};
globalThis.THREE = T;
globalThis.document = { createElement: () => ({ width: 0, height: 0, getContext: () => ({ createRadialGradient: () => ({ addColorStop() {} }), fillRect() {} }) }) };
module.exports = { THREE: T, Geo, Mat, Texture, toWorld, local };
