/* Teste da cidade (js/city.js): disposição determinista, geometria coerente (sem NaN), cidade sem plateia,
   avenidas livres, e construção com um THREE mínimo (só as classes/métodos que existem na r149). */
const path = require('path'), fs = require('fs');
const base = path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'game', 'js');
const ok = (c, m) => { if (!c) throw new Error(m); };
globalThis.DK = {};
require(path.join(base, 'city.js'));
const City = globalThis.DK.City, C = City.C;

// 1) disposição
const a = City.layout(20241), b = City.layout(20241);
ok(JSON.stringify(a.boxes[5]) === JSON.stringify(b.boxes[5]) && a.boxes.length === b.boxes.length, 'layout devia ser determinista');
ok(a.boxes.length > 150 && a.signs.length > 30 && a.lamps.length > 30 && a.cars.length > 20, 'cidade demasiado vazia');
for (const x of a.boxes) {
  ok([x.x, x.z, x.w, x.d, x.h, x.y0].every(Number.isFinite) && x.h > 0 && x.w > 0 && x.d > 0, 'caixa inválida');
  if (x.y0 === 0 && x.dist < 100) {   // nenhum edifício na praça nem nas avenidas principais
    const dx = Math.max(0, Math.abs(x.x) - x.w / 2), dz = Math.max(0, Math.abs(x.z) - x.d / 2);
    ok(Math.hypot(dx, dz) > C.PLAZA, 'edifício dentro da praça');
    ok(dx > C.MAIN + 2 || dz > C.MAIN + 2 || (dx > C.MAIN && dz > C.MAIN), 'edifício em cima da avenida');
  }
}
for (const c of a.cars) ok(Math.hypot(c.x, c.z) > C.PLAZA + 3, 'carro dentro da praça');
for (let i = 1; i < a.boxes.length; i++) ok(a.boxes[i - 1].dist <= a.boxes[i].dist, 'caixas por ordem de distância');
ok(!fs.readFileSync(path.join(base, 'scene.js'), 'utf8').includes('buildCrowd'), 'a plateia devia ter sido removida');

// 2) geometria fundida
const A = City.newArrays(); let n = 0;
for (const box of a.boxes.slice(0, 40)) { City.pushBox(A, box, true, { w: 19.2, h: 27.2 }); n++; }
ok(A.pos.length === n * 30 * 3 && A.col.length === A.pos.length && A.uv.length === n * 30 * 2, 'tamanhos de pos/cor/uv');
ok(A.pos.every(Number.isFinite) && A.col.every(Number.isFinite) && A.uv.every(Number.isFinite), 'NaN na geometria');
// orientação das faces (anti-horário visto de fora): a normal de cada triângulo aponta para fora do centro da caixa
{
  const bx = { x: 3, z: -4, w: 2, d: 6, y0: 0, h: 5, t: [1, 1, 1], ou: 0 }, B = City.newArrays(); City.pushBox(B, bx, true, { w: 19.2, h: 27.2 });
  for (let t = 0; t < B.pos.length; t += 9) {
    const p = (i) => [B.pos[t + i * 3], B.pos[t + i * 3 + 1], B.pos[t + i * 3 + 2]];
    const [p0, p1, p2] = [p(0), p(1), p(2)], u = p1.map((v, i) => v - p0[i]), w = p2.map((v, i) => v - p0[i]);
    const nrm = [u[1] * w[2] - u[2] * w[1], u[2] * w[0] - u[0] * w[2], u[0] * w[1] - u[1] * w[0]];
    const c = [(p0[0] + p1[0] + p2[0]) / 3 - bx.x, (p0[1] + p1[1] + p2[1]) / 3 - 2.5, (p0[2] + p1[2] + p2[2]) / 3 - bx.z];
    ok(nrm[0] * c[0] + nrm[1] * c[1] + nrm[2] * c[2] > 0, 'face virada para dentro (seria invisível)');
  }
}

// 3) construção com THREE mínimo
const made = { meshes: 0, instanced: 0, points: 0, lines: 0, ranges: [] };
class Attr { constructor(a, n) { this.array = a; this.itemSize = n; this.count = a.length / n; } }
class Geo { constructor() { this.attributes = {}; } setAttribute(k, v) { this.attributes[k] = v; return this; } setDrawRange(a, b) { made.ranges.push(b); this.range = [a, b]; } }
class Obj { constructor() { this.position = { set() {}, x: 0, y: 0, z: 0 }; this.rotation = { set() {}, x: 0, y: 0, z: 0 }; this.matrix = {}; this.visible = true; this.material = { opacity: 1 }; } updateMatrix() {} lookAt() {} }
class Mesh extends Obj { constructor(g, m) { super(); this.geometry = g; this.material = m || { opacity: 1 }; made.meshes++; } }
class Inst extends Mesh { constructor(g, m, n) { super(g, m); made.instanced++; this.count = n; this.instanceMatrix = {}; } setMatrixAt() {} setColorAt() {} }
class Pts extends Obj { constructor(g, m) { super(); this.geometry = g; this.material = m; made.points++; } }
class Lines extends Obj { constructor(g, m) { super(); this.geometry = g; this.material = m; made.lines++; } }
const mat = class { constructor(o) { Object.assign(this, { opacity: 1 }, o); } };
const T = {
  BufferGeometry: Geo, BufferAttribute: Attr, Mesh, InstancedMesh: Inst, Points: Pts, LineSegments: Lines, Object3D: Obj, Color: class { constructor() {} },
  MeshBasicMaterial: mat, MeshLambertMaterial: mat, MeshStandardMaterial: mat, PointsMaterial: mat, LineBasicMaterial: mat,
  PlaneGeometry: Geo, CircleGeometry: Geo, RepeatWrapping: 1, AdditiveBlending: 2, DoubleSide: 2
};
const added = [], scene = { add: (o) => added.push(o) };
const ctex = (w, h, draw) => { const g = new Proxy({}, { get: (t, p) => (p === 'createRadialGradient' || p === 'createLinearGradient' ? () => ({ addColorStop() {} }) : () => {}), set: () => true }); draw(g, w, h); return { }; };
const city = City.build({ T, scene, ctex, dotTex: {}, ground: 256 });
ok(made.instanced === 2 && made.points >= 3 && made.lines === 1 && made.meshes >= 10, 'objectos da cidade em falta: ' + JSON.stringify(made));
ok(city.builds.length === 3 && city.builds.every((q) => q.mesh.geometry.attributes.position.count === q.boxes * 30), 'edifícios: vértices != caixas*30');
const total = city.builds.reduce((s, q) => s + q.boxes, 0); ok(total === a.boxes.length, 'edifícios em falta');
city.setLevel(0, false); const lo = city.builds.map((q) => q.mesh.geometry.range[1]); city.setLevel(2, false); const hi = city.builds.map((q) => q.mesh.geometry.range[1]);
ok(lo.every((v, i) => v < hi[i]), 'qualidade baixa devia desenhar menos edifícios');
for (let t = 0; t < 600; t++) city.update(t / 60);   // animação sem erros
console.log('smoke_city OK — ' + a.boxes.length + ' volumes, ' + a.signs.length + ' letreiros, ' + a.lamps.length + ' candeeiros, ' + a.cars.length + ' carros; faces viradas para fora; sem plateia');
