/* Teste de fumo da aplicação completa com DOM e THREE falsos: arranca, abre menus, joga uma partida a solo,
   pausa, abre definições e volta ao menu, à procura de erros de código (não valida gráficos reais). */
const path = require('path');
const base = path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'game', 'js');
const any = () => new Proxy(function () {}, {
  get: (t, p) => (p === Symbol.toPrimitive ? () => 0 : p === 'then' ? undefined : (p in t ? t[p] : (t[p] = any()))),
  apply: () => any(), construct: () => any(), set: (t, p, v) => { t[p] = v; return true }
});
class El {
  constructor(id) {
    this.id = id; this.cls = new Set(); this.style = {}; this.dataset = {}; this.children = []; this.l = {}; this.hidden = true; this.value = ''; this.textContent = ''; this.innerHTML = '';
    const self = this; this.classList = { add: (c) => self.cls.add(c), remove: (c) => self.cls.delete(c), toggle: (c, f) => { if (f === undefined ? !self.cls.has(c) : f) self.cls.add(c); else self.cls.delete(c); }, contains: (c) => self.cls.has(c) };
    this.offsetWidth = 1; this.firstChild = null; this.lastChild = null;
  }
  set className(v) { this.cls = new Set(String(v).split(' ').filter(Boolean)); } get className() { return [...this.cls].join(' '); }
  addEventListener(t, f) { (this.l[t] = this.l[t] || []).push(f); }
  fire(t, ev) { (this.l[t] || []).forEach((f) => f(Object.assign({ preventDefault() {}, target: this, pointerId: 1, clientX: 0, clientY: 0 }, ev))); }
  appendChild(c) { this.children.push(c); this.firstChild = this.firstChild || c; this.lastChild = c; return c; }
  insertBefore(c) { this.children.unshift(c); return c; }
  querySelector() { return new El('q'); } querySelectorAll() { return []; }
  getBoundingClientRect() { return { left: 0, top: 0, width: 200, height: 200 }; } setPointerCapture() {} getContext() { return any(); }
  get disabled() { return !!this._d; } set disabled(v) { this._d = v; }
}
const store = {}; const rafs = [];
const els = new Proxy(store, { get: (o, id) => (o[id] = o[id] || new El(id)) });
globalThis.window = globalThis;
globalThis.document = {
  readyState: 'complete', body: new El('body'), documentElement: { style: { setProperty() {} } },
  getElementById: (id) => els[id], createElement: (t) => new El(t),
  querySelectorAll: () => [], addEventListener() {}
};
globalThis.navigator = { hardwareConcurrency: 8, deviceMemory: 4, vibrate() {} };
globalThis.innerWidth = 1280; globalThis.innerHeight = 600; globalThis.devicePixelRatio = 2;
globalThis.addEventListener = () => {}; globalThis.requestAnimationFrame = (f) => { rafs.push(f); };
globalThis.localStorage = { _: {}, getItem(k) { return this._[k] || null; }, setItem(k, v) { this._[k] = v; } };
globalThis.THREE = any();
const errors = []; const ce = console.error; console.error = (...a) => { errors.push(a.join(' ')); ce(...a); };
for (const f of ['settings', 'audio', 'protocol', 'sim', 'ai', 'models', 'model', 'city', 'scene', 'input', 'net', 'app']) require(path.join(base, f + '.js'));
const DK = globalThis.DK; let t = 0;
const frames = (n, hook) => { for (let i = 0; i < n; i++) { const cb = rafs.splice(0); t += 16.7; cb.forEach((f) => f(t)); if (hook) hook(i); } };
const click = (id) => els[id].fire('click', {});
(async () => {
frames(3);
if (els.fatal.hidden === false) throw new Error('fatal: ' + els.fatal.textContent);
els.splash.fire('pointerdown', {}); await new Promise((r) => setTimeout(r, 50)); frames(10);
if (!els.menu.cls.has('show')) throw new Error('menu não apareceu');
for (const id of ['mSettings', 'setBack', 'mFighters', 'fgBack', 'mSolo']) { click(id); frames(2); }
click('fgGo'); frames(2);
if (!els.hud.cls.has('show')) throw new Error('combate não iniciou');
let hits = 0; frames(60 * 40, (i) => { if (i % 25 === 0) DK.Input.edges.p = 1; if (i % 40 === 0) DK.Input.edges.k = 1; DK.Input.mx = (i % 300) < 150 ? 1 : 0; DK.Input.b = (i % 200) > 150 ? 1 : 0; });
click('pauseBtn'); frames(5); click('paResume'); frames(5);
click('pauseBtn'); click('paQuit'); click('cfYes'); frames(5);
if (!els.menu.cls.has('show')) throw new Error('não voltou ao menu');
if (errors.length) throw new Error('erros de execução: ' + errors[0]);
console.log('smoke_app OK — arranque, menus, definições, 40 s de combate simulado, pausa e saída sem erros de código');
process.exit(0);
})().catch((e) => { console.error('FALHOU: ' + e.stack); process.exit(1); });
