/* Teste do modelo 3D com um THREE falso (tests/fake_three.js, com matemática de transformações real; sem WebGL):
   1) modelo procedural (fallback quando os GLB não estão carregados);
   2) GLB reais de assets/game/models: orçamento de triângulos, ossos, e cinemática das poses (para onde apontam os braços/pernas). */
const path = require('path'), fs = require('fs');
const FT = require('./fake_three.js');
const root = path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'game');
const base = path.join(root, 'js');
require(path.join(base, 'sim.js')); require(path.join(base, 'models.js')); require(path.join(base, 'model.js'));
const DK = globalThis.DK;
const ok = (c, m) => { if (!c) throw new Error(m); };
const W = (o, p) => FT.toWorld(o, p || [0, 0, 0]);

function run(m, f, state, st, vx) {
  f.state = state; f.st = st; f.vx = vx || 0;
  for (let i = 0; i < 90; i++) { m.update(f, 1 / 60); if (state === 'idle' || state === 'walk') f.st = i / 60; }
}
function allStates(m, def, label) {
  const f = DK.Sim.makeFighter(def, 0);
  for (const s of DK.Sim.STATES) {
    for (let i = 0; i < 90; i++) {
      f.state = s; f.st = i / 60; f.vx = s === 'walk' ? 3 : 0; m.update(f, 1 / 60);
      for (const k of ['x', 'y', 'z']) if (!isFinite(m.J.body.position[k]) || !isFinite(m.J.root.position[k])) throw new Error(label + ': NaN em ' + s);
      if (m.J.body.position.y < 0.3 || m.J.body.position.y > 1.6) throw new Error(label + ': altura da anca absurda em ' + s + ': ' + m.J.body.position.y);
    }
  }
}

// ---------- 1) fallback procedural ----------
let proc = 0;
for (const id of ['kira', 'ren']) {
  const m = new DK.FighterModel(DK.Sim.FIGHTERS[id], 'medium');
  ok(m.kind === 'procedural', 'sem GLB carregado devia usar o modelo procedural');
  allStates(m, DK.Sim.FIGHTERS[id], 'procedural/' + id); proc++; m.dispose();
}

// ---------- 2) GLB ----------
const read = (n) => { const b = fs.readFileSync(path.join(root, 'models', n + '.glb')); return b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength); };
const BUDGET = { lod0: 7500, lod1: 7500 };   // lod1 = mesma malha com textura 512 (só muda o tamanho do ficheiro)
const info = [];
for (const id of ['kira', 'ren']) for (const lod of ['lod0', 'lod1']) {
  const model = DK.Models.parse(read(id + '_' + lod));
  DK.Models.set(id + '_' + lod, model);
  ok(model.tris <= BUDGET[lod], id + '_' + lod + ': ' + model.tris + ' triângulos (máx. ' + BUDGET[lod] + ')');
  ok(model.tris >= 800, id + '_' + lod + ': demasiado poucos triângulos');
  ok(model.extras.textured && model.skin && model.skin.length === 21, id + '_' + lod + ': devia ser texturado e skinned com 21 ossos');
  const pr = model.meshes[0][0];
  ok(pr.uv && pr.joints && pr.weights && pr.uv.length / 2 === pr.pos.length / 3 && pr.joints.length === pr.weights.length && pr.weights.length / 4 === pr.pos.length / 3, id + ': atributos de skinning incoerentes');
  for (let v = 0; v < pr.pos.length / 3; v++) { const sum = pr.weights[4 * v] + pr.weights[4 * v + 1] + pr.weights[4 * v + 2] + pr.weights[4 * v + 3]; if (Math.abs(sum - 1) > 1e-3) throw new Error(id + ': pesos não somam 1 no vértice ' + v); }
  ok(model.materials[0].img && model.materials[0].img.bytes.length > 10000, id + '_' + lod + ': sem textura embutida');
  ok(model.extras.triangles === model.tris, 'extras.triangles não coincide com a contagem real');
  info.push(id + '_' + lod + '=' + model.tris);
}
let mesh0 = 0;
for (const id of ['kira', 'ren']) for (const q of ['medium', 'low']) {
  const def = DK.Sim.FIGHTERS[id], m = new DK.FighterModel(def, q);
  ok(m.kind === 'glb', id + '/' + q + ': devia usar o GLB');
  ok(m.glb.tris === (q === 'low' ? DK.Models.get(id, 'low').tris : DK.Models.get(id, 'medium').tris), 'LOD errado');
  allStates(m, def, 'glb/' + id + '/' + q);
  const g0 = FT.Geo.disposed; m.dispose();
  ok(FT.Geo.disposed - g0 === m.glb.geos.length, 'dispose não devia libertar geometrias partilhadas dos GLB');
  if (q === 'medium') { const m2 = new DK.FighterModel(def, q); m2.root.traverse((o) => { if (o.isMesh) mesh0++; }); m2.dispose(); }
}
ok(DK.Models.get('kira', 'low').materials[0].img.bytes.length < DK.Models.get('kira', 'medium').materials[0].img.bytes.length, 'LOD baixo devia ter textura mais pequena');

// cinemática: poses -> posições no mundo (lutador a olhar para +X; 'l' = lado -Z, 'r' = lado +Z)
const def = DK.Sim.FIGHTERS.kira, m = new DK.FighterModel(def, 'medium'), J = m.J;
const fighter = () => { const f = DK.Sim.makeFighter(def, 0); f.x = 0; f.face = 1; return f; };
const peak = (s) => { const f = fighter(), t = DK.Sim.moveTimes(s, def); f.state = s; f.st = t.su + t.ac; for (let i = 0; i < 18; i++) m.update(f, 1 / 60); return f; };
const settle = (s, st) => { const f = fighter(); f.state = s; f.st = st; for (let i = 0; i < 120; i++) m.update(f, 1 / 60); return f; };

settle('idle', 0);
const head0 = W(J.head, [0, 0.2, 0])[1], hip0 = J.body.position.y;
ok(head0 > 1.6 && head0 < 2.1, 'altura da cabeça em guarda: ' + head0);
ok(W(J.lGlow)[2] < -0.05 && W(J.rGlow)[2] > 0.05, 'esquerda deve ficar em -Z e direita em +Z');
peak('punchL'); ok(W(J.lGlow)[0] > 0.7, 'jab esquerdo devia esticar para a frente: ' + W(J.lGlow)[0]);
peak('punchR'); ok(W(J.rGlow)[0] > 0.7, 'direto devia esticar para a frente: ' + W(J.rGlow)[0]);
peak('kickF'); { const p = W(J.rSh, [0, -0.6, 0.1]); ok(p[0] > 0.6 && p[1] > 0.6, 'pontapé frontal: pé em ' + p.map((v) => v.toFixed(2))); }
peak('kickH'); { const p = W(J.rSh, [0, -0.6, 0.1]); ok(p[1] > 1.3, 'pontapé alto: pé devia passar 1.3 m: ' + p[1]); }
peak('special'); ok(W(J.lGlow)[0] > 0.4 && W(J.rGlow)[0] > 0.4, 'especial: os dois punhos para a frente'); ok(J.rGlow.visible && J.lGlow.visible, 'brilho dos punhos no especial');
settle('down', 1); { const h = W(J.head, [0, 0.2, 0]); ok(h[1] < 0.5 && h[0] < -1, 'caído: cabeça no chão atrás: ' + h.map((v) => v.toFixed(2))); }
settle('win', 0.5); ok(W(J.lGlow)[1] > head0 && W(J.rGlow)[1] > head0, 'vitória: punhos acima da cabeça');
settle('idle', 0);
{ const f = fighter(); f.face = -1; f.x = 2; m.update(f, 1 / 60); ok(W(J.lGlow)[0] < 2 - 0.1, 'virado para -X os punhos ficam do lado negativo'); }
{ const f = fighter(); f.state = 'idle'; for (let i = 0; i < 90; i++) m.update(f, 1 / 60); ok(Math.abs(J.body.position.y - hip0) < 0.05, 'anca estável em guarda'); }
// malha deformada (skinning linear nos ossos, como a GPU): sem vértices a "explodir" em nenhuma pose, e o punho segue o osso
function skinnedBounds(mod, model) {
  const pr = model.meshes[0][0], names = model.skin.map((ni) => model.nodes[ni].name);
  const rp = {}; const walk = (ni, o) => { const nd = model.nodes[ni], p = [o[0] + (nd.translation ? nd.translation[0] : 0), o[1] + (nd.translation ? nd.translation[1] : 0), o[2] + (nd.translation ? nd.translation[2] : 0)]; rp[nd.name] = p; (nd.children || []).forEach((c) => walk(c, p)); };
  walk(model.root, [0, 0, 0]);
  const B = { pelvis: mod.J.body, torso: mod.J.torso, head: mod.J.head, shoulder_R: mod.J.rUA, elbow_R: mod.J.rFA, shoulder_L: mod.J.lUA, elbow_L: mod.J.lFA, thigh_R: mod.J.rTh, knee_R: mod.J.rSh, thigh_L: mod.J.lTh, knee_L: mod.J.lSh,
    chest: mod.J.chest, neck: mod.J.neck, clavicle_R: mod.J.rCl, clavicle_L: mod.J.lCl, hand_R: mod.J.rHand, hand_L: mod.J.lHand, foot_R: mod.J.rFoot, foot_L: mod.J.lFoot, toe_R: mod.J.rToe, toe_L: mod.J.lToe };
  const mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9]; let fist = -1e9;
  for (let v = 0; v < pr.pos.length / 3; v += 3) {
    const out = [0, 0, 0];
    for (let k = 0; k < 4; k++) { const w = pr.weights[4 * v + k]; if (!w) continue; const n = names[pr.joints[4 * v + k]], r = rp[n];
      const q = W(B[n], [pr.pos[3 * v] - r[0], pr.pos[3 * v + 1] - r[1], pr.pos[3 * v + 2] - r[2]]); for (let i = 0; i < 3; i++) out[i] += w * q[i]; }
    for (let i = 0; i < 3; i++) { if (!isFinite(out[i])) throw new Error('vértice não finito'); mn[i] = Math.min(mn[i], out[i]); mx[i] = Math.max(mx[i], out[i]); }
    if (names[pr.joints[4 * v]] === 'hand_L' && pr.weights[4 * v] > 0.5) fist = Math.max(fist, out[0]);   // osso hand_L = mão esquerda
  }
  return { mn, mx, fist };
}
{
  const model = DK.Models.get('kira', 'medium'), reach = {};
  for (const s of ['idle', 'punchL', 'punchR', 'kickF', 'kickH', 'special', 'down', 'win', 'lose', 'hit', 'block']) {
    const f = fighter(); f.state = s; const t = DK.Sim.moveTimes(s, def); f.st = t ? t.su + t.ac : 0.5; for (let i = 0; i < 90; i++) m.update(f, 1 / 60);
    const b = skinnedBounds(m, model); reach[s] = b;
    ok(b.mn[1] > -0.6 && b.mx[1] < 2.9 && b.mn[0] > -2.4 && b.mx[0] < 2.4 && Math.abs(b.mn[2]) < 1.2 && Math.abs(b.mx[2]) < 1.2, 'malha fora de limites em ' + s + ': ' + JSON.stringify(b));
  }
  ok(reach.idle.mn[1] > -0.08 && reach.idle.mn[1] < 0.15, 'pés de KIRA devem assentar no chão em guarda: ' + reach.idle.mn[1]);
  ok(reach.idle.mx[1] > 1.8 && reach.idle.mx[1] < 2.2, 'altura total de KIRA em guarda: ' + reach.idle.mx[1]);
  ok(reach.punchL.fist > 0.8, 'punho esquerdo (jab) devia alcançar > 0.8 à frente: ' + reach.punchL.fist);
  ok(reach.punchL.fist > reach.idle.fist + 0.2, 'o jab devia estender o punho para a frente');
}
const ren = new DK.FighterModel(DK.Sim.FIGHTERS.ren, 'medium'); ok(ren.kind === 'glb', 'REN em GLB');
{ const rm = DK.Models.get('ren', 'medium'); let sk = 0; ren.root.traverse((o) => { if (o.isSkinnedMesh) sk++; }); ok(sk === 1 && rm.extras.textured, 'REN devia ter 1 malha skinned');
  const g0 = FT.Texture.disposed; ren.dispose(); ok(FT.Texture.disposed === g0, 'a textura partilhada não deve ser libertada com o lutador'); }
m.dispose();

// carregador: rejeita ficheiros inválidos
let rej = 0; for (const bad of [new ArrayBuffer(8), new Uint8Array(40).buffer]) { try { DK.Models.parse(bad); } catch (e) { rej++; } }
ok(rej === 2, 'parse devia rejeitar GLB inválido');

// os 10 ossos novos existem, mexem-se e as molas ficam estáveis (sem NaN) em todos os estados
{
  const f = fighter(), seen = {}; const names = ['chest', 'neck', 'rCl', 'lCl', 'rHand', 'lHand', 'rFoot', 'lFoot', 'rToe', 'lToe'];
  for (const n of names) { ok(J[n], 'falta o osso ' + n); seen[n] = 0; }
  for (const st of ['idle', 'walk', 'punchL', 'punchR', 'kickF', 'kickH', 'special', 'block', 'hit', 'down', 'getup', 'win']) {
    f.state = st; f.vx = st === 'walk' ? 3 : 0;
    for (let i = 0; i < 120; i++) {
      f.st = i / 60; m.update(f, 1 / 60);
      for (const n of names) { const r = J[n].rotation; if (!isFinite(r.x + r.y + r.z)) throw new Error('rotação não finita em ' + n + '/' + st); seen[n] = Math.max(seen[n], Math.abs(r.x) + Math.abs(r.y) + Math.abs(r.z)); if (Math.abs(r.x) > 1.6 || Math.abs(r.y) > 1.2 || Math.abs(r.z) > 1.2) throw new Error('rotação absurda em ' + n + '/' + st + ': ' + [r.x, r.y, r.z].map((v) => v.toFixed(2))); }
    }
  }
  for (const n of names) ok(seen[n] > 0.02, 'o osso ' + n + ' nunca se mexeu');
}
console.log('smoke_model OK — procedural ' + proc + '/2, GLB (' + info.join(', ') + ' triângulos), ' + Math.round(mesh0 / 2) + ' malhas por lutador, 21 ossos (coluna, pescoço, clavículas, pulsos, pés, dedos) animados, poses verificadas (jab, direto, pontapés, especial, queda, vitória)');
