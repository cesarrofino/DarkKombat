/* Teste de fumo do modelo 3D com um THREE falso: executa todo o código de construção e animação (sem WebGL). */
const path = require('path');
const base = path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'game', 'js');
class V { constructor() { this.x = 0; this.y = 0; this.z = 0; } set(x, y, z) { this.x = x; this.y = y; this.z = z; return this; } setScalar(s) { this.x = this.y = this.z = s; return this; } }
class Obj {
  constructor() { this.children = []; this.position = new V(); this.rotation = new V(); this.scale = new V(); this.scale.set(1, 1, 1); this.visible = true; this.parent = null; this.geometry = null; this.material = null; }
  add(o) { this.children.push(o); o.parent = this; return this; }
  remove(o) { this.children = this.children.filter((c) => c !== o); }
  traverse(cb) { cb(this); this.children.forEach((c) => c.traverse(cb)); }
}
class Mesh extends Obj { constructor(g, m) { super(); this.geometry = g; this.material = m; this.isMesh = true; } }
class Geo { dispose() { Geo.disposed++; } }
Geo.disposed = 0;
class Mat { constructor(o) { Object.assign(this, o); } dispose() { Mat.disposed++; } }
Mat.disposed = 0;
globalThis.THREE = {
  Group: Obj, Mesh, CapsuleGeometry: Geo, BoxGeometry: Geo, SphereGeometry: Geo, CylinderGeometry: Geo, PlaneGeometry: Geo,
  MeshStandardMaterial: class extends Mat { get isMeshStandardMaterial() { return true; } }, MeshBasicMaterial: Mat,
  CanvasTexture: class { dispose() {} }, AdditiveBlending: 2
};
globalThis.document = { createElement: () => ({ width: 0, height: 0, getContext: () => ({ createRadialGradient: () => ({ addColorStop() {} }), fillRect() {} }) }) };
require(path.join(base, 'sim.js')); require(path.join(base, 'model.js'));
const DK = globalThis.DK; let meshes = 0;
for (const id of ['kira', 'ren']) {
  const m = new DK.FighterModel(DK.Sim.FIGHTERS[id], 'medium');
  m.root.traverse((o) => { if (o.isMesh) meshes++; });
  const f = DK.Sim.makeFighter(DK.Sim.FIGHTERS[id], 0);
  for (const s of DK.Sim.STATES) {
    f.state = s; f.vx = s === 'walk' ? 3 : 0;
    for (let i = 0; i < 90; i++) {
      f.st = i / 60; m.update(f, 1 / 60);
      for (const k of ['x', 'y', 'z']) { if (!isFinite(m.J.body.position[k]) || !isFinite(m.J.root.position[k])) throw new Error('NaN em ' + s); }
      if (m.J.body.position.y < 0.3 || m.J.body.position.y > 1.6) throw new Error('altura da anca absurda em ' + s + ': ' + m.J.body.position.y);
    }
  }
  m.dispose();
}
console.log('smoke_model OK — malhas por lutador ≈ ' + Math.round(meshes / 2) + ', geometrias libertadas: ' + Geo.disposed);
