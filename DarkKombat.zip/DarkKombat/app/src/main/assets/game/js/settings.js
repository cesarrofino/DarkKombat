/* Dark Kombat - preferências (guardadas no Android via GameSettings + localStorage como reserva). */
(function () {
  const DK = (globalThis.DK = globalThis.DK || {});
  const DEFAULTS = {
    quality: 'auto', music: 0.6, sfx: 0.9, vibration: true, joy: 1, ui: 1, reduceFx: false,
    fighter: 'kira', diff: 'normal', name: 'Jogador'
  };
  const S = Object.assign({}, DEFAULTS);
  const num = (v, a, b, d) => (typeof v === 'number' && isFinite(v) ? Math.min(b, Math.max(a, v)) : d);

  DK.Settings = {
    data: S, DEFAULTS,
    load() {
      let raw = null;
      try { if (globalThis.AndroidBridge) raw = globalThis.AndroidBridge.getSettings(); } catch (e) { /* ignora */ }
      if (!raw) { try { raw = localStorage.getItem('dk_settings'); } catch (e) { /* ignora */ } }
      if (raw) {
        try {
          const o = JSON.parse(raw);
          if (['auto', 'low', 'medium', 'high'].indexOf(o.quality) >= 0) S.quality = o.quality;
          S.music = num(o.music, 0, 1, DEFAULTS.music); S.sfx = num(o.sfx, 0, 1, DEFAULTS.sfx);
          S.joy = num(o.joy, 0.6, 1.6, 1); S.ui = num(o.ui, 0.8, 1.3, 1);
          if (typeof o.vibration === 'boolean') S.vibration = o.vibration;
          if (typeof o.reduceFx === 'boolean') S.reduceFx = o.reduceFx;
          if (o.fighter === 'kira' || o.fighter === 'ren') S.fighter = o.fighter;
          if (['easy', 'normal', 'hard'].indexOf(o.diff) >= 0) S.diff = o.diff;
          if (typeof o.name === 'string') S.name = o.name.replace(/[^A-Za-z0-9 _\-]/g, '').slice(0, 16) || 'Jogador';
        } catch (e) { /* ficheiro corrompido: usa predefinições */ }
      }
    },
    save() {
      const raw = JSON.stringify(S);
      try { localStorage.setItem('dk_settings', raw); } catch (e) { /* ignora */ }
      try { if (globalThis.AndroidBridge) globalThis.AndroidBridge.saveSettings(raw); } catch (e) { /* ignora */ }
    }
  };
})();
