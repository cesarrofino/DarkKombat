/* Dark Kombat - cidade cyberpunk (low-poly). A arena fica numa praça no cruzamento de duas avenidas; à volta há quarteirões,
   passeios, candeeiros, carros estacionados, letreiros néon, painéis holográficos e carros voadores.
   Tudo é geometria fundida (poucas chamadas de desenho). layout() é lógica pura (testável em Node); build() cria os objetos THREE. */
(function () {
  const DK = (globalThis.DK = globalThis.DK || {});

  // ---- medidas da cidade (metros) ----
  const C = {
    PLAZA: 14,          // raio da praça da arena
    MAIN: 8,            // meia-largura do asfalto das avenidas principais (eixos X e Z)
    BLOCK0: 12,         // onde começa o primeiro quarteirão (depois do passeio da avenida)
    BLOCK_W: 22, PITCH: 30, NB: 3,   // largura do quarteirão, distância entre quarteirões, nº de quarteirões por quadrante e eixo
    STREET: 4,          // meia-largura do asfalto das ruas transversais
    MAP: 100            // meia-largura do mapa pintado no chão
  };
  C.STREETS = [C.BLOCK0 + C.BLOCK_W + (C.PITCH - C.BLOCK_W) / 2, C.BLOCK0 + C.PITCH + C.BLOCK_W + (C.PITCH - C.BLOCK_W) / 2];   // centros das ruas transversais (38 e 68)

  function mulberry32(a) { return function () { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

  const SIGN_TEXTS = [
    ['NEON ARCADE', '#ff2bd6', '#ffd0f6'], ['RAMEN 24H', '#ff6a3d', '#ffe0c8'], ['CYBERDRONE', '#00e5ff', '#d0fbff'], ['HOTEL KO', '#ff2bd6', '#ffd0f6'],
    ['TECHNO MART', '#00e5ff', '#d0fbff'], ['FIGHT NIGHT', '#ff4d4d', '#ffd6d6'], ['DARK KOMBAT', '#00e5ff', '#ffffff'], ['CYBER GOGO', '#7a3cff', '#d9c8ff'],
    ['ARCADE', '#2d8bff', '#bfe0ff'], ['BAR', '#ff2bd6', '#ffd0f6'], ['CLINIC', '#2dff9a', '#d0ffe8'], ['NOODLES', '#ffd24d', '#fff3c4'],
    ['SYNTH', '#7a3cff', '#e6d9ff'], ['KARATE DOJO', '#ff4d4d', '#ffe0e0'], ['DATA', '#00e5ff', '#d0fbff'], ['PHARMA', '#2dff9a', '#d0ffe8']
  ];
  const SIGN_COLS = 4, SIGN_ROWS = 4;

  /** Gera toda a disposição da cidade (sem THREE). Determinista (mesma semente = mesma cidade). */
  function layout(seed) {
    const R = mulberry32(seed || 20241);
    const rnd = (a, b) => a + R() * (b - a), pick = (arr) => arr[Math.floor(R() * arr.length)];
    const boxes = [];            // edifícios (paredes com janelas)
    const props = [];            // objectos escuros (postes, antenas, equipamento de telhado)
    const glow = [];             // objectos brilhantes (cabeças de candeeiro, ecrãs)
    const signs = [];            // letreiros (quad virado para fora)
    const lamps = [];            // posições dos candeeiros (halo)
    const cars = [];             // carros estacionados
    const warn = [];             // luzes vermelhas de aviso
    const tints = [[1, 1, 1], [0.8, 0.95, 1], [1, 0.85, 0.95], [0.9, 0.85, 1], [1, 0.95, 0.8]];

    function addBuilding(cx, cz, w, d, h, dist) {
      const v = Math.floor(R() * 3), tn = pick(tints), k = rnd(0.62, 1) * (dist > 80 ? 0.75 : 1);
      const tier = h > 26 && R() < 0.55;
      const t = [tn[0] * k, tn[1] * k, tn[2] * k];
      if (tier) {
        const h1 = h * rnd(0.35, 0.5), inset = rnd(0.18, 0.3);
        boxes.push({ x: cx, z: cz, w, d, y0: 0, h: h1, v, t, dist });
        const w2 = w * (1 - inset), d2 = d * (1 - inset), h2 = h - h1;
        boxes.push({ x: cx + rnd(-0.1, 0.1) * w, z: cz + rnd(-0.1, 0.1) * d, w: w2, d: d2, y0: h1, h: h2, v, t, dist });
        if (h > 45 && R() < 0.6) {   // terceiro nível fino + antena
          const w3 = w2 * 0.55, d3 = d2 * 0.55;
          boxes.push({ x: cx, z: cz, w: w3, d: d3, y0: h, h: h * 0.18, v, t, dist });
          props.push({ x: cx, z: cz, w: 0.35, d: 0.35, y0: h + h * 0.18, h: rnd(6, 14), c: [0.18, 0.2, 0.26] });
          warn.push([cx, h + h * 0.18 + 12, cz]);
        }
        return h;
      }
      boxes.push({ x: cx, z: cz, w, d, y0: 0, h, v, t, dist });
      // equipamento de telhado
      const n = Math.floor(rnd(1, 4));
      for (let i = 0; i < n; i++) props.push({ x: cx + rnd(-w * 0.3, w * 0.3), z: cz + rnd(-d * 0.3, d * 0.3), w: rnd(0.8, 2.2), d: rnd(0.8, 2.2), y0: h, h: rnd(0.6, 1.6), c: [0.12, 0.14, 0.2] });
      if (h > 30 && R() < 0.5) { props.push({ x: cx + rnd(-w * 0.25, w * 0.25), z: cz + rnd(-d * 0.25, d * 0.25), w: 0.3, d: 0.3, y0: h, h: rnd(5, 11), c: [0.2, 0.22, 0.28] }); warn.push([cx, h + 9, cz]); }
      return h;
    }

    function addSign(bx, bz, w, d, face, h, nearAxis) {
      // face: 'x+','x-','z+','z-' (normal para fora). Só nos lados virados para as avenidas.
      const len = (face[0] === 'x' ? d : w), off = rnd(-len / 2 + 3.5, len / 2 - 3.5);
      const sw = rnd(6, 9), sh = sw * 0.34, y = rnd(5, Math.max(6, Math.min(h - 3, 16)));
      const cell = Math.floor(R() * SIGN_COLS * SIGN_ROWS);
      let x = bx, z = bz, nx = 0, nz = 0;
      if (face === 'x+') { x = bx + w / 2 + 0.15; z = bz + off; nx = 1; } else if (face === 'x-') { x = bx - w / 2 - 0.15; z = bz + off; nx = -1; }
      else if (face === 'z+') { z = bz + d / 2 + 0.15; x = bx + off; nz = 1; } else { z = bz - d / 2 - 0.15; x = bx + off; nz = -1; }
      signs.push({ x, y, z, nx, nz, w: sw, h: sh, cell });
      if (nearAxis && R() < 0.8) signs.push({ x: x + nz * 0, y: y + sh + 2.2 + R() * 3, z, nx, nz, w: sw * 0.8, h: sh * 0.8, cell: Math.floor(R() * SIGN_COLS * SIGN_ROWS) });   // segundo letreiro por cima
    }

    // ---- quarteirões nos 4 quadrantes ----
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) for (let kx = 0; kx < C.NB; kx++) for (let kz = 0; kz < C.NB; kz++) {
      const x0 = C.BLOCK0 + kx * C.PITCH + 2, z0 = C.BLOCK0 + kz * C.PITCH + 2, W = C.BLOCK_W - 4;   // área útil (passeios de 2 m)
      const cxB = sx * (x0 + W / 2), czB = sz * (z0 + W / 2), dist = Math.hypot(cxB, czB);
      const near = kx === 0 && kz === 0;
      const mode = near ? 'quad' : pick(['quad', 'quad', 'twin', 'mega']);
      const hBase = near ? rnd(14, 26) : 14 + Math.min(70, dist * 0.55) * rnd(0.5, 1.5);
      const plots = [];
      if (mode === 'quad') { const s = (W - 1.2) / 2; for (const a of [-1, 1]) for (const b of [-1, 1]) plots.push([cxB + a * (s / 2 + 0.6), czB + b * (s / 2 + 0.6), s, s]); }
      else if (mode === 'twin') { if (R() < 0.5) { const s = (W - 1.2) / 2; for (const a of [-1, 1]) plots.push([cxB + a * (s / 2 + 0.6), czB, s, W]); } else { const s = (W - 1.2) / 2; for (const b of [-1, 1]) plots.push([cxB, czB + b * (s / 2 + 0.6), W, s]); } }
      else plots.push([cxB, czB, W - 1, W - 1]);
      for (const [px, pz, pw, pd] of plots) {
        const dd = Math.hypot(px, pz), h = Math.max(8, hBase * rnd(0.7, 1.35) * (mode === 'mega' ? 1.5 : 1));
        const hh = addBuilding(px, pz, pw, pd, h, dd);
        // letreiros nos lados virados para as avenidas (praça e avenidas principais)
        if (dd < 70) {
          if (kz === 0) addSign(px, pz, pw, pd, sz > 0 ? 'z-' : 'z+', hh, near);                       // virado para a avenida do eixo X
          if (kx === 0) addSign(px, pz, pw, pd, sx > 0 ? 'x-' : 'x+', hh, near);                       // virado para a avenida do eixo Z
          if (kz > 0 && kx > 0 && R() < 0.3) addSign(px, pz, pw, pd, R() < 0.5 ? (sx > 0 ? 'x-' : 'x+') : (sz > 0 ? 'z-' : 'z+'), hh, false);
        }
      }
    }
    // ---- horizonte: torres distantes (esbatidas pelo nevoeiro) ----
    for (let i = 0; i < 44; i++) {
      const a = (i / 44) * Math.PI * 2 + rnd(-0.05, 0.05), r = rnd(112, 165), w = rnd(14, 28), h = rnd(70, 190);
      boxes.push({ x: Math.cos(a) * r, z: Math.sin(a) * r, w, d: w, y0: 0, h, v: Math.floor(R() * 3), t: [0.6, 0.62, 0.8], dist: r });
      if (R() < 0.5) warn.push([Math.cos(a) * r, h + 2, Math.sin(a) * r]);
    }
    boxes.sort((p, q) => p.dist - q.dist);   // os mais próximos primeiro (a qualidade baixa corta os mais distantes)

    // ---- candeeiros ao longo das avenidas e à volta da praça ----
    const lampAt = (x, z, ox, oz, col) => {
      props.push({ x, z, w: 0.22, d: 0.22, y0: 0, h: 7, c: [0.16, 0.18, 0.24] });
      props.push({ x: x + ox * 0.9, z: z + oz * 0.9, w: ox ? 1.8 : 0.16, d: oz ? 1.8 : 0.16, y0: 6.9, h: 0.14, c: [0.16, 0.18, 0.24] });
      glow.push({ x: x + ox * 1.7, z: z + oz * 1.7, w: ox ? 0.9 : 0.4, d: oz ? 0.9 : 0.4, y0: 6.7, h: 0.18, c: col });
      lamps.push([x + ox * 1.7, 6.5, z + oz * 1.7, col]);
    };
    const warm = [1, 0.86, 0.6], cool = [0.6, 0.92, 1], pink = [1, 0.4, 0.85];
    for (let i = 0; i < 7; i++) {
      const p = C.PLAZA + 4 + i * 12, col = i % 3 === 0 ? pink : i % 2 ? cool : warm;
      for (const s of [-1, 1]) {
        lampAt(p * s, C.MAIN + 0.7, 0, -1, col); lampAt(p * s, -(C.MAIN + 0.7), 0, 1, col);
        lampAt(C.MAIN + 0.7, p * s, -1, 0, col); lampAt(-(C.MAIN + 0.7), p * s, 1, 0, col);
      }
    }
    for (let i = 0; i < 8; i++) {   // praça
      const a = (i / 8) * Math.PI * 2 + Math.PI / 8, x = Math.cos(a) * (C.PLAZA - 1), z = Math.sin(a) * (C.PLAZA - 1);
      lampAt(x, z, -Math.cos(a), -Math.sin(a), i % 2 ? [0.2, 0.9, 1] : [1, 0.3, 0.85]);
    }
    // bolardos luminosos a delimitar a praça
    for (let i = 0; i < 28; i++) {
      const a = (i / 28) * Math.PI * 2;
      if (Math.abs(Math.sin(a)) < 0.6 || Math.abs(Math.cos(a)) < 0.6) continue;   // deixa as entradas das avenidas livres
      const x = Math.cos(a) * (C.PLAZA + 0.4), z = Math.sin(a) * (C.PLAZA + 0.4);
      props.push({ x, z, w: 0.28, d: 0.28, y0: 0, h: 0.8, c: [0.12, 0.14, 0.2] });
      glow.push({ x, z, w: 0.3, d: 0.3, y0: 0.8, h: 0.1, c: i % 2 ? [0, 0.9, 1] : [1, 0.2, 0.8] });
    }
    // quiosques / máquinas de venda junto à praça
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2 + 0.5, r = C.PLAZA + 2.6, x = Math.cos(a) * r, z = Math.sin(a) * r;
      if (Math.abs(x) < C.MAIN + 1.5 || Math.abs(z) < C.MAIN + 1.5) continue;
      props.push({ x, z, w: 1.6, d: 1.0, y0: 0, h: 2.4, c: [0.1, 0.12, 0.18], rot: a });
      glow.push({ x: x - Math.cos(a) * 0.52, z: z - Math.sin(a) * 0.52, w: 1.2, d: 0.08, y0: 0.7, h: 1.4, c: i % 2 ? [0.2, 0.8, 1] : [1, 0.35, 0.8], rot: a });
    }
    // carros estacionados (nos dois lados das avenidas, fora da praça)
    const carCols = [[1, 0.2, 0.75], [0.1, 0.8, 1], [0.9, 0.9, 1], [0.35, 0.3, 1], [1, 0.55, 0.2], [0.2, 1, 0.65], [0.55, 0.58, 0.7]];
    for (const axis of ['x', 'z']) for (const side of [-1, 1]) for (const dir of [-1, 1]) {
      let p = C.PLAZA + 6 + rnd(0, 3);
      while (p < C.MAP - 12) {
        if (R() < 0.7) cars.push({ x: axis === 'x' ? p * dir : side * 5.4, z: axis === 'x' ? side * 5.4 : p * dir, rot: (axis === 'x' ? 0 : Math.PI / 2) + (R() < 0.5 ? 0 : Math.PI) + rnd(-0.03, 0.03), col: pick(carCols) });
        p += rnd(7, 12);
      }
    }
    return { boxes, props, glow, signs, lamps, cars, warn };
  }

  // ---------------- geometria fundida ----------------
  /** Acrescenta uma caixa (todas as faces menos o fundo) a listas de posições/UV/cores. rot = rotação em Y. */
  function pushBox(A, b, withUV, tile) {
    const hw = b.w / 2, hd = b.d / 2, y0 = b.y0, y1 = b.y0 + b.h, cs = Math.cos(b.rot || 0), sn = Math.sin(b.rot || 0);
    const P = (lx, y, lz) => [b.x + lx * cs + lz * sn, y, b.z - lx * sn + lz * cs];
    const c = b.c || b.t || [1, 1, 1];
    const quad = (p0, p1, p2, p3, u0, v0, u1, v1, k) => {   // p0,p1 em baixo (esq->dir), p2,p3 em cima (dir->esq)
      const vs = [p0, p1, p2, p0, p2, p3], uvs = [[u0, v0], [u1, v0], [u1, v1], [u0, v0], [u1, v1], [u0, v1]];
      for (let i = 0; i < 6; i++) { A.pos.push(vs[i][0], vs[i][1], vs[i][2]); A.col.push(c[0] * k, c[1] * k, c[2] * k); if (withUV) A.uv.push(uvs[i][0], uvs[i][1]); }
    };
    if (withUV) {
      const ou = b.ou || 0, TW = tile.w, TH = tile.h, vb = y0 / TH, vt = y1 / TH;
      quad(P(hw, y0, hd), P(hw, y0, -hd), P(hw, y1, -hd), P(hw, y1, hd), ou, vb, ou + b.d / TW, vt, 0.92);          // +x
      quad(P(-hw, y0, -hd), P(-hw, y0, hd), P(-hw, y1, hd), P(-hw, y1, -hd), ou, vb, ou + b.d / TW, vt, 0.92);      // -x
      quad(P(-hw, y0, hd), P(hw, y0, hd), P(hw, y1, hd), P(-hw, y1, hd), ou, vb, ou + b.w / TW, vt, 1);             // +z
      quad(P(hw, y0, -hd), P(-hw, y0, -hd), P(-hw, y1, -hd), P(hw, y1, -hd), ou, vb, ou + b.w / TW, vt, 1);         // -z
      quad(P(-hw, y1, hd), P(hw, y1, hd), P(hw, y1, -hd), P(-hw, y1, -hd), 0.004, 0.004, 0.004, 0.004, 0.45);        // telhado (zona escura da textura)
    } else {
      const k = [0.75, 0.75, 0.9, 0.9, 1];
      quad(P(hw, y0, hd), P(hw, y0, -hd), P(hw, y1, -hd), P(hw, y1, hd), 0, 0, 0, 0, k[0]);
      quad(P(-hw, y0, -hd), P(-hw, y0, hd), P(-hw, y1, hd), P(-hw, y1, -hd), 0, 0, 0, 0, k[1]);
      quad(P(-hw, y0, hd), P(hw, y0, hd), P(hw, y1, hd), P(-hw, y1, hd), 0, 0, 0, 0, k[2]);
      quad(P(hw, y0, -hd), P(-hw, y0, -hd), P(-hw, y1, -hd), P(hw, y1, -hd), 0, 0, 0, 0, k[3]);
      quad(P(-hw, y1, hd), P(hw, y1, hd), P(hw, y1, -hd), P(-hw, y1, -hd), 0, 0, 0, 0, k[4]);
    }
  }
  function newArrays() { return { pos: [], col: [], uv: [] }; }

  function carParts() {   // carro low-poly (comprimento no eixo X)
    const L = [];
    L.push({ x: 0, z: 0, w: 4.2, d: 1.8, y0: 0.35, h: 0.62, c: [1, 1, 1] });             // carroçaria
    L.push({ x: -0.15, z: 0, w: 2.2, d: 1.6, y0: 0.97, h: 0.55, c: [0.12, 0.16, 0.24] });  // cabine (vidros)
    L.push({ x: -0.15, z: 0, w: 1.7, d: 1.66, y0: 1.5, h: 0.06, c: [1, 1, 1] });           // tejadilho
    for (const sx of [-1.35, 1.35]) for (const sz of [-0.82, 0.82]) L.push({ x: sx, z: sz, w: 0.8, d: 0.3, y0: 0.0, h: 0.62, c: [0.03, 0.03, 0.05] });   // rodas
    L.push({ x: 2.12, z: 0.6, w: 0.08, d: 0.4, y0: 0.62, h: 0.12, c: [1, 0.95, 0.75] }); L.push({ x: 2.12, z: -0.6, w: 0.08, d: 0.4, y0: 0.62, h: 0.12, c: [1, 0.95, 0.75] });   // faróis
    L.push({ x: -2.12, z: 0.6, w: 0.08, d: 0.4, y0: 0.62, h: 0.12, c: [1, 0.1, 0.15] }); L.push({ x: -2.12, z: -0.6, w: 0.08, d: 0.4, y0: 0.62, h: 0.12, c: [1, 0.1, 0.15] });  // farolins
    return L;
  }


  // ---------------- texturas ----------------
  function windowTex(ctex, variant) {
    return ctex(256, 256, (g) => {
      const R = mulberry32(100 + variant * 17);
      const lit = [['#cfe9ff', '#8fd8ff', '#ffffff', '#a9ffe9'], ['#ffd27a', '#ffb35a', '#ffe7b0', '#ff9a6a'], ['#ff2bd6', '#00e5ff', '#9a6cff', '#ffffff']][variant];
      const p = [0.5, 0.42, 0.55][variant];
      g.fillStyle = '#070a16'; g.fillRect(0, 0, 256, 256);
      for (let cy = 0; cy < 8; cy++) for (let cx = 0; cx < 8; cx++) {
        const x = cx * 32, y = cy * 32;
        g.fillStyle = '#0a0f20'; g.fillRect(x, y, 32, 32);
        g.fillStyle = '#121a33'; g.fillRect(x, y + 29, 32, 3);
        if (R() < p) { g.globalAlpha = 0.6 + R() * 0.4; g.fillStyle = lit[Math.floor(R() * 4)]; g.fillRect(x + 6, y + 6, 20, 16); g.globalAlpha = 1; g.fillStyle = '#0a0f20'; g.fillRect(x + 15, y + 6, 2, 16); }
        else { g.fillStyle = '#0b1328'; g.fillRect(x + 6, y + 6, 20, 16); g.fillStyle = 'rgba(120,150,255,0.12)'; g.fillRect(x + 6, y + 6, 20, 4); }
      }
    });
  }
  function signAtlas(ctex) {
    const cw = 256, ch = 128;
    return ctex(cw * SIGN_COLS, ch * SIGN_ROWS, (g) => {
      SIGN_TEXTS.forEach((s, i) => {
        const x = (i % SIGN_COLS) * cw, y = Math.floor(i / SIGN_COLS) * ch;
        g.fillStyle = 'rgba(4,6,20,0.9)'; g.fillRect(x + 4, y + 4, cw - 8, ch - 8);
        g.strokeStyle = s[1]; g.lineWidth = 5; g.strokeRect(x + 10, y + 10, cw - 20, ch - 20);
        g.font = 'bold ' + Math.min(52, Math.floor(215 / (s[0].length * 0.62))) + 'px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
        g.shadowColor = s[1]; g.shadowBlur = 16; g.fillStyle = s[2]; g.fillText(s[0], x + cw / 2, y + ch / 2 + 2); g.shadowBlur = 0;
      });
    });
  }
  function groundTex(ctex, size) {
    const M = C.MAP, k = size / (2 * M), R = mulberry32(77);
    const X = (x) => (x + M) * k, Z = (z) => (z + M) * k;
    return ctex(size, size, (g) => {
      g.fillStyle = '#090b16'; g.fillRect(0, 0, size, size);
      const band = (a, b, col, horiz) => { g.fillStyle = col; if (horiz) g.fillRect(0, Z(a), size, (b - a) * k); else g.fillRect(X(a), 0, (b - a) * k, size); };
      const roads = [{ c: 0, hw: C.MAIN, sw: C.BLOCK0 - C.MAIN }];
      for (const s of C.STREETS) for (const sg of [-1, 1]) roads.push({ c: s * sg, hw: C.STREET, sw: 2 });
      for (const r of roads) for (const h of [true, false]) band(r.c - r.hw - r.sw, r.c + r.hw + r.sw, '#222840', h);          // passeios
      // juntas dos passeios
      g.strokeStyle = 'rgba(160,180,255,0.07)'; g.lineWidth = Math.max(1, k * 0.05);
      for (let p = -M; p <= M; p += 1.5) { g.beginPath(); g.moveTo(X(p), 0); g.lineTo(X(p), size); g.stroke(); g.beginPath(); g.moveTo(0, Z(p)); g.lineTo(size, Z(p)); g.stroke(); }
      for (const r of roads) for (const h of [true, false]) band(r.c - r.hw, r.c + r.hw, '#11131c', h);                         // asfalto
      // rasto dos pneus
      g.fillStyle = 'rgba(0,0,0,0.25)';
      for (const lane of [-5.6, -2.4, 2.4, 5.6]) { g.fillRect(0, Z(lane - 0.45), size, 0.9 * k); g.fillRect(X(lane - 0.45), 0, 0.9 * k, size); }
      // marcações
      const dash = (x0, z0, x1, z1, len, gap, col, w) => {
        g.strokeStyle = col; g.lineWidth = w * k; const L = Math.hypot(x1 - x0, z1 - z0), ux = (x1 - x0) / L, uz = (z1 - z0) / L;
        for (let d = 0; d < L; d += len + gap) { const e = Math.min(L, d + len); g.beginPath(); g.moveTo(X(x0 + ux * d), Z(z0 + uz * d)); g.lineTo(X(x0 + ux * e), Z(z0 + uz * e)); g.stroke(); }
      };
      for (const sg of [-1, 1]) {
        dash(sg * 15, -0.28, sg * M, -0.28, 1000, 0, 'rgba(255,200,60,0.85)', 0.16); dash(sg * 15, 0.28, sg * M, 0.28, 1000, 0, 'rgba(255,200,60,0.85)', 0.16);
        dash(-0.28, sg * 15, -0.28, sg * M, 1000, 0, 'rgba(255,200,60,0.85)', 0.16); dash(0.28, sg * 15, 0.28, sg * M, 1000, 0, 'rgba(255,200,60,0.85)', 0.16);
        for (const o of [-4, 4]) { dash(sg * 15, o, sg * M, o, 3, 3, 'rgba(235,240,255,0.7)', 0.14); dash(o, sg * 15, o, sg * M, 3, 3, 'rgba(235,240,255,0.7)', 0.14); }
        for (const o of [-7.6, 7.6]) { dash(sg * 15, o, sg * M, o, 1000, 0, 'rgba(235,240,255,0.5)', 0.12); dash(o, sg * 15, o, sg * M, 1000, 0, 'rgba(235,240,255,0.5)', 0.12); }
        // passadeiras (zebra) à entrada da praça
        g.fillStyle = 'rgba(235,240,255,0.72)';
        for (let o = -7.4; o < 7.5; o += 1.0) { g.fillRect(X(sg * 15.2 - 1.3), Z(o), 2.6 * k, 0.5 * k); g.fillRect(X(o), Z(sg * 15.2 - 1.3), 0.5 * k, 2.6 * k); }
      }
      for (const s of C.STREETS) for (const sg of [-1, 1]) { dash(-M, s * sg, M, s * sg, 3, 3, 'rgba(235,240,255,0.55)', 0.12); dash(s * sg, -M, s * sg, M, 3, 3, 'rgba(235,240,255,0.55)', 0.12); }
      // praça: piso de ladrilhos com raios e anéis
      const cx = X(0), cy = Z(0), pr = C.PLAZA * k;
      g.save(); g.beginPath(); g.arc(cx, cy, pr, 0, Math.PI * 2); g.clip();
      const gr = g.createRadialGradient(cx, cy, pr * 0.3, cx, cy, pr); gr.addColorStop(0, '#1a2440'); gr.addColorStop(1, '#101626'); g.fillStyle = gr; g.fillRect(cx - pr, cy - pr, pr * 2, pr * 2);
      g.strokeStyle = 'rgba(120,170,255,0.16)'; g.lineWidth = Math.max(1, k * 0.06);
      for (let p = -C.PLAZA; p <= C.PLAZA; p += 2) { g.beginPath(); g.moveTo(X(p), Z(-C.PLAZA)); g.lineTo(X(p), Z(C.PLAZA)); g.stroke(); g.beginPath(); g.moveTo(X(-C.PLAZA), Z(p)); g.lineTo(X(C.PLAZA), Z(p)); g.stroke(); }
      g.strokeStyle = 'rgba(0,229,255,0.28)'; g.lineWidth = k * 0.1;
      for (const rr of [8.5, 10.5, 12.5]) { g.beginPath(); g.arc(cx, cy, rr * k, 0, Math.PI * 2); g.stroke(); }
      g.strokeStyle = 'rgba(255,43,214,0.3)';
      for (let i = 0; i < 16; i++) { const a = i * Math.PI / 8; g.beginPath(); g.moveTo(cx + Math.cos(a) * 7 * k, cy + Math.sin(a) * 7 * k); g.lineTo(cx + Math.cos(a) * 13.5 * k, cy + Math.sin(a) * 13.5 * k); g.stroke(); }
      g.restore();
      g.strokeStyle = '#2c4a8c'; g.lineWidth = k * 0.35; g.beginPath(); g.arc(cx, cy, pr - k * 0.2, 0, Math.PI * 2); g.stroke();
      // poças (reflexos) e tampas de esgoto
      for (let i = 0; i < 90; i++) {
        const x = R() * 2 * M - M, z = R() * 2 * M - M; if (Math.hypot(x, z) < 15) continue;
        const onRoad = Math.abs(x) < C.MAIN || Math.abs(z) < C.MAIN; if (!onRoad && R() < 0.7) continue;
        const rx = (1 + R() * 3) * k, ry = (0.6 + R() * 1.8) * k, pg = g.createRadialGradient(X(x), Z(z), 0, X(x), Z(z), rx);
        pg.addColorStop(0, 'rgba(150,170,255,0.20)'); pg.addColorStop(1, 'rgba(150,170,255,0)'); g.fillStyle = pg; g.save(); g.translate(X(x), Z(z)); g.scale(1, ry / rx); g.translate(-X(x), -Z(z)); g.beginPath(); g.arc(X(x), Z(z), rx, 0, Math.PI * 2); g.fill(); g.restore();
      }
      for (let i = 0; i < 14; i++) { const x = (R() < 0.5 ? -1 : 1) * (18 + R() * 70), z = (R() - 0.5) * 8; g.fillStyle = '#0a0b12'; g.beginPath(); g.arc(X(x), Z(z), 0.45 * k, 0, 7); g.fill(); g.beginPath(); g.arc(X(z), Z(x), 0.45 * k, 0, 7); g.fill(); }
    });
  }
  function billboardTex(ctex, i) {
    const cols = [['#00e5ff', '#ff2bd6'], ['#ff2bd6', '#7a3cff'], ['#2dff9a', '#00e5ff'], ['#ff6a3d', '#ff2bd6']][i % 4], txt = ['DARK KOMBAT', 'CYBERDRONE', 'NEO TOKYO', 'FIGHT NIGHT'][i % 4];
    return ctex(512, 288, (g, w, h) => {
      g.clearRect(0, 0, w, h);
      const gr = g.createLinearGradient(0, 0, w, h); gr.addColorStop(0, cols[0]); gr.addColorStop(1, cols[1]); g.globalAlpha = 0.28; g.fillStyle = gr; g.fillRect(0, 0, w, h); g.globalAlpha = 1;
      g.strokeStyle = cols[0]; g.lineWidth = 6; g.strokeRect(8, 8, w - 16, h - 16);
      g.strokeStyle = 'rgba(255,255,255,0.12)'; g.lineWidth = 1; for (let y = 14; y < h; y += 6) { g.beginPath(); g.moveTo(10, y); g.lineTo(w - 10, y); g.stroke(); }
      g.font = 'bold 76px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.shadowColor = cols[1]; g.shadowBlur = 24; g.fillStyle = '#ffffff'; g.fillText(txt, w / 2, h / 2 - 8);
      g.font = 'bold 30px sans-serif'; g.fillStyle = cols[0]; g.fillText('2077 · ' + ['ROUND 1', 'NEW MODEL', 'LIVE 24H', 'TONIGHT'][i % 4], w / 2, h / 2 + 62);
    });
  }

  // ---------------- construção THREE ----------------
  function toGeo(T, A, withUV) {
    const g = new T.BufferGeometry();
    g.setAttribute('position', new T.BufferAttribute(new Float32Array(A.pos), 3));
    g.setAttribute('color', new T.BufferAttribute(new Float32Array(A.col), 3));
    if (withUV) g.setAttribute('uv', new T.BufferAttribute(new Float32Array(A.uv), 2));
    return g;
  }

  /** Cria a cidade e devolve { update(t, dt), setLevel(l, reduce) }. env: { T, scene, ctex, dotTex, ground (nº de píxeis) } */
  function build(env) {
    const { T, scene: S, ctex, dotTex } = env, L = layout(20241), R = mulberry32(5), objs = [];
    const add = (o) => { S.add(o); objs.push(o); return o; };
    const city = { layout: L, builds: [], signMesh: null };

    // edifícios: 3 malhas (uma por variante de janelas), cada uma ordenada por distância
    const tile = { w: 19.2, h: 27.2 }, per = [newArrays(), newArrays(), newArrays()], cnt = [0, 0, 0];
    for (const b of L.boxes) { b.ou = R() * 4; pushBox(per[b.v], b, true, tile); cnt[b.v]++; }
    for (let v = 0; v < 3; v++) {
      const tex = windowTex(ctex, v); tex.wrapS = tex.wrapT = T.RepeatWrapping;
      const m = new T.Mesh(toGeo(T, per[v], true), new T.MeshBasicMaterial({ map: tex, vertexColors: true }));
      m.frustumCulled = false; add(m); city.builds.push({ mesh: m, boxes: cnt[v] });
    }
    // contornos néon dos telhados
    { const lp = [], lc = [], neon = [[0, 0.9, 1], [1, 0.2, 0.8], [0.5, 0.3, 1], [1, 0.45, 0.2], [0.2, 1, 0.6]];
      L.boxes.forEach((b, i) => {
        if (b.dist > 80 || R() < 0.55) return; const c = neon[i % neon.length], x0 = b.x - b.w / 2, x1 = b.x + b.w / 2, z0 = b.z - b.d / 2, z1 = b.z + b.d / 2, y = b.y0 + b.h + 0.05;
        const seg = [[x0, z0, x1, z0], [x1, z0, x1, z1], [x1, z1, x0, z1], [x0, z1, x0, z0]];
        for (const s of seg) { lp.push(s[0], y, s[1], s[2], y, s[3]); lc.push(c[0], c[1], c[2], c[0], c[1], c[2]); }
        if (b.h > 24 && R() < 0.5) { const ex = R() < 0.5 ? x0 : x1, ez = R() < 0.5 ? z0 : z1; lp.push(ex, b.y0 + 1, ez, ex, y, ez); lc.push(c[0], c[1], c[2], c[0], c[1], c[2]); }
      });
      const g = new T.BufferGeometry(); g.setAttribute('position', new T.BufferAttribute(new Float32Array(lp), 3)); g.setAttribute('color', new T.BufferAttribute(new Float32Array(lc), 3));
      const ln = new T.LineSegments(g, new T.LineBasicMaterial({ vertexColors: true })); ln.frustumCulled = false; add(ln); city.lines = ln; }

    // objectos escuros e brilhantes
    { const A = newArrays(); for (const p of L.props) pushBox(A, p, false); const m = new T.Mesh(toGeo(T, A, false), new T.MeshBasicMaterial({ vertexColors: true })); m.frustumCulled = false; add(m); }
    { const A = newArrays(); for (const p of L.glow) pushBox(A, p, false); const m = new T.Mesh(toGeo(T, A, false), new T.MeshBasicMaterial({ vertexColors: true })); m.frustumCulled = false; add(m); }

    // letreiros
    { const pos = [], uv = [], col = [], cw = 1 / SIGN_COLS, ch = 1 / SIGN_ROWS;
      for (const s of L.signs) {
        const rx = s.nz, rz = -s.nx, hw = s.w / 2, hh = s.h / 2, cu = (s.cell % SIGN_COLS) * cw, cv = 1 - (Math.floor(s.cell / SIGN_COLS) + 1) * ch;
        const P = [[s.x - rx * hw, s.y - hh, s.z - rz * hw], [s.x + rx * hw, s.y - hh, s.z + rz * hw], [s.x + rx * hw, s.y + hh, s.z + rz * hw], [s.x - rx * hw, s.y + hh, s.z - rz * hw]];
        const U = [[cu, cv], [cu + cw, cv], [cu + cw, cv + ch], [cu, cv + ch]];
        for (const i of [0, 1, 2, 0, 2, 3]) { pos.push(P[i][0], P[i][1], P[i][2]); uv.push(U[i][0], U[i][1]); col.push(1, 1, 1); }
      }
      const g = toGeo(T, { pos, uv, col }, true);
      const m = new T.Mesh(g, new T.MeshBasicMaterial({ map: signAtlas(ctex), vertexColors: true, transparent: true, depthWrite: false, side: T.DoubleSide }));
      m.frustumCulled = false; m.renderOrder = 2; add(m); city.signMesh = m; city.signCount = L.signs.length; }

    // poças de luz no chão (reflexo dos néons) e halos dos candeeiros
    { const pos = [], uv = [], col = [];
      const pool = (x, z, size, c, a) => { const h = size / 2; const P = [[x - h, z - h, 0, 0], [x + h, z - h, 1, 0], [x + h, z + h, 1, 1], [x - h, z + h, 0, 1]]; for (const i of [0, 1, 2, 0, 2, 3]) { pos.push(P[i][0], 0.045, P[i][1]); uv.push(P[i][2], P[i][3]); col.push(c[0] * a, c[1] * a, c[2] * a); } };
      const hexc = (h) => [parseInt(h.slice(1, 3), 16) / 255, parseInt(h.slice(3, 5), 16) / 255, parseInt(h.slice(5, 7), 16) / 255];
      for (const s of L.signs) if (Math.hypot(s.x, s.z) < 60) pool(s.x - s.nx * 5, s.z - s.nz * 5, 12, hexc(SIGN_TEXTS[s.cell][1]), 0.28);
      for (const l of L.lamps) pool(l[0], l[2], 7, l[3], 0.3);
      const g = toGeo(T, { pos, uv, col }, true);
      const m = new T.Mesh(g, new T.MeshBasicMaterial({ map: dotTex, vertexColors: true, transparent: true, depthWrite: false, blending: T.AdditiveBlending, side: T.DoubleSide })); m.frustumCulled = false; m.renderOrder = 1; add(m); city.pools = m; }
    { const n = L.lamps.length, p = new Float32Array(n * 3), c = new Float32Array(n * 3);
      L.lamps.forEach((l, i) => { p.set([l[0], l[1], l[2]], i * 3); c.set(l[3], i * 3); });
      const g = new T.BufferGeometry(); g.setAttribute('position', new T.BufferAttribute(p, 3)); g.setAttribute('color', new T.BufferAttribute(c, 3));
      const m = new T.Points(g, new T.PointsMaterial({ size: 2.6, map: dotTex, vertexColors: true, transparent: true, depthWrite: false, blending: T.AdditiveBlending, opacity: 0.85 })); m.frustumCulled = false; add(m); city.halos = m; }
    // luzes vermelhas de aviso (piscam)
    { const n = L.warn.length, p = new Float32Array(n * 3); L.warn.forEach((w, i) => p.set(w, i * 3));
      const g = new T.BufferGeometry(); g.setAttribute('position', new T.BufferAttribute(p, 3));
      city.warnMat = new T.PointsMaterial({ size: 1.8, map: dotTex, color: 0xff2020, transparent: true, depthWrite: false, blending: T.AdditiveBlending });
      const m = new T.Points(g, city.warnMat); m.frustumCulled = false; add(m); }

    // chão pintado (ruas, passeios, praça) + chão distante
    { const tex = groundTex(ctex, env.ground || 2048), M = C.MAP;
      const mat = new T.MeshLambertMaterial({ map: tex })   // Lambert: mais leve que PBR;
      const m = new T.Mesh(new T.PlaneGeometry(M * 2, M * 2), mat); m.rotation.x = -Math.PI / 2; m.position.y = -0.03; add(m); city.ground = m; city.groundMat = mat;
      const far = new T.Mesh(new T.CircleGeometry(420, 24), new T.MeshBasicMaterial({ color: 0x080a14 })); far.rotation.x = -Math.PI / 2; far.position.y = -0.06; add(far); }

    // carros estacionados
    const parts = carParts(), CA = newArrays(); for (const p of parts) pushBox(CA, p, false);
    const carGeo = toGeo(T, CA, false);
    { const n = L.cars.length, im = new T.InstancedMesh(carGeo, new T.MeshLambertMaterial({ vertexColors: true }), n), d = new T.Object3D();
      L.cars.forEach((c, i) => { d.position.set(c.x, 0, c.z); d.rotation.set(0, c.rot, 0); d.updateMatrix(); im.setMatrixAt(i, d.matrix); im.setColorAt(i, new T.Color(c.col[0], c.col[1], c.col[2])); });
      im.frustumCulled = false; add(im); city.parked = im; }
    // carros voadores nas avenidas
    { const N = 14, im = new T.InstancedMesh(carGeo, new T.MeshLambertMaterial({ vertexColors: true }), N), d = new T.Object3D(), cars = [];
      const pal = [[1, 0.2, 0.75], [0.1, 0.8, 1], [0.9, 0.9, 1], [0.5, 0.3, 1], [1, 0.55, 0.2]];
      for (let i = 0; i < N; i++) {
        const axis = i % 2, lane = (R() < 0.5 ? -1 : 1) * (2.5 + R() * 3.5), dir = R() < 0.5 ? -1 : 1;
        cars.push({ axis, lane, dir, y: 9 + R() * 18, v: 7 + R() * 7, p0: R() * 240 - 120 }); im.setColorAt(i, new T.Color(pal[i % 5][0], pal[i % 5][1], pal[i % 5][2]));
      }
      const gp = new Float32Array(N * 3), gc = new Float32Array(N * 3); cars.forEach((c, i) => gc.set(pal[i % 5], i * 3));
      const gg = new T.BufferGeometry(); gg.setAttribute('position', new T.BufferAttribute(gp, 3)); gg.setAttribute('color', new T.BufferAttribute(gc, 3));
      const glow = new T.Points(gg, new T.PointsMaterial({ size: 5, map: dotTex, vertexColors: true, transparent: true, depthWrite: false, blending: T.AdditiveBlending, opacity: 0.8 }));
      im.frustumCulled = false; glow.frustumCulled = false; add(im); add(glow);
      city.fly = { im, glow, cars, d, gp }; }
    // painéis holográficos
    city.boards = [];
    [[0, 24, -66], [66, 26, 0], [0, 25, 66], [-66, 23, 0]].forEach((p, i) => {
      const m = new T.Mesh(new T.PlaneGeometry(20, 11.25), new T.MeshBasicMaterial({ map: billboardTex(ctex, i), transparent: true, opacity: 0.8, depthWrite: false, blending: T.AdditiveBlending, side: T.DoubleSide }));
      m.position.set(p[0], p[1], p[2]); m.lookAt(0, p[1], 0); m.renderOrder = 3; add(m); city.boards.push(m);
    });

    // ---- actualização por frame e nível de qualidade ----
    city.level = 2; city.reduce = false;
    city.setLevel = function (l, reduce, frac, extras) {
      this.level = l; this.reduce = !!reduce;
      const f = frac == null ? [0.5, 0.8, 1][l] : frac;
      for (const b of this.builds) b.mesh.geometry.setDrawRange(0, Math.max(1, Math.floor(b.boxes * f)) * 30);
      this.signMesh.geometry.setDrawRange(0, Math.floor(this.signCount * (l === 0 ? 0.5 : 1)) * 6);
      const ex = extras == null ? l > 1 : !!extras;   // extras (carros voadores, painéis, halos, poças) só no nível ALTO
      this.fly.im.visible = this.fly.glow.visible = ex;
      this.boards.forEach((b) => { b.visible = ex; });
      this.halos.visible = ex; this.pools.visible = l > 0; this.parked.visible = l > 0; this.lines.visible = l > 0;
    };
    city.update = function (t) {
      this.warnMat.opacity = 0.35 + 0.65 * (Math.sin(t * 2.4) > 0.2 ? 1 : 0.15);
      if (this.reduce) return;
      this.signMesh.material.opacity = 0.9 + 0.1 * Math.sin(t * 23) * (Math.sin(t * 1.7) > 0.93 ? 1 : 0.2);
      this.boards.forEach((b, i) => { b.material.opacity = 0.72 + 0.1 * Math.sin(t * 1.3 + i) + (Math.sin(t * 9 + i * 3) > 0.985 ? -0.3 : 0); });
      if (!this.fly.im.visible) return;
      const F = this.fly, d = F.d;
      F.cars.forEach((c, i) => {
        let p = ((c.p0 + c.dir * c.v * t) % 240 + 360) % 240 - 120;
        const x = c.axis === 0 ? p : c.lane, z = c.axis === 0 ? c.lane : p;
        d.position.set(x, c.y, z); d.rotation.set(0, c.axis === 0 ? (c.dir > 0 ? 0 : Math.PI) : (c.dir > 0 ? -Math.PI / 2 : Math.PI / 2), 0); d.updateMatrix(); F.im.setMatrixAt(i, d.matrix);
        F.gp[i * 3] = x; F.gp[i * 3 + 1] = c.y - 0.5; F.gp[i * 3 + 2] = z;
      });
      F.im.instanceMatrix.needsUpdate = true; F.glow.geometry.attributes.position.needsUpdate = true;
    };
    city.setLevel(2, false);
    return city;
  }

  DK.City = { C, layout, build, pushBox, newArrays, carParts, SIGN_TEXTS, SIGN_COLS, SIGN_ROWS, mulberry32 };
})();
