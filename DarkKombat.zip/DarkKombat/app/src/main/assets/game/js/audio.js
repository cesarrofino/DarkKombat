/* Dark Kombat - áudio (Web Audio API; todos os ficheiros WAV vêm do APK). */
(function () {
  const DK = (globalThis.DK = globalThis.DK || {});
  const SFX = ['punch', 'kick', 'block', 'hit', 'special', 'whoosh', 'win', 'lose', 'click', 'beep', 'go', 'ko'];
  const MUSIC = ['music_menu', 'music_fight'];

  const A = {
    ctx: null, buf: {}, mus: null, musName: null, ready: false,
    init() {
      if (this.ctx) return;
      const AC = globalThis.AudioContext || globalThis.webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.mg = this.ctx.createGain(); this.sg = this.ctx.createGain();
      this.mg.connect(this.ctx.destination); this.sg.connect(this.ctx.destination);
      this.applyVolumes();
    },
    unlock() { this.init(); if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume(); },
    applyVolumes() {
      if (!this.ctx) return;
      this.mg.gain.value = DK.Settings.data.music * 0.55;
      this.sg.gain.value = DK.Settings.data.sfx;
    },
    decode(ab) {
      return new Promise((res, rej) => { const p = this.ctx.decodeAudioData(ab, res, rej); if (p && p.catch) p.catch(rej); });
    },
    async load(onProgress) {
      this.init();
      const all = SFX.concat(MUSIC); let n = 0;
      for (const name of all) {
        try {
          if (this.ctx) {
            const r = await fetch('audio/' + name + '.wav');
            this.buf[name] = await this.decode(await r.arrayBuffer());
          }
        } catch (e) { /* o jogo continua sem este som */ }
        n++; if (onProgress) onProgress(n / all.length);
      }
      this.ready = true;
    },
    sfx(name, vol, rate) {
      if (!this.ctx || !this.buf[name] || DK.Settings.data.sfx <= 0) return;
      const s = this.ctx.createBufferSource(), g = this.ctx.createGain();
      s.buffer = this.buf[name]; s.playbackRate.value = (rate || 1) * (0.96 + Math.random() * 0.08);
      g.gain.value = vol == null ? 1 : vol; s.connect(g); g.connect(this.sg); s.start();
    },
    music(name) {
      if (!this.ctx || this.musName === name) return;
      this.stopMusic();
      if (!name || !this.buf[name]) return;
      const s = this.ctx.createBufferSource(), g = this.ctx.createGain();
      s.buffer = this.buf[name]; s.loop = true; g.gain.value = 0;
      s.connect(g); g.connect(this.mg); s.start();
      g.gain.linearRampToValueAtTime(1, this.ctx.currentTime + 0.8);
      this.mus = { s, g }; this.musName = name;
    },
    stopMusic() {
      if (!this.mus || !this.ctx) { this.musName = null; return; }
      const m = this.mus, t = this.ctx.currentTime;
      try { m.g.gain.cancelScheduledValues(t); m.g.gain.setValueAtTime(m.g.gain.value, t); m.g.gain.linearRampToValueAtTime(0, t + 0.4); m.s.stop(t + 0.45); } catch (e) { /* ignora */ }
      this.mus = null; this.musName = null;
    },
    suspend() { if (this.ctx && this.ctx.state === 'running') this.ctx.suspend(); },
    resume() { if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume(); }
  };
  DK.Audio = A;
})();
