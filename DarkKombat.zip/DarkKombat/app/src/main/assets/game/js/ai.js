/* Dark Kombat - inteligência artificial. Gera apenas "entradas" (como um jogador) e respeita todas as regras do motor. */
(function () {
  const DK = (globalThis.DK = globalThis.DK || {});
  const LEVELS = {
    easy:   { react: 0.55, block: 0.12, aggr: 0.35, combo: 0.15, special: 0.15, think: 0.55, name: 'FÁCIL' },
    normal: { react: 0.30, block: 0.30, aggr: 0.60, combo: 0.40, special: 0.40, think: 0.35, name: 'NORMAL' },
    hard:   { react: 0.14, block: 0.55, aggr: 0.85, combo: 0.70, special: 0.65, think: 0.20, name: 'DIFÍCIL' }
  };

  class AI {
    constructor(level, rng) {
      this.p = LEVELS[level] || LEVELS.normal;
      this.rng = rng || Math.random;
      this.t = 0; this.nextThink = 0.4; this.mv = 0; this.mvUntil = 0;
      this.seenAtk = false; this.atkAt = 0; this.blockDecision = false; this.blockUntil = 0;
      this.followAt = -1; this.followKey = null; this.history = []; this.retreatUntil = 0;
      this.wantAct = null;
    }

    pickAction(me, dist) {
      const p = this.p, w = { P: 3, K: 2.2, W: 1.2, S: 0, B: 0.6 };
      if (me.en >= DK.Sim.SPECIAL_COST && dist < 2.2) w.S = 2.5 * p.special;
      const last = this.history[this.history.length - 1], prev = this.history[this.history.length - 2];
      if (last) w[last] *= 0.45;            // evita repetir sempre o mesmo golpe
      if (last && last === prev) w[last] *= 0.3;
      let total = 0; for (const k in w) total += w[k];
      let r = this.rng() * total;
      for (const k in w) { r -= w[k]; if (r <= 0) return k; }
      return 'P';
    }

    /** me/op: lutadores do motor (só leitura). Devolve {mx,p,k,s,b}. */
    think(me, op, match, dt) {
      const inp = { mx: 0, p: 0, k: 0, s: 0, b: 0 };
      if (match.phase !== 'fight') { this.seenAtk = false; return inp; }
      this.t += dt;
      const p = this.p;
      const dx = op.x - me.x, dist = Math.abs(dx), dir = dx >= 0 ? 1 : -1;
      const busy = DK.Sim.isAttack(me.state) || me.state === 'hit' || me.state === 'down' || me.state === 'getup' || me.state === 'dodge';

      // reacção aos ataques do adversário (com atraso de reacção da dificuldade)
      const opAtk = DK.Sim.isAttack(op.state);
      if (opAtk && !this.seenAtk) { this.seenAtk = true; this.atkAt = this.t; this.blockDecision = this.rng() < p.block; }
      if (!opAtk) this.seenAtk = false;
      if (opAtk && this.blockDecision && this.t - this.atkAt >= p.react && dist < 2.7 && !busy) {
        this.blockUntil = this.t + 0.45; this.blockDecision = false;
      }
      if (this.t < this.blockUntil && !busy) { inp.b = 1; return inp; }

      // seguimento de combo planeado
      if (this.followKey && this.t >= this.followAt) {
        if (DK.Sim.isAttack(me.state) && me.hitDone) {
          if (this.followKey === 'P') inp.p = 1; else if (this.followKey === 'K') inp.k = 1; else inp.s = 1;
        }
        this.followKey = null;
      }
      if (DK.Sim.isAttack(me.state) && me.hitDone && !this.followKey && this.rng() < p.combo * dt * 8) {
        const options = me.en >= DK.Sim.SPECIAL_COST_COMBO && me.chain.join('').slice(-2) === 'PP' ? ['P', 'K', 'S'] : ['P', 'K'];
        this.followKey = options[Math.floor(this.rng() * options.length)];
        this.followAt = this.t + p.react * 0.35;
      }

      if (busy) { return inp; }

      // pouca vida: recuar
      if (me.hp / me.maxHp < 0.25 && this.t > this.retreatUntil && this.rng() < 0.012) {
        this.retreatUntil = this.t + 0.9 + this.rng() * 0.8;
      }
      if (this.t < this.retreatUntil && Math.abs(me.x) < DK.Sim.ARENA - 0.6) { inp.mx = -dir; return inp; }

      // decisões periódicas
      if (this.t >= this.nextThink) {
        this.nextThink = this.t + p.think * (0.7 + this.rng() * 0.6);
        const reach = 1.25;
        if (dist > reach + 0.15) {
          this.mv = this.rng() < 0.25 + 0.7 * p.aggr ? dir : 0;
          this.mvUntil = this.t + p.think;
          this.wantAct = null;
        } else if (this.rng() < 0.35 + 0.6 * p.aggr) {
          const a = this.pickAction(me, dist);
          this.history.push(a); if (this.history.length > 4) this.history.shift();
          if (a === 'W') { this.mv = -dir; this.mvUntil = this.t + 0.35; }
          else if (a === 'B') { this.blockUntil = this.t + 0.4; }
          else this.wantAct = a;
        } else { this.mv = 0; this.mvUntil = this.t + 0.2; }
      }
      if (this.wantAct) {
        const a = this.wantAct; this.wantAct = null;
        if (a === 'P') inp.p = 1; else if (a === 'K') inp.k = 1; else if (a === 'S') inp.s = 1;
        return inp;
      }
      if (this.t < this.mvUntil) inp.mx = this.mv;
      return inp;
    }
  }

  DK.AI = AI;
  DK.AI_LEVELS = LEVELS;
})();
