/* Dark Kombat - motor de combate (lógica pura, sem gráficos). Corre em browser e em Node (testes). */
(function () {
  const DK = (globalThis.DK = globalThis.DK || {});
  const ARENA = 5.3, MIN_DIST = 0.95, ROUND_TIME = 60, WINS_NEEDED = 2, MAX_EN = 100;
  const STATES = ['idle', 'walk', 'punchL', 'punchR', 'kickF', 'kickH', 'special', 'block', 'dodge', 'hit', 'down', 'getup', 'win', 'lose'];
  const SI = {}; STATES.forEach((s, i) => { SI[s] = i; });
  const PHASES = ['countdown', 'fight', 'roundEnd', 'matchEnd'];
  const KIND_ID = { punchL: 0, punchR: 1, kickF: 2, kickH: 3, special: 4 };

  // su = arranque, ac = fase activa (pode causar dano), rc = recuperação (segundos, antes do factor de velocidade)
  const MOVES = {
    punchL: { su: 0.045, ac: 0.07, rc: 0.11, range: 1.25, dmg: 6, stun: 0.22, push: 0.12, gain: 7, kind: 'P' },
    punchR: { su: 0.055, ac: 0.07, rc: 0.13, range: 1.30, dmg: 7, stun: 0.24, push: 0.15, gain: 8, kind: 'P' },
    // kickF = mawashi-geri (pontapé circular de karaté); kickH = ushiro-mawashi-geri (meia-volta de 360° com pontapé)
    kickF: { su: 0.10, ac: 0.09, rc: 0.17, range: 1.65, dmg: 9, stun: 0.28, push: 0.30, gain: 9, kind: 'K' },
    kickH: { su: 0.21, ac: 0.10, rc: 0.20, range: 1.80, dmg: 13, stun: 0.34, push: 0.50, gain: 10, kind: 'K' },
    special: { su: 0.22, ac: 0.20, rc: 0.36, range: 2.50, dmg: 26, stun: 0.60, push: 1.90, gain: 0, kind: 'S', knock: true }
  };
  const COMBOS = {
    PP: { name: 'DUPLO SOCO', mult: 1.15 }, PK: { name: 'SOCO + CHUTE', mult: 1.2 },
    KK: { name: 'CHUTE DUPLO', mult: 1.2 }, PPS: { name: 'COMBO FINAL', mult: 1.5 }
  };
  const SPECIAL_COST = 50, SPECIAL_COST_COMBO = 30;

  const FIGHTERS = {
    kira: {
      id: 'kira', name: 'KIRA', level: 12, hp: 100, str: 0.9, spd: 1.18, def: 0.9, atk: 0.82, dodgeCd: 0.6,
      stats: { str: 6, spd: 9, def: 5 }, style: 'Ágil · ataques rápidos e boa esquiva',
      colors: { a: 0xff2bd6, b: 0x00e5ff, skin: 0xd9a47c, hair: 0x1a0f2e }
    },
    ren: {
      id: 'ren', name: 'REN', level: 14, hp: 120, str: 1.2, spd: 0.9, def: 1.25, atk: 1.08, dodgeCd: 1.3,
      stats: { str: 9, spd: 5, def: 9 }, style: 'Força bruta · golpes poderosos e defesa sólida',
      colors: { a: 0x2d8bff, b: 0x2dff9a, skin: 0xb98562, hair: 0x0b0b12 }
    }
  };

  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const isAttack = (s) => !!MOVES[s];

  function makeFighter(def, idx) {
    return {
      def, idx, id: def.id, name: def.name, maxHp: def.hp, hp: def.hp, en: 0, x: 0, face: 1, vx: 0,
      state: 'idle', st: 0, str: def.str, spd: def.spd, defn: def.def, atk: def.atk,
      hitDone: false, side: 0, chain: [], chainT: 0, mult: 1, comboName: '', buf: null, bufT: 0,
      dodgeCd: 0, juggle: 0, prevB: 0, stun: 0, combo: 0, comboHitT: 0, ko: false,
      stats: { hits: 0, dmg: 0, maxCombo: 0, blocks: 0 }
    };
  }

  function moveTimes(state, def) {
    const m = MOVES[state];
    if (!m) return null;
    return { su: m.su * def.atk, ac: m.ac * def.atk, rc: m.rc * def.atk };
  }

  class Match {
    constructor(defA, defB) {
      this.f = [makeFighter(defA, 0), makeFighter(defB, 1)];
      this.round = 1; this.wins = [0, 0]; this.events = []; this.elapsed = 0;
      this.matchWinner = -2; this.order = 1;
      this.resetRound(true);
    }

    emit(e) { this.events.push(e); }
    drain() { const e = this.events; this.events = []; return e; }

    resetRound(first) {
      const [a, b] = this.f;
      a.x = -1.6; b.x = 1.6; a.face = 1; b.face = -1; this.order = 1;
      for (const f of this.f) {
        f.hp = f.maxHp; f.en = first ? 0 : f.en * 0.5; f.state = 'idle'; f.st = 0; f.vx = 0; f.chain.length = 0;
        f.chainT = 0; f.buf = null; f.bufT = 0; f.juggle = 0; f.stun = 0; f.combo = 0; f.comboHitT = 0;
        f.hitDone = false; f.ko = false; f.dodgeCd = 0; f.prevB = 0;
      }
      this.time = ROUND_TIME; this.phase = 'countdown'; this.phaseT = 0; this.cd = 3; this.cdSent = -1;
    }

    invul(f) {
      return f.state === 'down' || f.state === 'getup' || f.state === 'win' || f.state === 'lose' ||
        (f.state === 'dodge' && f.st < 0.16);
    }

    step(dt, in0, in1) {
      this.phaseT += dt;
      const [a, b] = this.f;
      if (this.phase === 'countdown') {
        const n = Math.max(0, 3 - Math.floor(this.phaseT / 0.7));
        if (n !== this.cdSent) { this.cdSent = n; this.cd = n; this.emit({ t: 'cd', n }); }
        if (this.phaseT >= 3 * 0.7 + 0.45) { this.phase = 'fight'; this.phaseT = 0; this.cd = 0; }
        this.update(a, b, null, dt, false); this.update(b, a, null, dt, false);
      } else if (this.phase === 'fight') {
        this.time = Math.max(0, this.time - dt); this.elapsed += dt;
        this.update(a, b, in0, dt, true); this.update(b, a, in1, dt, true);
        this.resolve();
        if (a.hp <= 0 || b.hp <= 0 || this.time <= 0) this.endRound();
      } else if (this.phase === 'roundEnd') {
        this.update(a, b, null, dt, false); this.update(b, a, null, dt, false);
        this.resolve();
        if (this.phaseT > 3.0) {
          if (Math.max(this.wins[0], this.wins[1]) >= WINS_NEEDED) this.endMatch();
          else { this.round++; this.resetRound(false); }
        }
      } else {
        this.update(a, b, null, dt, false); this.update(b, a, null, dt, false);
      }
    }

    endRound() {
      const [a, b] = this.f;
      let w; const ko = (a.hp <= 0 || b.hp <= 0) ? 1 : 0;
      if (a.hp <= 0 && b.hp <= 0) w = -1;
      else if (a.hp <= 0) w = 1;
      else if (b.hp <= 0) w = 0;
      else {
        const pa = a.hp / a.maxHp, pb = b.hp / b.maxHp;
        w = Math.abs(pa - pb) < 0.0005 ? -1 : (pa > pb ? 0 : 1);
      }
      if (w >= 0) this.wins[w]++; else { this.wins[0]++; this.wins[1]++; }
      for (const f of this.f) {
        if (f.hp <= 0) { f.ko = true; if (f.state !== 'down') { f.state = 'down'; f.st = 0; } }
        else if (w === f.idx) { f.state = 'win'; f.st = 0; }
        else { f.state = 'lose'; f.st = 0; }
      }
      this.phase = 'roundEnd'; this.phaseT = 0;
      this.emit({ t: 'round', win: w, ko, w: [this.wins[0], this.wins[1]] });
    }

    endMatch() {
      const [w0, w1] = this.wins;
      this.matchWinner = w0 > w1 ? 0 : (w1 > w0 ? 1 : -1);
      this.phase = 'matchEnd'; this.phaseT = 0;
      this.emit({
        t: 'match', win: this.matchWinner, dur: Math.round(this.elapsed),
        st: this.f.map((f) => [f.stats.hits, Math.round(f.stats.dmg), f.stats.maxCombo, f.stats.blocks])
      });
    }

    buffer(f, key) { f.buf = key; f.bufT = 0.26; }

    update(f, o, inp, dt, canAct) {
      f.st += dt;
      if (f.dodgeCd > 0) f.dodgeCd -= dt;
      if (f.chainT > 0) { f.chainT -= dt; if (f.chainT <= 0) f.chain.length = 0; }
      if (f.comboHitT > 0) { f.comboHitT -= dt; if (f.comboHitT <= 0) f.combo = 0; }
      if (f.bufT > 0) { f.bufT -= dt; if (f.bufT <= 0) f.buf = null; }
      if (canAct) f.en = Math.min(MAX_EN, f.en + 3 * dt);
      if (canAct && inp) {
        if (inp.p) this.buffer(f, 'P');
        if (inp.k) this.buffer(f, 'K');
        if (inp.s) this.buffer(f, 'S');
      }
      const mx = canAct && inp ? clamp(Math.round(inp.mx || 0), -1, 1) : 0;
      f.mxNow = mx;
      const bHeld = canAct && inp && inp.b ? 1 : 0;
      const bPress = bHeld && !f.prevB; f.prevB = bHeld;
      let vx = 0;
      const s = f.state;
      const mv = MOVES[s];

      if (mv) {
        const t = moveTimes(s, f.def), total = t.su + t.ac + t.rc;
        if (canAct && f.st >= t.su && f.st < t.su + t.ac && !f.hitDone) this.tryHit(f, o, mv);
        if (canAct && f.hitDone && f.st >= t.su + t.ac && f.buf) this.tryStart(f, f.buf);
        else if (f.st >= total) { if (!f.hitDone) f.chain.length = 0; this.setState(f, 'idle'); }
      } else if (s === 'hit') {
        if (f.st >= f.stun) { this.setState(f, 'idle'); f.juggle = 0; }
      } else if (s === 'down') {
        if (!f.ko && f.st >= 0.62 && this.phase === 'fight') this.setState(f, 'getup');
        f.vx *= 0.9;
      } else if (s === 'getup') {
        if (f.st >= 0.38) { this.setState(f, 'idle'); f.juggle = 0; }
      } else if (s === 'dodge') {
        vx = -f.face * 11 * clamp(1 - f.st / 0.22, 0, 1);
        if (f.st >= 0.22) this.setState(f, 'idle');
      } else if (s === 'win' || s === 'lose') {
        /* mantém a pose */
      } else if (canAct) { // idle | walk | block
        if (bPress && mx * f.face < 0 && f.dodgeCd <= 0) {
          this.setState(f, 'dodge'); f.dodgeCd = f.def.dodgeCd * 0.7 + 0.2; f.buf = null;
        } else if (f.buf && this.tryStart(f, f.buf)) {
          /* começou ataque */
        } else if (bHeld) {
          if (f.state !== 'block') this.setState(f, 'block');
        } else {
          if (f.state === 'block') this.setState(f, 'idle');
          vx = mx * 5.2 * f.spd;
          const ns = mx !== 0 ? 'walk' : 'idle';
          if (f.state !== ns) { f.state = ns; f.st = 0; }
        }
      } else if (f.state === 'walk') { f.state = 'idle'; f.st = 0; }

      f.vx = vx !== 0 ? vx : (f.state === 'down' ? f.vx : 0);
      f.x += f.vx * dt;
      f.x = clamp(f.x, -ARENA, ARENA);
    }

    setState(f, s) { f.state = s; f.st = 0; if (MOVES[s]) f.hitDone = false; }

    /** Tenta iniciar um ataque (a partir do repouso, ou a cancelar a recuperação de um golpe que acertou). */
    tryStart(f, key) {
      const inChain = f.chainT > 0 && f.chain.length > 0;
      if (key === 'S') {
        const cost = (inChain && f.chain.join('').slice(-2) === 'PP') ? SPECIAL_COST_COMBO : SPECIAL_COST;
        if (f.en < cost) { f.buf = null; return false; }
        f.en -= cost;
      }
      if (!inChain) f.chain.length = 0;
      f.chain.push(key); if (f.chain.length > 3) f.chain.shift();
      f.chainT = 0.6;
      const c3 = f.chain.slice(-3).join(''), c2 = f.chain.slice(-2).join('');
      f.mult = 1; f.comboName = '';
      if (f.chain.length >= 3 && COMBOS[c3]) { f.mult = COMBOS[c3].mult; f.comboName = COMBOS[c3].name; }
      else if (f.chain.length >= 2 && COMBOS[c2]) { f.mult = COMBOS[c2].mult; f.comboName = COMBOS[c2].name; }
      else if (f.chain.length > 1) f.mult = 1 + 0.08 * (f.chain.length - 1);
      let st;
      if (key === 'P') { st = f.side ? 'punchR' : 'punchL'; f.side ^= 1; }
      else if (key === 'K') st = (inChain || (f.mxNow || 0) * f.face < 0) ? 'kickH' : 'kickF';   // em combo, ou a recuar: meia-volta
      else st = 'special';
      f.buf = null;
      this.setState(f, st);
      this.emit({ t: 'swing', who: f.idx, s: st });
      return true;
    }

    tryHit(a, d, mv) {
      const dx = (d.x - a.x) * a.face;
      if (dx < -0.15 || dx > mv.range) return;
      if (this.invul(d)) return;
      a.hitDone = true; a.chainT = Math.max(a.chainT, 0.5);
      const blocked = d.state === 'block';
      let dmg = mv.dmg * a.str * a.mult / Math.sqrt(d.defn);
      const kind = KIND_ID[a.state];
      if (blocked) {
        dmg *= (mv.kind === 'S' ? 0.45 : 0.15);
        d.stats.blocks++; d.en = Math.min(MAX_EN, d.en + 3);
        d.x += a.face * mv.push * 0.4;
        a.en = Math.min(MAX_EN, a.en + mv.gain * 0.3);
      } else {
        a.stats.hits++; a.combo++; a.comboHitT = 1.2;
        if (a.combo > a.stats.maxCombo) a.stats.maxCombo = a.combo;
        a.en = Math.min(MAX_EN, a.en + mv.gain);
        d.en = Math.min(MAX_EN, d.en + dmg * 0.25);
      }
      dmg = Math.round(dmg * 10) / 10;
      d.hp = Math.max(0, d.hp - dmg);
      a.stats.dmg += dmg;
      if (!blocked) {
        d.x += a.face * mv.push;
        d.juggle++; d.chain.length = 0; d.chainT = 0; d.buf = null;
        if (mv.knock || d.hp <= 0 || d.juggle >= 3) { d.ko = d.hp <= 0; this.setState(d, 'down'); d.vx = a.face * 2; }
        else { this.setState(d, 'hit'); d.stun = mv.stun; }
      }
      this.emit({
        t: 'hit', who: d.idx, att: a.idx, dmg, blocked: blocked ? 1 : 0, k: kind, c: blocked ? 0 : a.combo,
        name: a.comboName, x: d.x
      });
    }

    /** Impede atravessar e sair da arena; mantém a ordem esquerda/direita. */
    resolve() {
      const [a, b] = this.f;
      const l = this.order > 0 ? a : b, r = this.order > 0 ? b : a;
      l.x = clamp(l.x, -ARENA, ARENA); r.x = clamp(r.x, -ARENA, ARENA);
      if (r.x - l.x < MIN_DIST) {
        const mid = (l.x + r.x) / 2;
        l.x = mid - MIN_DIST / 2; r.x = mid + MIN_DIST / 2;
        if (l.x < -ARENA) { l.x = -ARENA; r.x = -ARENA + MIN_DIST; }
        if (r.x > ARENA) { r.x = ARENA; l.x = ARENA - MIN_DIST; }
      }
    }

    snapshot() {
      const row = (f) => [Math.round(f.x * 100) / 100, Math.round(f.hp * 10) / 10, Math.round(f.en), SI[f.state], Math.round(f.st * 100) / 100];
      return { ph: PHASES.indexOf(this.phase), cd: this.cd, tm: Math.round(this.time * 10) / 10, r: this.round, w: [this.wins[0], this.wins[1]], f: [row(this.f[0]), row(this.f[1])] };
    }
  }

  /** Vista do lado cliente: reflecte o estado autoritativo recebido do anfitrião. */
  class Mirror {
    constructor(defA, defB) {
      this.f = [makeFighter(defA, 0), makeFighter(defB, 1)];
      this.f[0].face = 1; this.f[1].face = -1; this.f[0].x = -1.6; this.f[1].x = 1.6;
      this.f.forEach((f) => { f.tx = f.x; });
      this.round = 1; this.wins = [0, 0]; this.time = ROUND_TIME; this.phase = 'countdown'; this.cd = 3;
      this.phaseT = 0; this.events = []; this.matchWinner = -2; this.got = false;
    }
    emit(e) { this.events.push(e); }
    drain() { const e = this.events; this.events = []; return e; }
    apply(s) {
      const prevCd = this.cd, prevPhase = this.phase;
      this.phase = PHASES[s.ph]; this.cd = s.cd; this.time = s.tm; this.round = s.r; this.wins = s.w.slice();
      for (let i = 0; i < 2; i++) {
        const f = this.f[i], r = s.f[i], ns = STATES[r[3]];
        f.tx = r[0]; f.hp = r[1]; f.en = r[2];
        if (!this.got || Math.abs(f.tx - f.x) > 1.5) f.x = f.tx;
        if (ns !== f.state) {
          f.state = ns; f.st = r[4];
          if (MOVES[ns]) this.emit({ t: 'swing', who: i, s: ns });
        } else if (Math.abs(f.st - r[4]) > 0.12) f.st = r[4];
      }
      this.got = true;
      if (this.phase === 'countdown' && (prevCd !== this.cd || prevPhase !== 'countdown')) this.emit({ t: 'cd', n: this.cd });
    }
    step(dt) {
      for (const f of this.f) {
        f.st += dt;
        const nx = f.x + (f.tx - f.x) * Math.min(1, dt * 16);
        f.vx = dt > 0 ? (nx - f.x) / dt : 0;
        f.x = nx;
      }
    }
  }

  DK.Sim = {
    Match, Mirror, FIGHTERS, MOVES, COMBOS, STATES, SI, PHASES, ARENA, MIN_DIST, ROUND_TIME,
    SPECIAL_COST, SPECIAL_COST_COMBO, isAttack, moveTimes, makeFighter
  };
})();
