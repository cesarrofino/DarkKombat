/* Dark Kombat - controlos tácteis (joystick + 4 botões, multi-toque) e teclado para testes em PC. */
(function () {
  const DK = (globalThis.DK = globalThis.DK || {});
  const I = {
    mx: 0, b: 0, edges: { p: 0, k: 0, s: 0 }, enabled: false, joyId: null, el: null, kb: { l: 0, r: 0, b: 0 },
    onPress: null,
    init() {
      const joy = document.getElementById('joy'), knob = document.getElementById('joyKnob');
      this.el = joy;
      const upd = (e) => {
        const r = joy.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
        let dx = e.clientX - cx, dy = e.clientY - cy; const max = r.width * 0.36, len = Math.hypot(dx, dy) || 1;
        if (len > max) { dx = dx / len * max; dy = dy / len * max; }
        knob.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
        const thr = max * 0.4 / Math.max(0.6, DK.Settings.data.joy);
        this.mx = dx > thr ? 1 : dx < -thr ? -1 : 0;
      };
      const end = () => { this.joyId = null; this.mx = 0; knob.style.transform = 'translate(0,0)'; };
      joy.addEventListener('pointerdown', (e) => { e.preventDefault(); this.joyId = e.pointerId; try { joy.setPointerCapture(e.pointerId); } catch (x) { /* ok */ } upd(e); });
      joy.addEventListener('pointermove', (e) => { if (e.pointerId === this.joyId) upd(e); });
      joy.addEventListener('pointerup', (e) => { if (e.pointerId === this.joyId) end(); });
      joy.addEventListener('pointercancel', (e) => { if (e.pointerId === this.joyId) end(); });
      joy.addEventListener('lostpointercapture', (e) => { if (e.pointerId === this.joyId) end(); });

      document.querySelectorAll('#actions [data-act]').forEach((btn) => {
        const act = btn.getAttribute('data-act'); let pid = null;
        const down = (e) => {
          e.preventDefault(); pid = e.pointerId; try { btn.setPointerCapture(pid); } catch (x) { /* ok */ }
          btn.classList.add('down');
          if (act === 'b') this.b = 1; else this.edges[act] = 1;
          if (this.onPress) this.onPress(act);
        };
        const up = (e) => { if (pid !== null && e.pointerId !== pid) return; pid = null; btn.classList.remove('down'); if (act === 'b') this.b = 0; };
        btn.addEventListener('pointerdown', down);
        btn.addEventListener('pointerup', up); btn.addEventListener('pointercancel', up); btn.addEventListener('lostpointercapture', up);
      });
      document.getElementById('hud').addEventListener('contextmenu', (e) => e.preventDefault());

      const map = { KeyA: 'l', ArrowLeft: 'l', KeyD: 'r', ArrowRight: 'r' };
      window.addEventListener('keydown', (e) => {
        if (!this.enabled || e.repeat) return;
        if (map[e.code]) this.kb[map[e.code]] = 1;
        else if (e.code === 'KeyJ') { this.edges.p = 1; if (this.onPress) this.onPress('p'); }
        else if (e.code === 'KeyK') { this.edges.k = 1; if (this.onPress) this.onPress('k'); }
        else if (e.code === 'KeyU' || e.code === 'KeyI') { this.edges.s = 1; if (this.onPress) this.onPress('s'); }
        else if (e.code === 'KeyL' || e.code === 'Space') this.kb.b = 1;
      });
      window.addEventListener('keyup', (e) => {
        if (map[e.code]) this.kb[map[e.code]] = 0; else if (e.code === 'KeyL' || e.code === 'Space') this.kb.b = 0;
      });
    },
    reset() {
      this.mx = 0; this.b = 0; this.edges.p = this.edges.k = this.edges.s = 0; this.kb.l = this.kb.r = this.kb.b = 0;
      this.joyId = null; const k = document.getElementById('joyKnob'); if (k) k.style.transform = 'translate(0,0)';
    },
    /** mx em coordenadas do ecrã (-1 esquerda, +1 direita). Consome os toques únicos. */
    read() {
      const o = { mx: this.mx || (this.kb.r - this.kb.l), p: this.edges.p, k: this.edges.k, s: this.edges.s, b: this.b || this.kb.b };
      this.edges.p = this.edges.k = this.edges.s = 0;
      return o;
    }
  };
  DK.Input = I;
})();
