/* Dark Kombat - lutadores 3D articulados (esqueleto de ossos com animação por poses + máquina de estados do motor).
   Usa os GLB articulados de assets/game/models (ver js/models.js e tools/build_glb.py). Se os GLB não estiverem
   carregados, cai para o modelo procedural embutido abaixo (ver docs/MODELOS.md). */
(function () {
  const DK = (globalThis.DK = globalThis.DK || {});
  const T = globalThis.THREE;
  const D2R = Math.PI / 180;
  const KEYS = ['hip', 'tz', 'ty', 'hz', 'by', 'rUA', 'rFA', 'lUA', 'lFA', 'rTh', 'rSh', 'lTh', 'lSh', 'rz', 'gl', 'lg'];
  const GUARD = { hip: 0, tz: -6, ty: 0, hz: 4, by: 0, rUA: 25, rFA: 105, lUA: 40, lFA: 95, rTh: -18, rSh: -22, lTh: 22, lSh: -28, rz: 0, gl: 0, lg: 0 };
  const P = (o) => Object.assign({}, GUARD, o);
  // Golpes: W = fim da preparação (antes de o golpe sair), PK = ponto de impacto.
  // kickF = mawashi-geri (pontapé circular de karaté): joelho sobe e abre, anca roda, perna estica à altura do tronco, tronco inclina-se para trás.
  // kickH = ushiro-mawashi-geri (meia-volta): o corpo gira 360° (ver spinAt) e a perna sai do giro, ao nível da cabeça.
  const W = {
    punchL: P({ lUA: 15, lFA: 140, ty: 12, by: 8 }),
    punchR: P({ rUA: 5, rFA: 145, ty: -20, by: -15 }),
    kickF: P({ rTh: 88, rSh: -122, tz: 6, by: -22, hz: -2, lTh: 8, lSh: -24, lUA: 62, lFA: 100, rUA: 30, rFA: 100 }),
    kickH: P({ rTh: 98, rSh: -128, tz: 12, by: -28, lTh: 10, lSh: -26, lUA: 70, lFA: 95, rUA: 35, rFA: 95 }),
    special: P({ rUA: -60, lUA: -60, rFA: 40, lFA: 40, tz: -22, by: -20, hip: -0.05, gl: 1 })
  };
  const PK = {
    punchL: P({ lUA: 90, lFA: 4, ty: -18, by: -12, tz: -12, lg: 0.12 }),
    punchR: P({ rUA: 92, rFA: 3, ty: 28, by: 22, tz: -14, lTh: 32, rTh: -30, lg: 0.14 }),
    kickF: P({ rTh: 118, rSh: -6, tz: 20, lg: 0.28, by: -10, hz: 6, lTh: 4, lSh: -16, lUA: 78, lFA: 88, rUA: -30, rFA: 70, hip: 0.02 }),
    kickH: P({ rTh: 138, rSh: -8, tz: 28, lg: 0.3, by: -12, hz: 12, lTh: 3, lSh: -14, lUA: 90, lFA: 80, rUA: -45, rFA: 60, hip: 0.03 }),
    special: P({ rUA: 95, lUA: 95, rFA: 2, lFA: 2, tz: -30, by: 10, hip: -0.05, lTh: 35, rTh: -30, gl: 1.6 })
  };
  const BLOCK = P({ rUA: 78, rFA: 128, lUA: 84, lFA: 122, tz: -14, rTh: -25, rSh: -35, lTh: 30, lSh: -45 });
  const DODGE = P({ tz: 28, hz: -8, rUA: -10, lUA: -5, rFA: 60, lFA: 60, rTh: -30, rSh: -50, lTh: 10, lSh: -60 });
  const HIT = P({ tz: 22, hz: 30, rUA: -25, lUA: -15, rFA: 40, lFA: 30, rTh: -5, lTh: 10, lSh: -15, rSh: -12 });
  const DOWN = P({ tz: 5, hz: 10, rUA: -30, lUA: -20, rFA: 20, lFA: 20, rTh: 5, lTh: 8, rSh: -8, lSh: -10, rz: 90 });
  const WIN = P({ rUA: 155, lUA: 150, rFA: 15, lFA: 20, tz: 6, hz: -10, rTh: -8, lTh: 8, rSh: -12, lSh: -12 });
  const LOSE = P({ tz: -35, hz: 35, rUA: 5, lUA: 5, rFA: 10, lFA: 10, rTh: 80, rSh: -120, lTh: 80, lSh: -120 });

  const lerpPose = (out, a, b, k) => { for (let i = 0; i < KEYS.length; i++) { const q = KEYS[i]; out[q] = a[q] + (b[q] - a[q]) * k; } };
  const copyPose = (out, a) => { for (let i = 0; i < KEYS.length; i++) out[KEYS[i]] = a[KEYS[i]]; };
  const ease = (x) => { x = x < 0 ? 0 : x > 1 ? 1 : x; return x * x * (3 - 2 * x); };

  /** Ângulo (graus) da meia-volta do pontapé giratório: 0 -> 360 durante a preparação e o início da fase activa. */
  function spinAt(f) {
    if (f.state !== 'kickH') return 0;
    const m = DK.Sim.moveTimes('kickH', f.def), T1 = m.su + m.ac * 0.35, u = Math.min(1, f.st / T1);
    return 360 * (u * u * (3 - 2 * u) * 0.35 + u * 0.65);   // arranque suave, velocidade alta no meio
  }

  /** Calcula a pose-alvo (graus) para o estado do lutador. Devolve true se for um ataque (sem suavização extra). */
  function targetPose(out, f, time, gait) {
    const s = f.state, t = f.st, mv = DK.Sim.MOVES[s];
    if (mv) {
      const m = DK.Sim.moveTimes(s, f.def);
      if (t < m.su) lerpPose(out, GUARD, W[s], ease(t / m.su));
      else if (t < m.su + m.ac) lerpPose(out, W[s], PK[s], (t - m.su) / m.ac);
      else lerpPose(out, PK[s], GUARD, ease((t - m.su - m.ac) / m.rc));
      return true;
    }
    if (s === 'block') copyPose(out, BLOCK);
    else if (s === 'dodge') copyPose(out, DODGE);
    else if (s === 'hit') { copyPose(out, HIT); out.tz += Math.sin(t * 30) * 2; }
    else if (s === 'down') { lerpPose(out, HIT, DOWN, ease(t / 0.28)); }
    else if (s === 'getup') { lerpPose(out, DOWN, GUARD, ease(t / 0.55)); }
    else if (s === 'win') { copyPose(out, WIN); out.hip = Math.abs(Math.sin(time * 4)) * 0.06; }
    else if (s === 'lose') copyPose(out, LOSE);
    else {
      copyPose(out, GUARD);
      out.hip = 0; out.tz += Math.sin(time * 2.2) * 1.4; out.rUA += Math.sin(time * 2.2 + 1) * 2; out.lUA += Math.sin(time * 2.2) * 2;
      const bob = 2.5 * (0.5 + 0.5 * Math.sin(time * 4.4)); out.rSh -= bob; out.lSh -= bob;   // saltitar de boxeador: joelhos a amortecer
      const mvx = f.vx * f.face; // >0 aproxima-se, <0 recua
      if (Math.abs(f.vx) > 0.3) {
        const sg = mvx >= 0 ? 1 : -1, g = (gait == null ? time * 14 : gait), w = Math.sin(g * sg), w2 = Math.sin(g * sg + Math.PI);
        out.lTh += 34 * w; out.rTh += 34 * w2; out.lSh -= 14 + 30 * Math.max(0, -w); out.rSh -= 14 + 30 * Math.max(0, -w2);
        out.tz += 3 * Math.abs(w) + (mvx >= 0 ? -7 : 4);     // inclina-se para a frente ao avançar (corrida de combate), para trás ao recuar
        out.hip -= 0.03; out.hip += 0.035 * Math.abs(Math.cos(g));   // salto da corrida
        out.rUA += 14 * w; out.lUA += 14 * w2;               // braços acompanham a passada
      }
    }
    return false;
  }

  const LEG_A = 0.45, LEG_B = 0.44;
  const legExt = (th, sh) => LEG_A * Math.cos(th) + LEG_B * Math.cos(th + sh);

  /** sombra suave (blob) — sempre barata. Devolve { stex, geo } para libertar depois. */
  function makeBlob(root, mats) {
    const sc = document.createElement('canvas'); sc.width = sc.height = 64;
    const sx = sc.getContext('2d'), gr = sx.createRadialGradient(32, 32, 2, 32, 32, 30);
    gr.addColorStop(0, 'rgba(0,0,0,0.65)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); sx.fillStyle = gr; sx.fillRect(0, 0, 64, 64);
    const stex = new T.CanvasTexture(sc); const smat = new T.MeshBasicMaterial({ map: stex, transparent: true, depthWrite: false });
    const geo = new T.PlaneGeometry(1.5, 1.5);
    const blob = new T.Mesh(geo, smat); blob.rotation.x = -Math.PI / 2; blob.position.y = 0.012; root.add(blob);
    mats.push(smat);
    return { stex, geo };
  }

  function buildProcedural(def, quality) {
    const C = def.colors, mats = [];
    const std = (o) => { const m = new T.MeshStandardMaterial(o); mats.push(m); return m; };
    const bas = (o) => { const m = new T.MeshBasicMaterial(o); mats.push(m); return m; };
    const mSuit = std({ color: 0x0b0e1a, metalness: 0.55, roughness: 0.42 });
    const mSkin = std({ color: C.skin, roughness: 0.75, metalness: 0 });
    const mHair = std({ color: C.hair, roughness: 0.6 });
    const mA = bas({ color: C.a }), mB = bas({ color: C.b });
    const mGlow = bas({ color: C.a, transparent: true, opacity: 0.55, blending: T.AdditiveBlending, depthWrite: false });
    const seg = quality === 'low' ? 6 : 8;
    const cap = (r, l) => new T.CapsuleGeometry(r, l, 3, seg);
    const box = (x, y, z) => new T.BoxGeometry(x, y, z);
    const M = (g, m, x, y, z) => { const o = new T.Mesh(g, m); o.position.set(x || 0, y || 0, z || 0); return o; };

    const root = new T.Group(), rig = new T.Group(), body = new T.Group();
    root.add(rig); rig.add(body);
    const bulk = def.id === 'ren' ? 1 : 0;
    rig.scale.set(bulk ? 1.06 : 0.96, bulk ? 1.05 : 0.97, bulk ? 1.14 : 0.93);

    body.add(M(box(0.26, 0.2, 0.34), mSuit));
    body.add(M(box(0.27, 0.035, 0.35), mA, 0, 0.07, 0));
    const torso = new T.Group(); torso.position.y = 0.1; body.add(torso);
    torso.add(M(box(0.27, 0.52, 0.44), mSuit, 0, 0.27, 0));
    torso.add(M(box(0.02, 0.34, 0.1), mA, 0.14, 0.3, 0));
    torso.add(M(box(0.02, 0.05, 0.3), mB, 0.14, 0.12, 0));
    const head = new T.Group(); head.position.y = 0.58; torso.add(head);
    head.add(M(cap(0.045, 0.05), mSkin, 0, 0.04, 0));
    head.add(M(new T.SphereGeometry(0.125, seg + 2, seg), mSkin, 0, 0.17, 0));
    head.add(M(box(0.1, 0.045, 0.2), mB, 0.07, 0.185, 0));
    if (def.id === 'kira') {
      const tail = M(cap(0.04, 0.22), mHair, -0.17, 0.12, 0); tail.rotation.z = 0.7; head.add(tail);
      head.add(M(new T.SphereGeometry(0.13, seg, seg, 0, Math.PI * 2, 0, Math.PI * 0.55), mHair, -0.02, 0.18, 0));
      head.add(M(new T.SphereGeometry(0.035, 6, 6), mA, -0.26, 0.02, 0));
    } else {
      const cp = M(new T.SphereGeometry(0.13, seg, seg, 0, Math.PI * 2, 0, Math.PI * 0.45), mHair, 0, 0.19, 0); cp.scale.set(1, 0.9, 1); head.add(cp);
      head.add(M(box(0.02, 0.03, 0.27), mA, 0.0, 0.25, 0));
    }

    const J = { body, torso, head, rig, root };
    for (const [side, sg] of [['r', 1], ['l', -1]]) {
      const sh = new T.Group(); sh.position.set(0, 0.47, sg * 0.27); torso.add(sh);
      sh.add(M(new T.SphereGeometry(0.1, 8, 6), mSuit, 0, 0, 0));
      sh.add(M(box(0.05, 0.03, 0.12), mB, 0, 0.09, 0));
      sh.add(M(cap(0.062, 0.2), mSuit, 0, -0.17, 0));
      const el = new T.Group(); el.position.y = -0.35; sh.add(el);
      el.add(M(cap(0.055, 0.19), mSuit, 0, -0.15, 0));
      const cuff = M(new T.CylinderGeometry(0.066, 0.066, 0.05, 8), mA, 0, -0.24, 0); el.add(cuff);
      el.add(M(new T.SphereGeometry(0.075, 8, 6), mSuit, 0, -0.33, 0));
      const glow = M(new T.SphereGeometry(0.22, 8, 6), mGlow, 0, -0.33, 0); glow.visible = false; el.add(glow);
      J[side + 'UA'] = sh; J[side + 'FA'] = el; J[side + 'Glow'] = glow;

      const hp = new T.Group(); hp.position.set(0, -0.1, sg * 0.11); body.add(hp);
      hp.add(M(cap(0.088, 0.27), mSuit, 0, -0.225, 0));
      hp.add(M(box(0.03, 0.2, 0.09), mB, 0.075, -0.2, 0));
      const kn = new T.Group(); kn.position.y = -0.45; hp.add(kn);
      kn.add(M(cap(0.07, 0.3), mSuit, 0, -0.22, 0));
      const foot = M(box(0.27, 0.08, 0.13), mSuit, 0.07, -0.47, 0); kn.add(foot);
      kn.add(M(box(0.02, 0.06, 0.14), mB, 0.205, -0.47, 0));
      J[side + 'Th'] = hp; J[side + 'Sh'] = kn;
    }

    const blob = makeBlob(root, mats);
    const stex = blob.stex;
    return { root, J, mats, stex, glb: null };
  }

  const BONES = ['pelvis', 'torso', 'head', 'shoulder_R', 'elbow_R', 'shoulder_L', 'elbow_L', 'thigh_R', 'knee_R', 'thigh_L', 'knee_L'];
  // ossos extra do esqueleto de 21 ossos (coluna em 2 partes, pescoço, clavículas, pulsos, tornozelos, dedos dos pés).
  // São opcionais: se um GLB antigo não os tiver, o lutador anima-se só com os 11 de cima.
  const EXTRA = { chest: 'chest', neck: 'neck', rCl: 'clavicle_R', lCl: 'clavicle_L', rHand: 'hand_R', lHand: 'hand_L', rFoot: 'foot_R', lFoot: 'foot_L', rToe: 'toe_R', lToe: 'toe_L' };
  const SK = ['chx', 'chy', 'nkx', 'nky', 'hdx', 'hdy', 'rClz', 'rCly', 'lClz', 'lCly', 'rHd', 'lHd', 'rFt', 'lFt', 'rTo', 'lTo'];   // molas secundárias (ângulo, velocidade)
  const clamp = (x, a, b) => (x < a ? a : x > b ? b : x);

  /** Monta o lutador a partir do GLB articulado. Devolve null se o modelo não estiver carregado/for inválido. */
  function buildGLB(def, quality) {
    const M = DK.Models && DK.Models.get(def.id, quality);
    if (!M) return null;
    let inst; try { inst = DK.Models.instantiate(M); } catch (e) { return null; }
    const B = inst.bones, X = inst.extras, mats = inst.mats;
    if (BONES.some((n) => !B[n])) return null;

    const root = new T.Group(), rig = new T.Group(), orient = new T.Group();
    root.add(rig); rig.add(orient); orient.add(inst.root);
    orient.rotation.y = Math.PI / 2;            // GLB: frente em +Z  ->  jogo: frente em +X (lado = Z)
    const bulk = def.id === 'ren' ? 1 : 0;
    if (!M.extras.textured) rig.scale.set(bulk ? 1.06 : 0.96, bulk ? 1.05 : 0.97, bulk ? 1.14 : 0.93);   // os texturados já têm a altura/largura finais

    // ângulos de repouso do modelo (graus, na convenção do jogo) para converter pose absoluta -> rotação do osso
    const rest = { rUA: X.shoulder_R.rest || 0, rFA: X.elbow_R.rest || 0, lUA: X.shoulder_L.rest || 0, lFA: X.elbow_L.rest || 0,
      rTh: X.thigh_R.rest || 0, rSh: X.knee_R.rest || 0, lTh: X.thigh_L.rest || 0, lSh: X.knee_L.rest || 0 };
    // comprimentos [coxa, joelho->chão] de cada perna; em repouso ambas dão a altura restY da anca (modelos texturados têm pernas em passada)
    const legA = X.pelvis.legA || LEG_A, legB = X.pelvis.legB || LEG_B, lg = X.pelvis.legs || {};
    const legs = { r: lg.R || [legA, legB], l: lg.L || [legA, legB] };

    // brilho dos punhos (efeito do golpe especial)
    const mGlow = new T.MeshBasicMaterial({ color: def.colors.a, transparent: true, opacity: 0.55, blending: T.AdditiveBlending, depthWrite: false });
    mats.push(mGlow);
    const glowGeo = new T.SphereGeometry(0.22, 8, 6);
    const J = { root, rig, body: B.pelvis, torso: B.torso, head: B.head, rUA: B.shoulder_R, rFA: B.elbow_R, lUA: B.shoulder_L, lFA: B.elbow_L,
      rTh: B.thigh_R, rSh: B.knee_R, lTh: B.thigh_L, lSh: B.knee_L };
    for (const k in EXTRA) if (B[EXTRA[k]]) J[k] = B[EXTRA[k]];
    // ordem de Euler YXZ nos ombros: a rotação em Y (contra-giro da clavícula) fica a mais exterior e anula-se exactamente
    if (J.rCl && J.lCl) { J.rUA.rotation.order = 'YXZ'; J.lUA.rotation.order = 'YXZ'; }
    for (const [side, bone] of [['r', B.elbow_R], ['l', B.elbow_L]]) {
      const g = new T.Mesh(glowGeo, mGlow), p = (X[bone.name].glow) || [0, -0.3, 0.2];
      g.position.set(p[0], p[1], p[2]); g.visible = false; bone.add(g); J[side + 'Glow'] = g;
    }
    const blob = makeBlob(root, mats);
    return { root, J, mats, stex: blob.stex, glb: { rest, legA, legB, legs, geos: [glowGeo, blob.geo], tris: M.tris } };
  }

  function build(def, quality) { return buildGLB(def, quality) || buildProcedural(def, quality); }

  class FighterModel {
    constructor(def, quality) {
      const b = build(def, quality || 'medium');
      this.def = def; this.root = b.root; this.J = b.J; this.mats = b.mats; this.stex = b.stex; this.glb = b.glb; this.kind = b.glb ? 'glb' : 'procedural';
      this.cur = Object.assign({}, GUARD); this.tgt = Object.assign({}, GUARD); this.vel = {}; this.pose = Object.assign({}, GUARD); this.time = Math.random() * 10;
      for (let i = 0; i < KEYS.length; i++) this.vel[KEYS[i]] = 0;
      this.sx = {}; this.sv = {}; for (const k of SK) { this.sx[k] = 0; this.sv[k] = 0; }
      this.prev = { rUA: GUARD.rUA, rFA: GUARD.rFA, lUA: GUARD.lUA, lFA: GUARD.lFA };
    }
    /** mola amortecida (ângulo em rad) com pequeno excesso: dá atraso e inércia aos ossos secundários */
    spring(k, target, w, zeta, dt) {
      const n = Math.max(1, Math.ceil(dt / 0.006)), h = dt / n; let x = this.sx[k], v = this.sv[k];
      for (let i = 0; i < n; i++) { v += (w * w * (target - x) - 2 * zeta * w * v) * h; x += v * h; }
      this.sx[k] = x; this.sv[k] = v; return x;
    }
    setShadows(on) { this.root.traverse((o) => { if (o.isMesh && o.material && o.material.isMeshStandardMaterial) { o.castShadow = on; } }); }
    /** Pose do modelo procedural (eixo do jogo: frente +X, lado Z -> rotação em Z). */
    poseProcedural(c) {
      const J = this.J;
      J.body.rotation.y = c.by * D2R; J.torso.rotation.z = c.tz * D2R; J.torso.rotation.y = c.ty * D2R; J.head.rotation.z = c.hz * D2R;
      J.rUA.rotation.z = c.rUA * D2R; J.rFA.rotation.z = c.rFA * D2R; J.lUA.rotation.z = c.lUA * D2R; J.lFA.rotation.z = c.lFA * D2R;
      J.rTh.rotation.z = c.rTh * D2R; J.rSh.rotation.z = c.rSh * D2R; J.lTh.rotation.z = c.lTh * D2R; J.lSh.rotation.z = c.lSh * D2R;
      // apoio no chão: a perna mais "esticada" define a altura da anca
      const ext = Math.max(legExt(c.rTh * D2R, c.rSh * D2R), legExt(c.lTh * D2R, c.lSh * D2R));
      J.body.position.y = ext + 0.1 + 0.07 + c.hip;
    }
    /** Pose do modelo GLB (eixo glTF dentro do grupo orientado: lado = X -> rotação em X com sinal trocado).
        Ângulos do jogo são absolutos (0 = membro a pender); subtrai-se o repouso do modelo para obter a rotação do osso. */
    poseGLB(c0, dt) {
      const J = this.J, R = this.glb.rest, c = this.pose, E = !!J.chest;
      dt = dt || 1 / 60;
      for (let i = 0; i < KEYS.length; i++) c[KEYS[i]] = c0[KEYS[i]];
      c.rFA = Math.max(c.rFA, 0); c.lFA = Math.max(c.lFA, 0); c.rSh = Math.min(c.rSh, -1); c.lSh = Math.min(c.lSh, -1);   // sem hiperextensão
      // pernas em passada: a anca roda um pouco com a passada e o peito contra-roda (como numa caminhada real)
      const stride = E ? clamp((c.lTh - c.rTh) * 0.07, -4, 4) : 0;
      J.body.rotation.y = (c.by + stride) * D2R;
      const tx = -c.tz * D2R, ty = c.ty * D2R, cmp = -(c.ty + c.by) * D2R;
      if (E) {
        // coluna em duas partes: a base segue a pose, o peito acompanha com atraso (e respira em repouso)
        const breath = Math.sin(this.time * 2.3) * 0.012;
        J.torso.rotation.x = tx * 0.5; J.torso.rotation.y = ty * 0.5;
        J.chest.rotation.x = this.spring('chx', tx * 0.5 + breath, 20, 0.6, dt);
        J.chest.rotation.y = this.spring('chy', ty * 0.5 - stride * D2R * 0.6, 20, 0.6, dt);
        // pescoço e cabeça: compensam a torção do tronco (olham sempre para o adversário) e atrasam-se ligeiramente
        J.neck.rotation.x = this.spring('nkx', (-c.hz * 0.4 + c.tz * 0.15) * D2R, 17, 0.6, dt);
        J.neck.rotation.y = this.spring('nky', cmp * 0.3, 17, 0.6, dt);
        J.head.rotation.x = this.spring('hdx', (-c.hz * 0.6 + c.tz * 0.2) * D2R, 13, 0.55, dt);
        J.head.rotation.y = this.spring('hdy', cmp * 0.25, 13, 0.55, dt);
      } else {
        J.torso.rotation.x = tx; J.torso.rotation.y = ty; J.head.rotation.x = -c.hz * D2R;
        J.head.rotation.y = cmp * 0.55; J.head.rotation.x += c.tz * D2R * 0.35;
      }
      // cotovelos ligeiramente afastados do tronco na guarda (menos braços colados ao corpo); em golpes esticados desaparece
      const abd = 8 * (1 - Math.min(1, Math.max(0, Math.max(c.rUA, c.lUA) / 100)) * 0.85) * D2R;
      J.rUA.rotation.z = -abd; J.lUA.rotation.z = abd;
      J.rUA.rotation.x = -(c.rUA - R.rUA) * D2R; J.rFA.rotation.x = -(c.rFA - R.rFA) * D2R;
      J.lUA.rotation.x = -(c.lUA - R.lUA) * D2R; J.lFA.rotation.x = -(c.lFA - R.lFA) * D2R;
      J.rTh.rotation.x = -(c.rTh - R.rTh) * D2R; J.rSh.rotation.x = -(c.rSh - R.rSh) * D2R; J.lTh.rotation.x = -(c.lTh - R.lTh) * D2R; J.lSh.rotation.x = -(c.lSh - R.lSh) * D2R;
      // apoio no chão: a perna mais "esticada" define a altura da anca (os pés do GLB assentam em y = 0)
      const LG = this.glb.legs, r = LG.r, l = LG.l;
      const eR = r[0] * Math.cos(c.rTh * D2R) + r[1] * Math.cos((c.rTh + c.rSh) * D2R), eL = l[0] * Math.cos(c.lTh * D2R) + l[1] * Math.cos((c.lTh + c.lSh) * D2R);
      const ext = Math.max(eR, eL);
      J.body.position.y = ext + c.hip;
      if (!E) return;

      // clavículas: o ombro sobe ao levantar o braço e avança ao esticar o soco (alcance e naturalidade)
      const sat = (x) => clamp(x, 0, 1);
      for (const [s, UA, FA, sg] of [['r', c.rUA, c.rFA, 1], ['l', c.lUA, c.lFA, -1]]) {
        const up = (sat(UA / 110) * 11 + sat((UA - 120) / 40) * 6) * D2R, fw = sat((UA - 35) / 60) * 12 * D2R * (1 - sat((FA - 90) / 60) * 0.5);
        J[s + 'Cl'].rotation.z = this.spring(s + 'Clz', -sg * up, 22, 0.65, dt);   // R: -z sobe; L: +z sobe
        const cy = this.spring(s + 'Cly', sg * fw, 22, 0.65, dt);                 // R: +y avança; L: -y avança
        J[s + 'Cl'].rotation.y = cy;
        J[s + 'UA'].rotation.y = -cy;                                              // contra-giro: o ombro avança mas a direcção do braço mantém-se
      }
      // pulsos: arrastam-se atrás do antebraço (atraso/seguimento do golpe) e a mão fica ligeiramente fechada em guarda
      for (const [s, UA, FA] of [['r', c.rUA, c.rFA], ['l', c.lUA, c.lFA]]) {
        const rate = ((UA - this.prev[s + 'UA']) + (FA - this.prev[s + 'FA'])) / dt;   // graus/s do braço
        this.prev[s + 'UA'] = UA; this.prev[s + 'FA'] = FA;
        const tgt = clamp(rate * 0.0016, -0.4, 0.4) + 0.17 * (1 - sat(UA / 90));
        J[s + 'Hand'].rotation.x = this.spring(s + 'Hd', tgt, 20, 0.5, dt);
      }
      // pés: ficam assentes no chão enquanto a perna está apoiada; no ar acompanham a perna (ponta do pé a apontar)
      for (const [s, th, sh, e] of [['r', c.rTh, c.rSh, eR], ['l', c.lTh, c.lSh, eL]]) {
        const lift = ext - e, ground = 1 - sat((lift - 0.02) / 0.1), ks = (th - R[s + 'Th']) + (sh - R[s + 'Sh']);
        const k = 0.28 + 0.72 * ground;                                          // 1 = pé plano no chão; 0.28 = pé acompanha a perna
        const tf = ks * k * D2R - (1 - ground) * 0.32;                           // + compensação, - ponta do pé esticada no ar
        J[s + 'Foot'].rotation.x = this.spring(s + 'Ft', tf, 24, 0.7, dt);
        J[s + 'Toe'].rotation.x = this.spring(s + 'To', clamp((1 - ground) * 0.35 + Math.max(0, -(th - R[s + 'Th'])) * 0.004 * ground, -0.1, 0.6), 24, 0.7, dt);
      }
    }
    /** f: lutador do motor (ou Mirror) */
    update(f, dt) {
      this.time += dt;
      this.gait = (this.gait || 0) + dt * Math.min(24, Math.abs(f.vx) * 3.4 + 4);
      const atk = targetPose(this.tgt, f, this.time, this.gait), c = this.cur, v = this.vel;
      if (atk) {   // golpes: quase directos (os tempos já vêm das poses), só um toque de suavização
        const k = 1 - Math.exp(-70 * dt);
        for (let i = 0; i < KEYS.length; i++) { const q = KEYS[i]; c[q] += (this.tgt[q] - c[q]) * k; v[q] = 0; }
      } else {     // restantes estados: mola amortecida -> movimento com inércia e pequeno excesso, sem rigidez de robô
        const w = f.state === 'hit' ? 48 : 34, zeta = f.state === 'hit' ? 0.85 : 0.75, n = Math.max(1, Math.ceil(dt / 0.006)), h = dt / n;
        for (let s = 0; s < n; s++) for (let i = 0; i < KEYS.length; i++) {
          const q = KEYS[i]; v[q] += (w * w * (this.tgt[q] - c[q]) - 2 * zeta * w * v[q]) * h; c[q] += v[q] * h;
        }
      }
      const J = this.J;
      J.root.position.x = f.x + c.lg * f.face; J.root.rotation.y = f.face > 0 ? 0 : Math.PI;
      if (this.glb) this.poseGLB(c, dt); else this.poseProcedural(c);
      // corpo caído: roda à volta dos pés; sobe-se o eixo do corpo para não enterrar tronco/mochila no chão
      const rz = c.rz * D2R; J.rig.rotation.z = rz; J.rig.rotation.y = spinAt(f) * D2R;
      J.rig.position.y = this.glb ? 0.34 * Math.sin(rz) : 0.22 * Math.sin(rz) - (c.rz > 1 ? 0.05 : 0);
      const g = c.gl > 0.05;
      J.rGlow.visible = g; J.lGlow.visible = g;
      if (g) { const s = 0.7 + c.gl * 0.5 + Math.sin(this.time * 40) * 0.08; J.rGlow.scale.setScalar(s); J.lGlow.scale.setScalar(s); }
    }
    dispose() {
      // as geometrias do GLB são partilhadas entre instâncias (ficam na cache de DK.Models); só se libertam as próprias
      if (this.glb) this.glb.geos.forEach((g) => g.dispose());
      else this.root.traverse((o) => { if (o.geometry) o.geometry.dispose(); });
      for (const m of this.mats) { if (m.map && !(m.map.userData && m.map.userData.shared)) m.map.dispose(); m.dispose(); }
      if (this.stex) this.stex.dispose();
      if (this.root.parent) this.root.parent.remove(this.root);
    }
  }

  DK.FighterModel = FighterModel;
  DK.Poses = { targetPose, spinAt, GUARD, KEYS, EXTRA_BONES: EXTRA };
})();
