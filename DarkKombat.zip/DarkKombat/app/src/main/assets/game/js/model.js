/* Dark Kombat - lutadores 3D articulados (esqueleto de peças com animação por poses + máquina de estados do motor).
   NOTA: são modelos procedurais provisórios (sem ficheiros GLB). Ver docs/MODELOS.md para os substituir por GLB. */
(function () {
  const DK = (globalThis.DK = globalThis.DK || {});
  const T = globalThis.THREE;
  const D2R = Math.PI / 180;
  const KEYS = ['hip', 'tz', 'ty', 'hz', 'by', 'rUA', 'rFA', 'lUA', 'lFA', 'rTh', 'rSh', 'lTh', 'lSh', 'rz', 'gl'];
  const GUARD = { hip: 0, tz: -6, ty: 0, hz: 4, by: 0, rUA: 25, rFA: 105, lUA: 40, lFA: 95, rTh: -18, rSh: -22, lTh: 22, lSh: -28, rz: 0, gl: 0 };
  const P = (o) => Object.assign({}, GUARD, o);
  const W = {
    punchL: P({ lUA: 15, lFA: 140, ty: -12, by: -8 }),
    punchR: P({ rUA: 5, rFA: 145, ty: -20, by: -15 }),
    kickF: P({ rTh: 55, rSh: -100, tz: 2 }),
    kickH: P({ rTh: 75, rSh: -115, tz: 6 }),
    special: P({ rUA: -60, lUA: -60, rFA: 40, lFA: 40, tz: -22, by: -20, hip: -0.05, gl: 1 })
  };
  const PK = {
    punchL: P({ lUA: 90, lFA: 4, ty: 18, by: 12, tz: -12 }),
    punchR: P({ rUA: 92, rFA: 3, ty: 28, by: 22, tz: -14, lTh: 32, rTh: -30 }),
    kickF: P({ rTh: 88, rSh: -4, tz: 14, lSh: -10, rUA: -10, lUA: 60 }),
    kickH: P({ rTh: 135, rSh: -6, tz: 28, lTh: 5, lSh: -8, rUA: -40, lUA: 70 }),
    special: P({ rUA: 95, lUA: 95, rFA: 2, lFA: 2, tz: -30, by: 10, hip: -0.05, lTh: 35, rTh: -30, gl: 1.6 })
  };
  const BLOCK = P({ rUA: 78, rFA: 128, lUA: 84, lFA: 122, tz: -14, rTh: -25, rSh: -35, lTh: 30, lSh: -45 });
  const DODGE = P({ tz: 28, hz: -8, rUA: -10, lUA: -5, rFA: 60, lFA: 60, rTh: -30, rSh: -50, lTh: 10, lSh: -60 });
  const HIT = P({ tz: 22, hz: 30, rUA: -25, lUA: -15, rFA: 40, lFA: 30, rTh: -5, lTh: 10, lSh: -15, rSh: -12 });
  const DOWN = P({ tz: 5, hz: 10, rUA: -30, lUA: -20, rFA: 20, lFA: 20, rTh: 5, lTh: 8, rSh: -8, lSh: -10, rz: 90 });
  const WIN = P({ rUA: 155, lUA: 150, rFA: 15, lFA: 20, tz: 6, hz: -10, rTh: -8, lTh: 8, rSh: -12, lSh: -12 });
  const LOSE = P({ tz: -35, hz: 35, rUA: 5, lUA: 5, rFA: 10, lFA: 10, rTh: 80, rSh: -120, lTh: 80, lSh: -120 });

  const lerpPose = (out, a, b, k) => { for (let i = 0; i < KEYS.length; i++) { const q = KEYS[i]; out[q] = a[q] + (b[q] - a[q]) * k; } };
  const copyPose = (out, a) => { for (let i = 0; i < KEYS.length; i++) out[KEYS[i]] = a[KEYS[i]]; };
  const ease = (x) => { x = x < 0 ? 0 : x > 1 ? 1 : x; return x * x * (3 - 2 * x); };

  /** Calcula a pose-alvo (graus) para o estado do lutador. Devolve true se for um ataque (sem suavização extra). */
  function targetPose(out, f, time) {
    const s = f.state, t = f.st, mv = DK.Sim.MOVES[s];
    if (mv) {
      const m = DK.Sim.moveTimes(s, f.def);
      if (t < m.su) lerpPose(out, GUARD, W[s], ease(t / m.su));
      else if (t < m.su + m.ac) lerpPose(out, W[s], PK[s], (t - m.su) / m.ac);
      else lerpPose(out, PK[s], GUARD, ease((t - m.su - m.ac) / m.rc));
      return true;
    }
    if (s === 'block') copyPose(out, BLOCK);
    else if (s === 'dodge') copyPose(out, DODGE);
    else if (s === 'hit') { copyPose(out, HIT); out.tz += Math.sin(t * 30) * 2; }
    else if (s === 'down') { lerpPose(out, HIT, DOWN, ease(t / 0.28)); }
    else if (s === 'getup') { lerpPose(out, DOWN, GUARD, ease(t / 0.55)); }
    else if (s === 'win') { copyPose(out, WIN); out.hip = Math.abs(Math.sin(time * 4)) * 0.06; }
    else if (s === 'lose') copyPose(out, LOSE);
    else {
      copyPose(out, GUARD);
      out.hip = 0; out.tz += Math.sin(time * 2.2) * 1.4; out.rUA += Math.sin(time * 2.2 + 1) * 2; out.lUA += Math.sin(time * 2.2) * 2;
      const mvx = f.vx * f.face; // >0 aproxima-se, <0 recua
      if (Math.abs(f.vx) > 0.3) {
        const sg = mvx >= 0 ? 1 : -1, w = Math.sin(time * 9 * sg), w2 = Math.sin(time * 9 * sg + Math.PI);
        out.lTh += 26 * w; out.rTh += 26 * w2; out.lSh -= 10 + 18 * Math.max(0, -w); out.rSh -= 10 + 18 * Math.max(0, -w2);
        out.tz += 3 * Math.abs(w);
      }
    }
    return false;
  }

  const LEG_A = 0.45, LEG_B = 0.44;
  const legExt = (th, sh) => LEG_A * Math.cos(th) + LEG_B * Math.cos(th + sh);

  function build(def, quality) {
    const C = def.colors, mats = [];
    const std = (o) => { const m = new T.MeshStandardMaterial(o); mats.push(m); return m; };
    const bas = (o) => { const m = new T.MeshBasicMaterial(o); mats.push(m); return m; };
    const mSuit = std({ color: 0x0b0e1a, metalness: 0.55, roughness: 0.42 });
    const mSkin = std({ color: C.skin, roughness: 0.75, metalness: 0 });
    const mHair = std({ color: C.hair, roughness: 0.6 });
    const mA = bas({ color: C.a }), mB = bas({ color: C.b });
    const mGlow = bas({ color: C.a, transparent: true, opacity: 0.55, blending: T.AdditiveBlending, depthWrite: false });
    const seg = quality === 'low' ? 6 : 8;
    const cap = (r, l) => new T.CapsuleGeometry(r, l, 3, seg);
    const box = (x, y, z) => new T.BoxGeometry(x, y, z);
    const M = (g, m, x, y, z) => { const o = new T.Mesh(g, m); o.position.set(x || 0, y || 0, z || 0); return o; };

    const root = new T.Group(), rig = new T.Group(), body = new T.Group();
    root.add(rig); rig.add(body);
    const bulk = def.id === 'ren' ? 1 : 0;
    rig.scale.set(bulk ? 1.06 : 0.96, bulk ? 1.05 : 0.97, bulk ? 1.14 : 0.93);

    body.add(M(box(0.26, 0.2, 0.34), mSuit));
    body.add(M(box(0.27, 0.035, 0.35), mA, 0, 0.07, 0));
    const torso = new T.Group(); torso.position.y = 0.1; body.add(torso);
    torso.add(M(box(0.27, 0.52, 0.44), mSuit, 0, 0.27, 0));
    torso.add(M(box(0.02, 0.34, 0.1), mA, 0.14, 0.3, 0));
    torso.add(M(box(0.02, 0.05, 0.3), mB, 0.14, 0.12, 0));
    const head = new T.Group(); head.position.y = 0.58; torso.add(head);
    head.add(M(cap(0.045, 0.05), mSkin, 0, 0.04, 0));
    head.add(M(new T.SphereGeometry(0.125, seg + 2, seg), mSkin, 0, 0.17, 0));
    head.add(M(box(0.1, 0.045, 0.2), mB, 0.07, 0.185, 0));
    if (def.id === 'kira') {
      const tail = M(cap(0.04, 0.22), mHair, -0.17, 0.12, 0); tail.rotation.z = 0.7; head.add(tail);
      head.add(M(new T.SphereGeometry(0.13, seg, seg, 0, Math.PI * 2, 0, Math.PI * 0.55), mHair, -0.02, 0.18, 0));
      head.add(M(new T.SphereGeometry(0.035, 6, 6), mA, -0.26, 0.02, 0));
    } else {
      const cp = M(new T.SphereGeometry(0.13, seg, seg, 0, Math.PI * 2, 0, Math.PI * 0.45), mHair, 0, 0.19, 0); cp.scale.set(1, 0.9, 1); head.add(cp);
      head.add(M(box(0.02, 0.03, 0.27), mA, 0.0, 0.25, 0));
    }

    const J = { body, torso, head, rig, root };
    for (const [side, sg] of [['r', 1], ['l', -1]]) {
      const sh = new T.Group(); sh.position.set(0, 0.47, sg * 0.27); torso.add(sh);
      sh.add(M(new T.SphereGeometry(0.1, 8, 6), mSuit, 0, 0, 0));
      sh.add(M(box(0.05, 0.03, 0.12), mB, 0, 0.09, 0));
      sh.add(M(cap(0.062, 0.2), mSuit, 0, -0.17, 0));
      const el = new T.Group(); el.position.y = -0.35; sh.add(el);
      el.add(M(cap(0.055, 0.19), mSuit, 0, -0.15, 0));
      const cuff = M(new T.CylinderGeometry(0.066, 0.066, 0.05, 8), mA, 0, -0.24, 0); el.add(cuff);
      el.add(M(new T.SphereGeometry(0.075, 8, 6), mSuit, 0, -0.33, 0));
      const glow = M(new T.SphereGeometry(0.22, 8, 6), mGlow, 0, -0.33, 0); glow.visible = false; el.add(glow);
      J[side + 'UA'] = sh; J[side + 'FA'] = el; J[side + 'Glow'] = glow;

      const hp = new T.Group(); hp.position.set(0, -0.1, sg * 0.11); body.add(hp);
      hp.add(M(cap(0.088, 0.27), mSuit, 0, -0.225, 0));
      hp.add(M(box(0.03, 0.2, 0.09), mB, 0.075, -0.2, 0));
      const kn = new T.Group(); kn.position.y = -0.45; hp.add(kn);
      kn.add(M(cap(0.07, 0.3), mSuit, 0, -0.22, 0));
      const foot = M(box(0.27, 0.08, 0.13), mSuit, 0.07, -0.47, 0); kn.add(foot);
      kn.add(M(box(0.02, 0.06, 0.14), mB, 0.205, -0.47, 0));
      J[side + 'Th'] = hp; J[side + 'Sh'] = kn;
    }

    // sombra suave (blob) — sempre barata
    const sc = document.createElement('canvas'); sc.width = sc.height = 64;
    const sx = sc.getContext('2d'), gr = sx.createRadialGradient(32, 32, 2, 32, 32, 30);
    gr.addColorStop(0, 'rgba(0,0,0,0.65)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); sx.fillStyle = gr; sx.fillRect(0, 0, 64, 64);
    const stex = new T.CanvasTexture(sc); const smat = new T.MeshBasicMaterial({ map: stex, transparent: true, depthWrite: false });
    const blob = new T.Mesh(new T.PlaneGeometry(1.5, 1.5), smat); blob.rotation.x = -Math.PI / 2; blob.position.y = 0.012; root.add(blob);
    mats.push(smat);

    return { root, J, mats, stex };
  }

  class FighterModel {
    constructor(def, quality) {
      const b = build(def, quality || 'medium');
      this.def = def; this.root = b.root; this.J = b.J; this.mats = b.mats; this.stex = b.stex;
      this.cur = Object.assign({}, GUARD); this.tgt = Object.assign({}, GUARD); this.time = Math.random() * 10;
    }
    setShadows(on) { this.root.traverse((o) => { if (o.isMesh && o.material && o.material.isMeshStandardMaterial) { o.castShadow = on; } }); }
    /** f: lutador do motor (ou Mirror) */
    update(f, dt) {
      this.time += dt;
      const atk = targetPose(this.tgt, f, this.time), c = this.cur;
      const k = atk ? 1 : 1 - Math.exp(-(f.state === 'hit' ? 40 : 16) * dt);
      for (let i = 0; i < KEYS.length; i++) { const q = KEYS[i]; c[q] += (this.tgt[q] - c[q]) * k; }
      const J = this.J;
      J.root.position.x = f.x; J.root.rotation.y = f.face > 0 ? 0 : Math.PI;
      J.body.rotation.y = c.by * D2R; J.torso.rotation.z = c.tz * D2R; J.torso.rotation.y = c.ty * D2R; J.head.rotation.z = c.hz * D2R;
      J.rUA.rotation.z = c.rUA * D2R; J.rFA.rotation.z = c.rFA * D2R; J.lUA.rotation.z = c.lUA * D2R; J.lFA.rotation.z = c.lFA * D2R;
      J.rTh.rotation.z = c.rTh * D2R; J.rSh.rotation.z = c.rSh * D2R; J.lTh.rotation.z = c.lTh * D2R; J.lSh.rotation.z = c.lSh * D2R;
      // apoio no chão: a perna mais "esticada" define a altura da anca
      const ext = Math.max(legExt(c.rTh * D2R, c.rSh * D2R), legExt(c.lTh * D2R, c.lSh * D2R));
      J.body.position.y = ext + 0.1 + 0.07 + c.hip;
      const rz = c.rz * D2R; J.rig.rotation.z = rz; J.rig.position.y = 0.22 * Math.sin(rz) - (c.rz > 1 ? 0.05 : 0);
      const g = c.gl > 0.05;
      J.rGlow.visible = g; J.lGlow.visible = g;
      if (g) { const s = 0.7 + c.gl * 0.5 + Math.sin(this.time * 40) * 0.08; J.rGlow.scale.setScalar(s); J.lGlow.scale.setScalar(s); }
    }
    dispose() {
      this.root.traverse((o) => { if (o.geometry) o.geometry.dispose(); });
      for (const m of this.mats) { if (m.map) m.map.dispose(); m.dispose(); }
      if (this.stex) this.stex.dispose();
      if (this.root.parent) this.root.parent.remove(this.root);
    }
  }

  DK.FighterModel = FighterModel;
  DK.Poses = { targetPose, GUARD, KEYS };
})();
