/* Dark Kombat - cenário 3D, câmara, partículas e qualidade adaptativa (Three.js). */
(function () {
  const DK = (globalThis.DK = globalThis.DK || {});
  const T = globalThis.THREE;
  const LEVELS = ['low', 'medium', 'high'];
  const dpr = () => Math.max(1, Math.min(3, globalThis.devicePixelRatio || 1));
  // níveis de qualidade: o jogo tem de ser LEVE. BAIXO = telemóveis fracos; MÉDIO = por omissão; ALTO = só se o FPS aguentar.
  const Q = {
    low:    { pr: () => Math.min(dpr(), 1) * 0.8,  shadows: false, plights: false, env: false, sparks: 40,  rain: 0,   city: 0.35, extras: false },
    medium: { pr: () => Math.min(dpr(), 1.15),     shadows: false, plights: false, env: false, sparks: 80,  rain: 0,   city: 0.6,  extras: false },
    high:   { pr: () => Math.min(dpr(), 1.6),      shadows: false, plights: true,  env: true,  sparks: 160, rain: 90,  city: 1,    extras: true }
  };

  const srgb = (tex) => { if ('colorSpace' in tex) tex.colorSpace = 'srgb'; else tex.encoding = T.sRGBEncoding; return tex; };
  function canvasTex(w, h, draw) {
    const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h);
    const t = new T.CanvasTexture(c); srgb(t); return t;
  }
  const rnd = (a, b) => a + Math.random() * (b - a);

  function floorTextures(size) {
    const base = canvasTex(size, size, (g, w, h) => {
      const gr = g.createRadialGradient(w / 2, h / 2, 10, w / 2, h / 2, w / 2);
      gr.addColorStop(0, '#1b2a4a'); gr.addColorStop(1, '#0a1020'); g.fillStyle = gr; g.fillRect(0, 0, w, h);
      g.strokeStyle = 'rgba(120,170,255,0.18)'; g.lineWidth = 1;
      for (let i = 0; i < 40; i++) { g.beginPath(); g.moveTo(rnd(0, w), rnd(0, h)); g.lineTo(rnd(0, w), rnd(0, h)); g.stroke(); }
      g.strokeStyle = 'rgba(0,229,255,0.5)'; g.lineWidth = Math.max(1, size / 256);
      const n = 16; for (let i = 0; i <= n; i++) { const p = i * w / n; g.beginPath(); g.moveTo(p, 0); g.lineTo(p, h); g.stroke(); g.beginPath(); g.moveTo(0, p); g.lineTo(w, p); g.stroke(); }
    });
    const emis = canvasTex(size, size, (g, w, h) => {
      g.fillStyle = '#000'; g.fillRect(0, 0, w, h); g.strokeStyle = '#0a5a78'; g.lineWidth = Math.max(1, size / 200);
      const n = 16; for (let i = 0; i <= n; i++) { const p = i * w / n; g.beginPath(); g.moveTo(p, 0); g.lineTo(p, h); g.stroke(); g.beginPath(); g.moveTo(0, p); g.lineTo(w, p); g.stroke(); }
    });
    return { base, emis };
  }

  function envTexture() {
    const t = canvasTex(256, 128, (g, w, h) => {
      const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, '#05081a'); gr.addColorStop(0.55, '#162052'); gr.addColorStop(1, '#03040c');
      g.fillStyle = gr; g.fillRect(0, 0, w, h);
      const cols = ['#00e5ff', '#ff2bd6', '#7a3cff', '#2d8bff'];
      for (let i = 0; i < 26; i++) { g.fillStyle = cols[i % 4]; g.globalAlpha = rnd(0.5, 0.95); g.fillRect(rnd(0, w), rnd(h * 0.2, h * 0.8), rnd(8, 40), rnd(2, 8)); }
      g.globalAlpha = 1;
    });
    t.mapping = T.EquirectangularReflectionMapping; return t;
  }

  function neonPanel(text, c1, c2) {
    return canvasTex(256, 96, (g, w, h) => {
      g.fillStyle = 'rgba(4,6,20,0.85)'; g.fillRect(0, 0, w, h);
      g.strokeStyle = c1; g.lineWidth = 4; g.strokeRect(5, 5, w - 10, h - 10);
      g.font = 'bold ' + Math.min(44, Math.floor(215 / (text.length * 0.62))) + 'px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.shadowColor = c2; g.shadowBlur = 14; g.fillStyle = c2; g.fillText(text, w / 2, h / 2 + 2);
    });
  }

  const G = {
    ready: false, mode: 'auto', level: 1, maxLevel: 2, dropped: {}, good: 0, fps: 60, fAcc: 0, fN: 0, perfSkip: 2,
    models: [], sign: 1, t: 0, shake: 0, oyaw: 0, opitch: 0, tyaw: 0, tpitch: 0, orbitIdle: 0, orbitOn: false, fovPunch: 0, reduce: false, sparkMax: 150, camPos: null, camLook: null,

    init(canvas) {
      this.canvas = canvas;
      // textura redonda e suave para as partículas (sem ela o WebGL desenha quadrados)
      this.dotTex = canvasTex(64, 64, (g, w, h) => {
        const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
        gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.3, 'rgba(255,255,255,0.8)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
        g.fillStyle = gr; g.fillRect(0, 0, w, h);
      });
      // estrela de impacto (clarão do golpe)
      this.burstTex = canvasTex(128, 128, (g, w, h) => {
        g.translate(64, 64);
        const gr = g.createRadialGradient(0, 0, 0, 0, 0, 44);
        gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.35, 'rgba(255,255,255,0.55)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
        g.fillStyle = gr; g.beginPath(); g.arc(0, 0, 44, 0, Math.PI * 2); g.fill();
        for (let i = 0; i < 10; i++) {
          const len = i % 2 ? 36 : 62, wd = i % 2 ? 4 : 5.5; g.save(); g.rotate(i * Math.PI / 5);
          const lg = g.createLinearGradient(0, 0, len, 0); lg.addColorStop(0, 'rgba(255,255,255,0.95)'); lg.addColorStop(1, 'rgba(255,255,255,0)');
          g.fillStyle = lg; g.beginPath(); g.moveTo(0, -wd); g.lineTo(len, 0); g.lineTo(0, wd); g.closePath(); g.fill(); g.restore();
        }
      });
      // clarão azul-branco do golpe (estilo da imagem de referência): núcleo branco, halo azul grande
      this.blastTex = canvasTex(256, 256, (g) => {
        g.translate(128, 128);
        const gr = g.createRadialGradient(0, 0, 0, 0, 0, 128);
        gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.2, 'rgba(255,255,255,1)'); gr.addColorStop(0.34, 'rgba(215,242,255,0.96)');
        gr.addColorStop(0.52, 'rgba(70,176,255,0.6)'); gr.addColorStop(0.76, 'rgba(20,100,255,0.2)'); gr.addColorStop(1, 'rgba(0,60,255,0)');
        g.fillStyle = gr; g.beginPath(); g.arc(0, 0, 128, 0, Math.PI * 2); g.fill();
      });
      // raios finos que saem do ponto de impacto (linhas azuis de comprimentos diferentes)
      this.rayTex = canvasTex(256, 256, (g) => {
        g.translate(128, 128); let seed = 7; const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
        for (let i = 0; i < 64; i++) {
          const a = rnd() * Math.PI * 2, len = 60 + rnd() * rnd() * 68 + rnd() * 20, w = 0.6 + rnd() * 1.9;
          g.save(); g.rotate(a);
          const lg = g.createLinearGradient(0, 0, len, 0); lg.addColorStop(0, 'rgba(235,248,255,0.95)'); lg.addColorStop(0.4, 'rgba(120,205,255,0.6)'); lg.addColorStop(1, 'rgba(40,130,255,0)');
          g.fillStyle = lg; g.beginPath(); g.moveTo(0, -w); g.lineTo(len, 0); g.lineTo(0, w); g.closePath(); g.fill(); g.restore();
        }
      });
      this.renderer = new T.WebGLRenderer({ canvas, antialias: false, alpha: false, powerPreference: 'high-performance' });
      const r = this.renderer;
      if ('outputColorSpace' in r) r.outputColorSpace = 'srgb'; else r.outputEncoding = T.sRGBEncoding;
      r.setClearColor(0x120a2c, 1); r.shadowMap.type = T.PCFShadowMap;
      this.scene = new T.Scene(); this.scene.fog = new T.FogExp2(0x120a2c, 0.0105);
      this.camera = new T.PerspectiveCamera(40, 16 / 9, 0.1, 700);
      this.camPos = new T.Vector3(0, 2.2, 8); this.camLook = new T.Vector3(0, 1.1, 0); this._v = new T.Vector3();
      this.buildWorld(); this.buildFx();
      const lowEnd = (navigator.hardwareConcurrency || 4) <= 4 || (navigator.deviceMemory || 4) <= 3;
      this.autoStart = lowEnd ? 0 : 1;   // começa leve e só sobe se o FPS sobrar
      this.resize(); this.ready = true;
      this.setQuality(DK.Settings.data.quality);
      window.addEventListener('resize', () => this.resize());
      this.initOrbit(canvas);
      canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); this.lost = true; });
      canvas.addEventListener('webglcontextrestored', () => { this.lost = false; this.applyLevel(this.level); });
    },

    buildWorld() {
      const S = this.scene, tq = Q.high; // texturas criadas uma vez; resolução definida pelo nível inicial
      const ft = floorTextures(512);
      this.floorMat = new T.MeshStandardMaterial({ color: 0xffffff, map: ft.base, emissive: 0xffffff, emissiveMap: ft.emis, emissiveIntensity: 0.9, metalness: 0.85, roughness: 0.3 });
      this.floor = new T.Mesh(new T.CylinderGeometry(6.2, 6.5, 0.4, 56), this.floorMat); this.floor.position.y = -0.2; S.add(this.floor);
      const ringMat = new T.MeshBasicMaterial({ color: 0x28b4ff });
      const ring = new T.Mesh(new T.TorusGeometry(6.1, 0.12, 8, 72), ringMat); ring.rotation.x = Math.PI / 2; ring.position.y = 0.02; S.add(ring);
      const glow = new T.Mesh(new T.TorusGeometry(6.1, 0.34, 8, 72), new T.MeshBasicMaterial({ color: 0x0aa8ff, transparent: true, opacity: 0.32, blending: T.AdditiveBlending, depthWrite: false }));
      glow.rotation.x = Math.PI / 2; glow.position.y = 0.03; S.add(glow);
      const inner = new T.Mesh(new T.TorusGeometry(5.0, 0.025, 6, 72), new T.MeshBasicMaterial({ color: 0xff2bd6 })); inner.rotation.x = Math.PI / 2; inner.position.y = 0.015; S.add(inner);
      const emblemTex = canvasTex(256, 256, (g, w, h) => {
        g.clearRect(0, 0, w, h); g.strokeStyle = '#00e5ff'; g.lineWidth = 5; g.beginPath(); g.arc(w / 2, h / 2, 110, 0, 7); g.stroke();
        g.strokeStyle = '#ff2bd6'; g.lineWidth = 3; g.beginPath(); g.arc(w / 2, h / 2, 90, 0, 7); g.stroke();
        g.strokeStyle = 'rgba(0,229,255,0.55)'; g.lineWidth = 2; for (const rr of [100, 124]) { g.beginPath(); for (let k = 0; k < 6; k++) { const aa = k * Math.PI / 3 + Math.PI / 6; g.lineTo(w / 2 + Math.cos(aa) * rr, h / 2 + Math.sin(aa) * rr); } g.closePath(); g.stroke(); }
        g.fillStyle = '#00e5ff'; g.font = 'bold 70px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('DK', w / 2, h / 2 + 4);
        g.fillStyle = '#ff2bd6'; for (let i = 0; i < 4; i++) { g.save(); g.translate(w / 2, h / 2); g.rotate(i * Math.PI / 2); g.fillRect(-4, -126, 8, 22); g.restore(); }
      });
      const emblem = new T.Mesh(new T.CircleGeometry(2.3, 40), new T.MeshBasicMaterial({ map: emblemTex, transparent: true, opacity: 0.7, blending: T.AdditiveBlending, depthWrite: false }));
      emblem.rotation.x = -Math.PI / 2; emblem.position.y = 0.012; S.add(emblem);

      // cidade cyberpunk (ver js/city.js): praça + avenidas + quarteirões, letreiros, carros, candeeiros
      this.city = DK.City.build({ T, scene: S, ctex: canvasTex, dotTex: this.dotTex, ground: (navigator.deviceMemory || 4) >= 6 ? 2048 : 1024 });
      this.ground = this.city.ground; this.buildings = null;

      // céu: degradê (a cor do horizonte combina com o nevoeiro) e duas luas
      const sky = new T.Mesh(new T.CylinderGeometry(300, 300, 400, 24, 1, true), new T.MeshBasicMaterial({
        side: T.BackSide, fog: false, map: canvasTex(4, 256, (g, w, h) => { const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, '#02030a'); gr.addColorStop(0.55, '#0a0a28'); gr.addColorStop(0.78, '#1c0d4a'); gr.addColorStop(0.86, '#4a1a80'); gr.addColorStop(0.885, '#2a1260'); gr.addColorStop(0.9, '#120a2c'); gr.addColorStop(1, '#120a2c'); g.fillStyle = gr; g.fillRect(0, 0, w, h); })
      }));
      sky.position.y = 150; S.add(sky);
      const moonTex = canvasTex(128, 128, (g, w, h) => { const gr = g.createRadialGradient(64, 64, 4, 64, 64, 62); gr.addColorStop(0, 'rgba(255,200,255,1)'); gr.addColorStop(0.25, 'rgba(255,43,214,0.7)'); gr.addColorStop(1, 'rgba(255,43,214,0)'); g.fillStyle = gr; g.fillRect(0, 0, w, h); });
      const moon = new T.Sprite(new T.SpriteMaterial({ map: moonTex, fog: false, depthWrite: false, blending: T.AdditiveBlending })); moon.scale.set(64, 64, 1); moon.position.set(-60, 72, -230); S.add(moon);
      const moon2 = new T.Sprite(new T.SpriteMaterial({ map: moonTex, color: 0x66d9ff, fog: false, depthWrite: false, blending: T.AdditiveBlending })); moon2.scale.set(30, 30, 1); moon2.position.set(150, 90, 200); S.add(moon2);

      // luzes
      this.amb = new T.AmbientLight(0x3a4c7a, 0.62); S.add(this.amb);
      this.hemi = new T.HemisphereLight(0x7a96ff, 0x1c0a38, 0.6); S.add(this.hemi);
      this.dir = new T.DirectionalLight(0xc2d8ff, 1.0); this.dir.position.set(3, 9, 6); S.add(this.dir);
      this.dir.shadow.mapSize.set(1024, 1024); const sc = this.dir.shadow.camera; sc.left = -8; sc.right = 8; sc.top = 8; sc.bottom = -8; sc.near = 1; sc.far = 25; this.dir.shadow.bias = -0.0006;
      this.rim = new T.DirectionalLight(0x6aa8ff, 0.55); this.rim.position.set(-5, 4, -7); S.add(this.rim);   // contraluz azul: destaca a silhueta sem luzes por pixel
      this.pm = new T.PointLight(0xff2bd6, 1.6, 18); this.pm.position.set(-5, 3.2, 3); S.add(this.pm);
      this.pc = new T.PointLight(0x00e5ff, 1.6, 18); this.pc.position.set(5, 3.2, -3); S.add(this.pc);
      this.envTex = envTexture();

      // chuva (apenas qualidade alta)
      const N = 160, pos = new Float32Array(N * 3); this.rainPos = pos;
      for (let i = 0; i < N; i++) { pos[i * 3] = rnd(-13, 13); pos[i * 3 + 1] = rnd(0, 14); pos[i * 3 + 2] = rnd(-13, 13); }
      const rg = new T.BufferGeometry(); rg.setAttribute('position', new T.BufferAttribute(pos, 3));
      this.rain = new T.Points(rg, new T.PointsMaterial({ color: 0x6fd8ff, size: 0.11, map: this.dotTex, transparent: true, opacity: 0.5, depthWrite: false })); this.rain.frustumCulled = false; this.rain.visible = false; S.add(this.rain);
    },

    buildFx() {
      const N = 260; this.sp = { n: N, pos: new Float32Array(N * 3), col: new Float32Array(N * 3), base: new Float32Array(N * 3), vel: new Float32Array(N * 3), life: new Float32Array(N), max: new Float32Array(N), cur: 0 };
      const g = new T.BufferGeometry(); g.setAttribute('position', new T.BufferAttribute(this.sp.pos, 3)); g.setAttribute('color', new T.BufferAttribute(this.sp.col, 3));
      for (let i = 0; i < N; i++) this.sp.pos[i * 3 + 1] = -100;
      this.sparks = new T.Points(g, new T.PointsMaterial({ size: 0.075, map: this.dotTex, vertexColors: true, transparent: true, depthWrite: false, blending: T.AdditiveBlending }));
      this.sparks.frustumCulled = false; this.scene.add(this.sparks);
      this.rings = [];
      for (let i = 0; i < 3; i++) {
        const m = new T.Mesh(new T.RingGeometry(0.85, 1, 40), new T.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0, side: T.DoubleSide, depthWrite: false, blending: T.AdditiveBlending }));
        m.rotation.x = -Math.PI / 2; m.position.y = 0.05; m.visible = false; m.userData = { life: 0 }; this.scene.add(m); this.rings.push(m);
      }
      this.ringCur = 0;
      this.flashes = [];   // clarões de impacto (sprites reutilizados)
      for (let i = 0; i < 6; i++) {
        const sp = new T.Sprite(new T.SpriteMaterial({ map: this.burstTex, color: 0xffffff, transparent: true, opacity: 0, depthWrite: false, depthTest: true, blending: T.AdditiveBlending }));
        sp.visible = false; sp.renderOrder = 20; sp.userData = { life: 0, max: 0.2, size: 1 }; this.scene.add(sp); this.flashes.push(sp);
      }
      this.flashCur = 0;
      this.blasts = [];   // clarões grandes de impacto: halo + raios (reutilizados)
      for (let i = 0; i < 3; i++) {
        const mk = (tex, order) => { const sp = new T.Sprite(new T.SpriteMaterial({ map: tex, color: 0xffffff, transparent: true, opacity: 0, depthWrite: false, depthTest: false, blending: T.AdditiveBlending })); sp.visible = false; sp.renderOrder = order; this.scene.add(sp); return sp; };
        this.blasts.push({ glow: mk(this.blastTex, 21), rays: mk(this.rayTex, 22), life: 0, max: 0.45, size: 4, rot: 0, rays_on: true });
      }
      this.blastCur = 0;
    },
    /** Direcção (unitária) do ponto para a câmara: os efeitos ficam à frente do corpo sem o cobrir. */
    towardCam(x, y, z, k) {
      const c = this.camera.position, dx = c.x - x, dy = c.y - y, dz = c.z - z, l = Math.hypot(dx, dy, dz) || 1;
      return [x + dx / l * k, y + dy / l * k, z + dz / l * k];
    },
    /** Clarão GRANDE (halo + raios): usado só no golpe especial. */
    emitBlast(x, y, z, power, weak) {
      const b = this.blasts[this.blastCur]; this.blastCur = (this.blastCur + 1) % this.blasts.length;
      const r = this.reduce ? 0.6 : 1, p = this.towardCam(x, y, z, 0.5);
      b.size = (weak ? 1.9 : 3.4 + 2.2 * power) * r; b.max = weak ? 0.22 : 0.42 + 0.1 * power; b.life = b.max; b.rot = Math.random() * 6.28; b.rays_on = !weak && !this.reduce;
      for (const sp of [b.glow, b.rays]) { sp.position.set(p[0], p[1], p[2]); sp.visible = true; sp.material.rotation = b.rot; }
      b.glow.material.color.set(weak ? 0x8fe8ff : 0xffffff); b.rays.visible = b.rays_on;
    },
    /** Impacto pequeno e rápido (soco/pontapé normal ou defesa). power ~0.5..1.2. Não cobre o lutador: pequeno, curto e com teste de profundidade. */
    emitHit(x, y, z, color, power) {
      const s = this.flashes[this.flashCur]; this.flashCur = (this.flashCur + 1) % this.flashes.length;
      const p = this.towardCam(x, y, z, 0.28);
      s.position.set(p[0], p[1], p[2]); s.material.color.set(color); s.material.rotation = Math.random() * 6.28;
      s.userData.life = s.userData.max = 0.11; s.userData.size = 0.42 * (power || 1); s.visible = true;
    },
    emitFlash(x, y, z, color, size) {
      const s = this.flashes[this.flashCur]; this.flashCur = (this.flashCur + 1) % this.flashes.length;
      const p = this.towardCam(x, y, z, 0.3);
      s.position.set(p[0], p[1], p[2]); s.material.color.set(color); s.material.rotation = Math.random() * 6.28;
      s.userData.life = s.userData.max = 0.15; s.userData.size = size || 1; s.visible = true;
    },

    emitSparks(x, y, z, color, count, speed) {
      const s = this.sp, c = new T.Color(color), n = Math.min(count, Math.max(4, Math.round(count * (this.reduce ? 0.3 : 1))));
      for (let k = 0; k < n; k++) {
        const i = s.cur; s.cur = (s.cur + 1) % Math.min(s.n, this.sparkMax);
        const a = Math.random() * Math.PI * 2, e = Math.random() * 1.2 - 0.2, sp = speed * (0.4 + Math.random() * 0.8);
        s.pos[i * 3] = x; s.pos[i * 3 + 1] = y; s.pos[i * 3 + 2] = z;
        s.vel[i * 3] = Math.cos(a) * sp; s.vel[i * 3 + 1] = (e + 0.4) * sp; s.vel[i * 3 + 2] = Math.sin(a) * sp * 0.6;
        s.base[i * 3] = c.r; s.base[i * 3 + 1] = c.g; s.base[i * 3 + 2] = c.b; s.max[i] = s.life[i] = 0.35 + Math.random() * 0.3;
      }
    },
    ring(x, color, size) {
      const m = this.rings[this.ringCur]; this.ringCur = (this.ringCur + 1) % this.rings.length;
      m.position.x = x; m.material.color.set(color); m.userData.life = 0.6; m.userData.size = size || 4; m.visible = true;
    },
    addShake(a) { if (!this.reduce) this.shake = Math.min(0.5, this.shake + a); },
    punchFov(a) { if (!this.reduce) this.fovPunch = a; },

    updateFx(dt) {
      const s = this.sp; let any = false;
      for (let i = 0; i < s.n; i++) {
        if (s.life[i] > 0) {
          any = true; s.life[i] -= dt; const k = Math.max(0, s.life[i] / s.max[i]);
          s.vel[i * 3 + 1] -= 9 * dt; s.pos[i * 3] += s.vel[i * 3] * dt; s.pos[i * 3 + 1] += s.vel[i * 3 + 1] * dt; s.pos[i * 3 + 2] += s.vel[i * 3 + 2] * dt;
          if (s.pos[i * 3 + 1] < 0.02) { s.pos[i * 3 + 1] = 0.02; s.vel[i * 3 + 1] *= -0.3; }
          s.col[i * 3] = s.base[i * 3] * k; s.col[i * 3 + 1] = s.base[i * 3 + 1] * k; s.col[i * 3 + 2] = s.base[i * 3 + 2] * k;
          if (s.life[i] <= 0) s.pos[i * 3 + 1] = -100;
        }
      }
      if (any || this._sparkDirty) { this.sparks.geometry.attributes.position.needsUpdate = true; this.sparks.geometry.attributes.color.needsUpdate = true; this._sparkDirty = any; }
      for (const r of this.rings) {
        if (r.userData.life > 0) {
          r.userData.life -= dt; const k = 1 - Math.max(0, r.userData.life) / 0.6; r.scale.setScalar(0.4 + k * r.userData.size); r.material.opacity = (1 - k) * 0.8;
          if (r.userData.life <= 0) { r.visible = false; r.material.opacity = 0; }
        }
      }
      for (const b of this.blasts) {
        if (b.life <= 0) continue;
        b.life -= dt; const k = 1 - Math.max(0, b.life) / b.max, e = 1 - (1 - k) * (1 - k);
        b.glow.scale.setScalar(b.size * (0.4 + 0.8 * e)); b.glow.material.opacity = k < 0.3 ? 1 : Math.pow(Math.max(0, 1 - (k - 0.3) / 0.7), 1.5);
        if (b.rays_on) { b.rays.scale.setScalar(b.size * (0.8 + 1.7 * e)); b.rays.material.rotation = b.rot + k * 0.12; b.rays.material.opacity = Math.pow(1 - k, 1.1); }
        if (b.life <= 0) { b.glow.visible = false; b.rays.visible = false; b.glow.material.opacity = 0; b.rays.material.opacity = 0; }
      }
      for (const s of this.flashes) {
        const u = s.userData; if (u.life <= 0) continue;
        u.life -= dt; const k = 1 - Math.max(0, u.life) / u.max;
        s.scale.setScalar(u.size * (0.55 + k * 0.7)); s.material.opacity = Math.max(0, 1 - k * k) * 0.95;
        if (u.life <= 0) { s.visible = false; s.material.opacity = 0; }
      }
      if (this.city) this.city.update(this.t);
      if (this.rain.visible) {
        const p = this.rainPos; for (let i = 0; i < p.length; i += 3) { p[i + 1] -= 16 * dt; if (p[i + 1] < 0) p[i + 1] = 14; }
        this.rain.geometry.attributes.position.needsUpdate = true;
      }
    },

    // ---------- lutadores ----------
    showFighters(defA, defB) {
      this.clearFighters();
      const q = LEVELS[this.level] === 'low' ? 'low' : 'medium';
      this.models = [new DK.FighterModel(defA, q), new DK.FighterModel(defB, q)];
      this.models.forEach((m) => { this.scene.add(m.root); m.setShadows(Q[LEVELS[this.level]].shadows); });
    },
    replaceFighter(i, def) {
      const old = this.models[i]; if (old) old.dispose();
      const m = new DK.FighterModel(def, 'medium'); this.models[i] = m; this.scene.add(m.root); m.setShadows(Q[LEVELS[this.level]].shadows);
    },
    clearFighters() { this.models.forEach((m) => m.dispose()); this.models = []; },

    /** Retrato 3D da cara do lutador (renderiza o GLB da arena para um canvas 2D). Devolve null se não for possível. */
    renderPortrait(def, px) {
      try {
        if (!this.ready || !DK.Models || !DK.Models.has(def.id)) return null;
        this._pc = this._pc || {};
        if (!this._pc[def.id]) {
          const size = px || 160, m = new DK.FighterModel(def, 'medium');
          if (m.kind !== 'glb') { m.dispose(); return null; }
          const sc = new T.Scene(); sc.background = new T.Color(0x0e1740); sc.add(m.root);
          sc.add(new T.AmbientLight(0xffffff, 0.8)); sc.add(new T.HemisphereLight(0x9fb6ff, 0x301048, 0.7));
          const dl = new T.DirectionalLight(0xffffff, 1.2); dl.position.set(3, 3, 3); sc.add(dl);
          const rim = new T.PointLight(def.colors.a, 1.4, 6); rim.position.set(-1, 2, -1.5); sc.add(rim);
          const f = DK.Sim.makeFighter(def, 0); f.x = 0; f.face = 1; m.update(f, 0.016); sc.updateMatrixWorld(true);
          const hp = new T.Vector3(); m.J.head.getWorldPosition(hp);
          const cam = new T.PerspectiveCamera(24, 1, 0.1, 20); cam.position.set(hp.x + 1.25, hp.y + 0.14, hp.z + 0.45); cam.lookAt(hp.x, hp.y + 0.11, hp.z);
          const rt = new T.WebGLRenderTarget(size, size);
          if ('colorSpace' in rt.texture) rt.texture.colorSpace = 'srgb'; else rt.texture.encoding = T.sRGBEncoding;
          const r = this.renderer, prev = r.getRenderTarget(), sh = r.shadowMap.enabled;
          r.shadowMap.enabled = false; r.setRenderTarget(rt); r.render(sc, cam);
          const buf = new Uint8Array(size * size * 4); r.readRenderTargetPixels(rt, 0, 0, size, size, buf);
          r.setRenderTarget(prev); r.shadowMap.enabled = sh; rt.dispose(); m.dispose();
          let any = 0; for (let i = 0; i < buf.length; i += 97) any |= buf[i];
          if (!any) return null;
          const c = document.createElement('canvas'); c.width = c.height = size; const g = c.getContext('2d'), im = g.createImageData(size, size);
          for (let y = 0; y < size; y++) im.data.set(buf.subarray((size - 1 - y) * size * 4, (size - y) * size * 4), y * size * 4);
          g.putImageData(im, 0, 0); this._pc[def.id] = c;
        }
        const src = this._pc[def.id], out = document.createElement('canvas'); out.width = src.width; out.height = src.height;
        out.getContext('2d').drawImage(src, 0, 0); return out;
      } catch (e) { if (globalThis.console) console.warn('Retrato 3D indisponível:', e && e.message); return null; }
    },

    // ---------- qualidade ----------
    setQuality(mode) {
      this.mode = mode;
      if (mode === 'auto') { this.level = this.autoStart; this.dropped = {}; this.good = 0; this.perfSkip = 2; }
      else this.level = LEVELS.indexOf(mode);
      this.applyLevel(this.level);
    },
    levelName() { return LEVELS[this.level]; },
    applyLevel(l) {
      const q = Q[LEVELS[l]], r = this.renderer;
      r.setPixelRatio(q.pr()); this.resize();
      const sh = q.shadows; if (r.shadowMap.enabled !== sh) { r.shadowMap.enabled = sh; this.scene.traverse((o) => { if (o.material && !Array.isArray(o.material)) o.material.needsUpdate = true; }); }
      this.dir.castShadow = sh; this.floor.receiveShadow = sh; this.models.forEach((m) => m.setShadows(sh));
      this.pm.visible = q.plights; this.pc.visible = q.plights;
      this.scene.environment = q.env ? this.envTex : null; this.floorMat.needsUpdate = true;
      this.rain.visible = q.rain > 0 && !this.reduce; this.rain.geometry.setDrawRange(0, q.rain);
      this.city.setLevel(l, this.reduce, q.city, q.extras); this.sparkMax = Math.min(q.sparks, this.sp.n);
    },
    setReduce(on) { this.reduce = !!on; if (this.ready) this.applyLevel(this.level); },
    perfTick(raw) {
      this.fAcc += raw; this.fN++;
      if (this.fAcc < 3) return;
      const fps = this.fN / this.fAcc; this.fps = Math.round(fps); this.fAcc = 0; this.fN = 0;
      if (this.perfSkip > 0) { this.perfSkip--; return; }
      if (this.mode !== 'auto' || this.paused) return;
      if (fps < 27 && this.level > 0) { this.dropped[this.level] = true; this.level--; this.good = 0; this.perfSkip = 1; this.applyLevel(this.level); }
      else if (fps >= 56 && this.level < 2 && !this.dropped[this.level + 1]) { if (++this.good >= 3) { this.level++; this.good = 0; this.perfSkip = 1; this.applyLevel(this.level); } }
      else this.good = 0;
    },

    resize() {
      const w = globalThis.innerWidth, h = globalThis.innerHeight; if (!this.renderer) return;
      this.renderer.setSize(w, h, false); this.camera.aspect = w / h; this.camera.updateProjectionMatrix();
    },
    project(x, y, z) {
      this._v.set(x, y, z).project(this.camera);
      return { x: (this._v.x * 0.5 + 0.5) * globalThis.innerWidth, y: (-this._v.y * 0.5 + 0.5) * globalThis.innerHeight };
    },

    // ---------- desenho ----------
    draw(dt, view, mode) {
      if (!this.ready || this.lost) return;
      this.t += dt;
      const f = view.f;
      for (let i = 0; i < this.models.length; i++) { if (mode === 'menu') f[i].st += dt; this.models[i].update(f[i], dt); }
      this.updateFx(dt);
      this.updateCamera(dt, f, mode);
      this.renderer.render(this.scene, this.camera);
    },
    /** Arrastar o dedo (ou o rato) no ecrã gira a câmara à volta dos lutadores; larga-se e ela volta sozinha ao fim de uns segundos. */
    initOrbit(canvas) {
      let pid = null, lx = 0, ly = 0;
      const down = (e) => { if (!this.orbitOn || pid !== null) return; pid = e.pointerId; lx = e.clientX; ly = e.clientY; this.orbitIdle = 0; try { canvas.setPointerCapture(pid); } catch (x) { /* ok */ } };
      const move = (e) => {
        if (e.pointerId !== pid) return;
        const dx = e.clientX - lx, dy = e.clientY - ly; lx = e.clientX; ly = e.clientY;
        this.tyaw = Math.max(-1.3, Math.min(1.3, this.tyaw - dx * 0.0065 * this.sign)); this.tpitch = Math.max(-0.12, Math.min(0.62, this.tpitch + dy * 0.004)); this.orbitIdle = 0;
      };
      const up = (e) => { if (e.pointerId === pid) { pid = null; this.orbitIdle = 0.001; } };
      canvas.addEventListener('pointerdown', down); canvas.addEventListener('pointermove', move);
      canvas.addEventListener('pointerup', up); canvas.addEventListener('pointercancel', up); canvas.addEventListener('lostpointercapture', up);
      this._orbitDragging = () => pid !== null;
    },
    resetOrbit() { this.tyaw = this.tpitch = this.oyaw = this.opitch = 0; this.orbitIdle = 0; },
    updateCamera(dt, f, mode) {
      const cam = this.camera, k = Math.min(1, dt * 5);
      if (mode === 'menu') {
        const ang = Math.sin(this.t * 0.22) * 0.5, r = 7.4;
        this.camPos.set(Math.sin(ang) * r, 2.1, Math.cos(ang) * r); this.camLook.set(0, 1.15, 0);
        cam.position.copy(this.camPos); cam.lookAt(this.camLook); if (cam.fov !== 40) { cam.fov = 40; cam.updateProjectionMatrix(); } return;
      }
      const a = f[0].x, b = f[1].x, cx = (a + b) / 2, dist = Math.abs(a - b);
      let D = Math.max(6.4, 4.8 + dist * 0.62); const asp = cam.aspect; if (asp < 1.8) D *= 1 + (1.8 - asp) * 0.18;
      const tx = cx * 0.75, ty = 1.85, tz = this.sign * D;
      this.camPos.x += (tx - this.camPos.x) * k; this.camPos.y += (ty - this.camPos.y) * k; this.camPos.z += (tz - this.camPos.z) * k;
      this.camLook.x += (cx * 0.9 - this.camLook.x) * k; this.camLook.y = 1.1; this.camLook.z = 0;
      // órbita: depois de largar o dedo, volta suavemente à vista normal
      if (this.orbitIdle > 0 && !(this._orbitDragging && this._orbitDragging())) { this.orbitIdle += dt; if (this.orbitIdle > 4) { this.tyaw *= Math.max(0, 1 - dt * 1.6); this.tpitch *= Math.max(0, 1 - dt * 1.6); } }
      const ko = Math.min(1, dt * 12); this.oyaw += (this.tyaw - this.oyaw) * ko; this.opitch += (this.tpitch - this.opitch) * ko;
      let ox = this.camPos.x - this.camLook.x, oy = this.camPos.y - this.camLook.y, oz = this.camPos.z - this.camLook.z;
      const cy = Math.cos(this.oyaw), sy = Math.sin(this.oyaw), rx = ox * cy + oz * sy, rz = -ox * sy + oz * cy;
      const hr = Math.hypot(rx, rz), cp = Math.cos(this.opitch), sp = Math.sin(this.opitch);
      ox = rx * cp; oz = rz * cp; oy = oy + hr * sp * 0.9;
      let sx = 0, sy2 = 0; if (this.shake > 0.002) { sx = (Math.random() - 0.5) * this.shake; sy2 = (Math.random() - 0.5) * this.shake * 0.6; this.shake *= Math.max(0, 1 - dt * 9); }
      cam.position.set(this.camLook.x + ox + sx, Math.max(0.5, this.camLook.y + oy + sy2), this.camLook.z + oz); cam.lookAt(this.camLook);
      this.fovPunch *= Math.max(0, 1 - dt * 6); const fov = 40 - this.fovPunch; if (Math.abs(cam.fov - fov) > 0.05) { cam.fov = fov; cam.updateProjectionMatrix(); }
    },
    snapCamera() { this.camPos.set(0, 1.85, this.sign * 8); this.camLook.set(0, 1.1, 0); this.resetOrbit(); },
    dispose() { this.clearFighters(); this.renderer.dispose(); }
  };
  DK.Gfx = G;
})();
