/* Dark Kombat - protocolo Bluetooth (ver docs/PROTOCOLO.md). Funciona em browser e em Node (testes). */
(function () {
  const DK = (globalThis.DK = globalThis.DK || {});
  const MAX_LEN = 2048;
  const isInt = (v, a, b) => Number.isInteger(v) && v >= a && v <= b;
  const isNum = (v, a, b) => typeof v === 'number' && Number.isFinite(v) && v >= a && v <= b;
  const FIGHTER_IDS = ['kira', 'ren', 'liam', 'saray'];
  const isFighter = (v) => FIGHTER_IDS.indexOf(v) >= 0;

  function fighterRow(r) {
    return Array.isArray(r) && r.length === 5 &&
      isNum(r[0], -12, 12) && isNum(r[1], 0, 400) && isNum(r[2], 0, 100) &&
      isInt(r[3], 0, 31) && isNum(r[4], 0, 30);
  }
  function statRow(r) {
    return Array.isArray(r) && r.length === 4 && isInt(r[0], 0, 999) && isNum(r[1], 0, 9999) &&
      isInt(r[2], 0, 99) && isInt(r[3], 0, 999);
  }

  /* validadores por tipo: devolvem objecto limpo ou null */
  const V = {
    HELLO: (o) => (typeof o.name === 'string' && o.name.length <= 24 && isInt(o.v, 1, 99))
      ? { name: o.name.replace(/[^A-Za-z0-9 _\-]/g, '').slice(0, 24) || 'Jogador', v: o.v } : null,
    READY: (o) => (isFighter(o.f) && isInt(o.r, 0, 1)) ? { f: o.f, r: o.r } : null,
    START: (o) => (isFighter(o.hf) && isFighter(o.cf)) ? { hf: o.hf, cf: o.cf } : null,
    INPUT: (o) => (isInt(o.mx, -1, 1) && isInt(o.a, 0, 7) && isInt(o.b, 0, 1)) ? { mx: o.mx, a: o.a, b: o.b } : null,
    STATE: (o) => (isInt(o.ph, 0, 3) && isInt(o.cd, 0, 3) && isNum(o.tm, 0, 120) && isInt(o.r, 1, 9) &&
      Array.isArray(o.w) && o.w.length === 2 && isInt(o.w[0], 0, 9) && isInt(o.w[1], 0, 9) &&
      Array.isArray(o.f) && o.f.length === 2 && fighterRow(o.f[0]) && fighterRow(o.f[1]))
      ? { ph: o.ph, cd: o.cd, tm: o.tm, r: o.r, w: [o.w[0], o.w[1]], f: [o.f[0].slice(), o.f[1].slice()] } : null,
    HIT: (o) => (isInt(o.v, 0, 1) && isNum(o.d, 0, 400) && isInt(o.b, 0, 1) && isInt(o.k, 0, 5) && isInt(o.c, 0, 99))
      ? { v: o.v, d: o.d, b: o.b, k: o.k, c: o.c } : null,
    ROUND_END: (o) => (isInt(o.win, -1, 1) && isInt(o.ko, 0, 1) && Array.isArray(o.w) && o.w.length === 2 &&
      isInt(o.w[0], 0, 9) && isInt(o.w[1], 0, 9)) ? { win: o.win, ko: o.ko, w: [o.w[0], o.w[1]] } : null,
    MATCH_END: (o) => (isInt(o.win, -1, 1) && isNum(o.dur, 0, 99999) && Array.isArray(o.st) && o.st.length === 2 &&
      statRow(o.st[0]) && statRow(o.st[1])) ? { win: o.win, dur: o.dur, st: [o.st[0].slice(), o.st[1].slice()] } : null,
    PING: (o) => (isNum(o.ts, 0, 1e13) && isInt(o.r, 0, 1)) ? { ts: o.ts, r: o.r } : null,
    DISCONNECT: () => ({})
  };

  function validate(input) {
    let o = input;
    if (typeof input === 'string') {
      if (input.length === 0 || input.length > MAX_LEN) return null;
      try { o = JSON.parse(input); } catch (e) { return null; }
    }
    if (!o || typeof o !== 'object' || Array.isArray(o)) return null;
    if (typeof o.t !== 'string' || !Object.prototype.hasOwnProperty.call(V, o.t)) return null;
    if (!isInt(o.q, 0, 2147483647)) return null;
    const body = V[o.t](o);
    if (!body) return null;
    body.t = o.t; body.q = o.q;
    return body;
  }

  function build(type, fields, seq) {
    const o = Object.assign({ t: type, q: seq }, fields || {});
    const s = JSON.stringify(o);
    return s.length <= MAX_LEN ? s : null;
  }

  DK.Proto = { MAX_LEN, TYPES: Object.keys(V), validate, build, FIGHTER_IDS };
})();
