/* Dark Kombat - camada de rede sobre a ponte nativa Bluetooth (sem simulações: só funciona com a app Android). */
(function () {
  const DK = (globalThis.DK = globalThis.DK || {});
  const N = {
    state: 'idle', role: null, remoteName: '', remoteAddr: null, seq: 0, lastQ: {}, rx: 0, rtt: 0, dropped: 0,
    h: {}, pingTimer: null, watchTimer: null,
    available() { return !!globalThis.AndroidBridge && typeof globalThis.AndroidBridge.btHost === 'function'; },
    on(ev, fn) { this.h[ev] = fn; },
    fire(ev, ...args) { const f = this.h[ev]; if (f) { try { f(...args); } catch (e) { console.error(e); } } },
    host() { if (this.available()) { this.resetLinks(); globalThis.AndroidBridge.btHost(); } else this.fire('state', 'error', 'Bluetooth só está disponível na app Android.'); },
    scan() { if (this.available()) { this.resetLinks(); globalThis.AndroidBridge.btScan(); } else this.fire('state', 'error', 'Bluetooth só está disponível na app Android.'); },
    stopScan() { if (this.available()) globalThis.AndroidBridge.btStopScan(); },
    connect(addr) { if (this.available()) { this.resetLinks(); globalThis.AndroidBridge.btConnect(addr); } },
    resetLinks() { this.stopTimers(); this.seq = 0; this.lastQ = {}; this.remoteName = ''; },
    disconnect(notify) {
      if (!this.available()) return;
      if (notify && this.state === 'connected') this.send('DISCONNECT', {});
      this.stopTimers();
      try { globalThis.AndroidBridge.btDisconnect(); } catch (e) { /* ignora */ }
      this.state = 'idle';
    },
    send(type, fields) {
      if (this.state !== 'connected' || !this.available()) return false;
      const s = DK.Proto.build(type, fields, ++this.seq);
      if (!s) return false;
      try { return globalThis.AndroidBridge.btSend(s); } catch (e) { return false; }
    },
    stopTimers() { clearInterval(this.pingTimer); clearInterval(this.watchTimer); this.pingTimer = this.watchTimer = null; },
    startTimers() {
      this.stopTimers(); this.rx = performance.now();
      this.pingTimer = setInterval(() => this.send('PING', { ts: Math.round(performance.now()), r: 0 }), 1000);
      this.watchTimer = setInterval(() => {
        if (this.state === 'connected' && performance.now() - this.rx > 6000) {
          this.stopTimers(); try { globalThis.AndroidBridge.btDisconnect(); } catch (e) { /* ignora */ }
          this.state = 'closed'; this.fire('state', 'closed', 'Sem resposta do adversário (tempo esgotado).');
        }
      }, 1000);
    },
    /* chamado pelo Kotlin: NativeBT.on({...}) */
    _native(ev) {
      if (!ev || typeof ev !== 'object') return;
      if (ev.e === 'state') {
        this.state = ev.s; if (ev.role) this.role = ev.role;
        if (ev.s === 'connected') { this.remoteName = String(ev.name || 'Adversário').slice(0, 24); this.remoteAddr = ev.addr || this.remoteAddr; this.seq = 0; this.lastQ = {}; this.startTimers(); }
        if (ev.s === 'closed' || ev.s === 'error' || ev.s === 'idle') this.stopTimers();
        this.fire('state', ev.s, ev.msg || '', ev);
      } else if (ev.e === 'device') this.fire('device', ev);
      else if (ev.e === 'scan_end') this.fire('scanEnd');
      else if (ev.e === 'msg') {
        const m = DK.Proto.validate(ev.d);
        if (!m) { this.dropped++; return; }
        this.rx = performance.now();
        if (m.t === 'INPUT' || m.t === 'STATE') { // descarta mensagens antigas/fora de ordem
          if (this.lastQ[m.t] != null && m.q <= this.lastQ[m.t]) return;
          this.lastQ[m.t] = m.q;
        }
        if (m.t === 'PING') { if (m.r === 0) this.send('PING', { ts: m.ts, r: 1 }); else this.rtt = Math.round(performance.now() - m.ts); return; }
        this.fire('msg', m);
      }
    }
  };
  globalThis.NativeBT = { on(ev) { N._native(ev); } };
  DK.Net = N;
})();
