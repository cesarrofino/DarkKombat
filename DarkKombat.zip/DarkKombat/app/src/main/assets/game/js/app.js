/* Dark Kombat - aplicação: menus, fluxo de jogo, HUD, Bluetooth (lobby) e ligação a tudo o resto. */
(function () {
  const DK = globalThis.DK, S = DK.Settings.data, F = DK.Sim.FIGHTERS, IDS = ['kira', 'ren'];
  const $ = (id) => document.getElementById(id);
  const STEP = 1 / 60, MAIN = ['splash', 'loading', 'menu', 'fighters', 'settings', 'bt', 'hud'];
  let screen = 'splash', game = null, last = 0, appPaused = false, menuView = null, fgMode = 'solo', btLast = null, lobby = null, lastBtAddr = null;

  const other = (id) => IDS.find((x) => x !== id) || id;
  const bridge = () => globalThis.AndroidBridge || null;
  const vib = (ms) => { if (!S.vibration) return; try { const b = bridge(); if (b && b.vibrate) b.vibrate(ms); else if (navigator.vibrate) navigator.vibrate(ms); } catch (e) { /* ignora */ } };
  function toast(msg, ms) { const t = $('toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toast.h); toast.h = setTimeout(() => t.classList.remove('show'), ms || 2600); }
  function fatal(msg) { const f = $('fatal'); f.hidden = false; f.textContent = 'Erro: ' + msg; }
  const click = () => DK.Audio.sfx('click', 0.8);

  function go(name) {
    MAIN.forEach((n) => $(n).classList.toggle('show', n === name));
    screen = name;
  }
  const overlay = (id, on) => $(id).classList.toggle('show', !!on);
  const isOpen = (id) => $(id).classList.contains('show');

  // ---------------- retratos (desenhados no momento, sem imagens externas) ----------------
  function portrait(def, el) {
    const p3 = DK.Gfx.renderPortrait && DK.Gfx.renderPortrait(def, 160);
    if (p3) { el.innerHTML = ''; el.appendChild(p3); return; }
    const c = document.createElement('canvas'); c.width = c.height = 96; const g = c.getContext('2d');
    const hex = (n) => '#' + ('000000' + n.toString(16)).slice(-6), A = hex(def.colors.a), B = hex(def.colors.b);
    const bg = g.createLinearGradient(0, 0, 96, 96); bg.addColorStop(0, '#0b1440'); bg.addColorStop(1, '#25083a'); g.fillStyle = bg; g.fillRect(0, 0, 96, 96);
    g.fillStyle = B; g.globalAlpha = 0.25; g.fillRect(0, 70, 96, 3); g.globalAlpha = 1;
    g.fillStyle = '#0b0e1a'; g.beginPath(); g.moveTo(8, 96); g.quadraticCurveTo(48, 62, 88, 96); g.fill();
    g.strokeStyle = A; g.lineWidth = 3; g.beginPath(); g.moveTo(22, 90); g.quadraticCurveTo(48, 70, 74, 90); g.stroke();
    g.fillStyle = hex(def.colors.skin); g.fillRect(41, 58, 14, 14);
    g.beginPath(); g.ellipse(48, 42, 19, 23, 0, 0, 7); g.fill();
    g.fillStyle = hex(def.colors.hair);
    if (def.id === 'kira') { g.beginPath(); g.ellipse(48, 30, 21, 16, 0, Math.PI, 0); g.fill(); g.fillRect(27, 28, 7, 28); g.fillStyle = A; g.fillRect(60, 14, 5, 34); g.fillStyle = B; g.fillRect(66, 18, 3, 26); }
    else { g.beginPath(); g.ellipse(48, 27, 20, 12, 0, Math.PI, 0); g.fill(); g.fillStyle = A; g.fillRect(28, 26, 40, 3); g.strokeStyle = B; g.lineWidth = 2; g.beginPath(); g.moveTo(58, 34); g.lineTo(64, 52); g.stroke(); }
    g.fillStyle = '#05060f'; g.fillRect(31, 40, 34, 7); g.fillStyle = B; g.fillRect(34, 42, 10, 3); g.fillRect(52, 42, 10, 3);
    g.fillStyle = '#7a3a3a'; g.fillRect(42, 57, 12, 2);
    el.innerHTML = ''; el.appendChild(c);
  }
  function portraitText(def) { const d = document.createElement('div'); portrait(def, d); return d.firstChild; }

  // ---------------- cartões de lutadores ----------------
  function cardHTML(id) {
    const d = F[id], bar = (n, v) => '<div class="stat"><span>' + n + '</span><i style="--v:' + v * 10 + '%"></i></div>';
    return '<div class="port"></div><div class="info"><b>' + d.name + '</b><small>' + d.style + '</small>' + bar('Força', d.stats.str) + bar('Veloc.', d.stats.spd) + bar('Defesa', d.stats.def) + '</div>';
  }
  function buildCards(container, selected, onPick) {
    container.innerHTML = '';
    IDS.forEach((id) => {
      const c = document.createElement('div'); c.className = 'card' + (id === selected ? ' sel' : ''); c.innerHTML = cardHTML(id);
      portrait(F[id], c.querySelector('.port')); c.addEventListener('click', () => { click(); onPick(id); });
      container.appendChild(c);
    });
  }
  function markSelected(container, id) { const k = container.children; for (let i = 0; i < k.length; i++) k[i].classList.toggle('sel', IDS[i] === id); }

  function setupMenuScene() {
    const a = F[S.fighter], b = F[other(S.fighter)];
    DK.Gfx.sign = 1; DK.Gfx.showFighters(a, b);
    const fa = DK.Sim.makeFighter(a, 0), fb = DK.Sim.makeFighter(b, 1);
    fa.x = -1.15; fb.x = 1.15; fa.face = 1; fb.face = -1; menuView = { f: [fa, fb] };
  }
  function openFighters(m) {
    fgMode = m; $('diffRow').style.display = m === 'solo' ? 'flex' : 'none';
    $('fgTitle').textContent = m === 'solo' ? 'ESCOLHE O TEU LUTADOR' : 'LUTADORES';
    $('fgGo').textContent = m === 'solo' ? 'LUTAR' : 'CONFIRMAR';
    buildCards($('cards'), S.fighter, pickFighter); refreshDiff(); go('fighters');
  }
  function pickFighter(id) {
    S.fighter = id; DK.Settings.save(); markSelected($('cards'), id);
    DK.Gfx.replaceFighter(0, F[id]); DK.Gfx.replaceFighter(1, F[other(id)]);
    menuView.f[0] = Object.assign(DK.Sim.makeFighter(F[id], 0), { x: -1.15, face: 1 }); menuView.f[1] = Object.assign(DK.Sim.makeFighter(F[other(id)], 1), { x: 1.15, face: -1 });
  }
  function refreshDiff() { document.querySelectorAll('#diffRow button').forEach((b) => b.classList.toggle('on', b.dataset.d === S.diff)); }

  // ---------------- jogo ----------------
  function startGame(o) {
    stopGame(false);
    const defs = [F[o.p1], F[o.p2]], client = o.mode === 'client';
    game = { mode: o.mode, defs, local: client ? 1 : 0, view: client ? -1 : 1, paused: false, over: false, acc: 0, sendT: 0, stT: 0, edge: 0, lastMx: 9, lastB: 9, cache: {}, remote: { mx: 0, a: 0, b: 0 }, diff: o.diff };
    game.sim = client ? new DK.Sim.Mirror(defs[0], defs[1]) : new DK.Sim.Match(defs[0], defs[1]);
    if (o.mode === 'solo') game.ai = new DK.AI(o.diff || 'normal');
    DK.Gfx.sign = game.view; DK.Gfx.showFighters(defs[0], defs[1]); DK.Gfx.snapCamera(); DK.Gfx.paused = false;
    const L = game.local, R = 1 - L;
    $('p1Name').textContent = defs[L].name; $('p2Name').textContent = defs[R].name;
    $('p1Lvl').textContent = 'LVL ' + defs[L].level; $('p2Lvl').textContent = 'LVL ' + defs[R].level;
    portrait(defs[L], $('p1Port')); portrait(defs[R], $('p2Port'));
    ['result', 'pause', 'disc', 'confirm'].forEach((i) => overlay(i, false));
    $('banner').className = 'banner'; $('comboTxt').className = 'combo';
    document.body.classList.remove('vict', 'def');
    DK.Input.reset(); DK.Input.enabled = true; DK.Gfx.orbitOn = true; DK.Gfx.resetOrbit(); DK.Audio.music('music_fight'); go('hud');
    $('pauseBtn').style.display = o.mode === 'solo' ? '' : 'none';
    if (o.mode === 'host' || o.mode === 'client') DK.Net.send('PING', { ts: Math.round(performance.now()), r: 0 });
  }
  function stopGame() {
    if (!game) return; game = null; DK.Input.enabled = false; DK.Input.reset(); DK.Gfx.orbitOn = false; DK.Gfx.resetOrbit();
    ['result', 'pause', 'disc', 'confirm'].forEach((i) => overlay(i, false));
    document.body.classList.remove('vict', 'def');
  }
  function toMenu() {
    const was = game && game.mode !== 'solo';
    stopGame(); if (was || DK.Net.state === 'connected') DK.Net.disconnect(true);
    setupMenuScene(); DK.Audio.music('music_menu'); go('menu');
  }

  function updateGame(dt) {
    const g = game, sim = g.sim;
    if (g.paused || g.netLost) return;
    { const me = sim.f[g.local]; if (me) DK.Input.backDir = -(me.face || 1) * g.view; }   // para a esquiva (ver input.js)
    if (g.mode === 'client') {
      const raw = DK.Input.read(), mx = raw.mx * g.view;
      g.edge |= (raw.p ? 1 : 0) | (raw.k ? 2 : 0) | (raw.s ? 4 : 0); g.sendT += dt;
      if (g.edge || mx !== g.lastMx || raw.b !== g.lastB || g.sendT >= 0.033) {
        if (g.sendT >= 0.016 || g.edge) { DK.Net.send('INPUT', { mx, a: g.edge, b: raw.b ? 1 : 0 }); g.edge = 0; g.lastMx = mx; g.lastB = raw.b; g.sendT = 0; }
      }
      sim.step(dt);
    } else {
      g.acc = Math.min(g.acc + dt, STEP * 4);
      if (g.acc >= STEP) {
        const raw = DK.Input.read(); let first = true;
        while (g.acc >= STEP) {
          g.acc -= STEP;
          const i0 = first ? { mx: raw.mx, p: raw.p, k: raw.k, s: raw.s, b: raw.b } : { mx: raw.mx, p: 0, k: 0, s: 0, b: raw.b };
          let i1;
          if (g.mode === 'solo') i1 = g.ai.think(sim.f[1], sim.f[0], sim, STEP);
          else { const r = g.remote; i1 = { mx: r.mx, p: first && (r.a & 1) ? 1 : 0, k: first && (r.a & 2) ? 1 : 0, s: first && (r.a & 4) ? 1 : 0, b: r.b }; }
          sim.step(STEP, i0, i1);
          if (first && g.mode === 'host') g.remote.a = 0;
          first = false;
        }
      }
      if (g.mode === 'host') { g.stT += dt; if (g.stT >= 0.05) { g.stT = 0; DK.Net.send('STATE', sim.snapshot()); } }
    }
    const ev = sim.drain();
    for (const e of ev) {
      onEvent(e);
      if (g.mode === 'host') {
        if (e.t === 'hit') DK.Net.send('HIT', { v: e.who, d: e.dmg, b: e.blocked, k: e.k, c: e.c });
        else if (e.t === 'round') DK.Net.send('ROUND_END', { win: e.win, ko: e.ko, w: e.w });
        else if (e.t === 'match') { DK.Net.send('STATE', sim.snapshot()); DK.Net.send('MATCH_END', { win: e.win, dur: e.dur, st: e.st }); }
      }
    }
  }

  // ---------------- eventos de combate: efeitos, sons, mensagens ----------------
  function banner(text, long) {
    const b = $('banner'); b.className = 'banner'; void b.offsetWidth; b.textContent = text; b.className = 'banner show' + (long ? ' long' : '');
  }
  function flash(a) { const f = $('flash'); f.style.opacity = a; setTimeout(() => { f.style.opacity = 0; }, 70); }
  let dmgIdx = 0;
  function dmgNumber(x, y, text, cls) {
    const layer = $('dmgLayer'); let el = layer.children[dmgIdx % 8];
    if (!el) { el = document.createElement('div'); layer.appendChild(el); } dmgIdx++;
    el.className = 'dmg ' + (cls || ''); el.textContent = text; el.style.left = x + 'px'; el.style.top = y + 'px';
    el.style.animation = 'none'; void el.offsetWidth; el.style.animation = '';
  }
  function onEvent(e) {
    const g = game; if (!g) return; const sim = g.sim, A = DK.Audio;
    if (e.t === 'cd') {
      if (e.n === 3) { banner('RONDA ' + sim.round, false); A.sfx('beep', 0.8); }
      else if (e.n > 0) { banner(String(e.n), false); A.sfx('beep', 0.8); }
      else { banner('LUTA!', false); A.sfx('go', 1); }
    } else if (e.t === 'swing') {
      if (e.s === 'special') { A.sfx('special', 0.9); DK.Gfx.ring(sim.f[e.who].x, g.defs[e.who].colors.a, 3); DK.Gfx.punchFov(3); }
      else if (e.s === 'kickH') A.sfx('spin', 0.85);
      else if (e.s === 'kickF') A.sfx('whoosh', 0.75, 0.9);
      else A.sfx('whoosh', 0.5, 1.15);
    } else if (e.t === 'hit') {
      const v = sim.f[e.who], att = g.defs[1 - e.who], k = e.k;
      const y = k === 3 ? 1.55 : k >= 2 && k < 4 ? 1.15 : 1.35, hx = v.x + v.face * 0.3;
      if (k === 4 && !e.blocked) {   // golpe ESPECIAL: único que enche o ecrã com clarão grande
        DK.Gfx.emitBlast(hx, y, 0.1, 1.6, false);
        DK.Gfx.emitSparks(hx, y, 0.1, 0x7fcfff, 26, 7); DK.Gfx.emitSparks(hx, y, 0.1, 0xffffff, 12, 5);
      } else {                        // golpes normais e defesas: impacto pequeno que não tapa o personagem
        const pw = e.blocked ? 0.6 : 0.75 + Math.min(0.45, e.dmg * 0.03);
        DK.Gfx.emitHit(hx, y, 0.1, e.blocked ? 0x7fe8ff : 0xcfeaff, pw);
        DK.Gfx.emitSparks(hx, y, 0.1, e.blocked ? 0x7fe8ff : 0x9fdcff, e.blocked ? 3 : 5 + Math.min(4, Math.round(e.dmg * 0.35)), e.blocked ? 2.5 : 3.8);
      }
      if (e.blocked) { A.sfx('block', 0.9); DK.Gfx.addShake(0.02); }
      else {
        A.sfx(k <= 1 ? 'punch' : k <= 3 ? 'kick' : 'hit', 1); if (k === 4) { A.sfx('hit', 1); DK.Gfx.ring(v.x, att.colors.b, 5); flash(0.25); }
        DK.Gfx.addShake(k === 4 ? 0.32 : 0.06);
        if (e.who === g.local) vib(k === 4 ? 90 : 30);
      }
      const p = DK.Gfx.project(hx, y + 0.5, 0); dmgNumber(p.x, p.y, (e.blocked ? '🛡 ' : '') + Math.round(e.dmg), e.blocked ? 'blk' : (e.dmg >= 14 ? 'big' : ''));
      if (!e.blocked && e.c >= 2) {
        const c = $('comboTxt'); c.className = 'combo'; void c.offsetWidth; c.textContent = (e.name ? e.name + ' ' : 'COMBO ') + 'x' + e.c;
        c.style.left = (1 - e.who === g.local ? '6%' : '58%'); c.className = 'combo show';
      }
    } else if (e.t === 'round') {
      A.sfx('ko', 1); flash(0.35); DK.Gfx.addShake(0.2);
      banner(e.ko ? 'K.O.!' : 'TEMPO!', true);
      setTimeout(() => { if (game === g) banner(e.win < 0 ? 'EMPATE' : g.defs[e.win].name + ' VENCE A RONDA', true); }, 1300);
    } else if (e.t === 'match') {
      g.over = true; showResult(e);
    }
  }
  function showResult(e) {
    const g = game; if (!g) return;
    setTimeout(() => {
      if (game !== g) return;
      const me = g.local, draw = e.win < 0, won = e.win === me;
      $('resTitle').textContent = draw ? 'EMPATE' : won ? 'VITÓRIA' : 'DERROTA';
      document.body.classList.toggle('vict', won); document.body.classList.toggle('def', !draw && !won);
      $('resWinner').textContent = draw ? '—' : g.defs[e.win].name + ' VENCEU';
      const s = e.st, a = s[me], b = s[1 - me], t = Math.floor(e.dur / 60) + ':' + ('0' + (e.dur % 60)).slice(-2);
      const row = (l, x, y) => '<span class="h">' + l + '</span><span class="v">' + x + '</span><span class="v">' + y + '</span>';
      $('resStats').innerHTML = '<span></span><span class="h">' + g.defs[me].name + '</span><span class="h">' + g.defs[1 - me].name + '</span>' +
        row('Duração', t, t) + row('Golpes acertados', a[0], b[0]) + row('Dano causado', a[1], b[1]) + row('Melhor combo', a[2], b[2]) + row('Defesas', a[3], b[3]);
      const again = $('resAgain');
      if (g.mode === 'client') { again.textContent = 'AGUARDAR ANFITRIÃO'; again.disabled = true; } else { again.textContent = 'JOGAR NOVAMENTE'; again.disabled = false; }
      overlay('result', true); DK.Audio.stopMusic(); DK.Audio.sfx(won ? 'win' : draw ? 'click' : 'lose', 1); DK.Input.enabled = false;
    }, 1500);
  }

  // ---------------- HUD ----------------
  function hudSet(key, id, fn) { const c = game.cache; return c[key] === id ? false : ((c[key] = id), fn(), true); }
  function pips(n) { return '<i class="' + (n >= 1 ? 'on' : '') + '"></i><i class="' + (n >= 2 ? 'on' : '') + '"></i>'; }
  function updateHud() {
    const g = game, sim = g.sim, L = g.local, R = 1 - L, a = sim.f[L], b = sim.f[R];
    const side = (p, f) => {
      const r = Math.max(0, Math.min(1, f.hp / f.maxHp)), pc = Math.ceil(r * 100);
      hudSet(p + 'hp', pc, () => { $(p + 'Hp').style.transform = 'scaleX(' + r + ')'; $(p + 'Trail').style.transform = 'scaleX(' + r + ')'; $(p + 'Pct').textContent = pc + '%'; $(p + 'Hp').classList.toggle('low', r < 0.25); });
      const e = Math.round(f.en); hudSet(p + 'en', e, () => { $(p + 'En').style.transform = 'scaleX(' + Math.min(1, e / 100) + ')'; $(p + 'EnBox').classList.toggle('full', e >= DK.Sim.SPECIAL_COST); });
    };
    side('p1', a); side('p2', b);
    const w = sim.wins; hudSet('w', w[L] + ',' + w[R], () => { $('p1Pips').innerHTML = pips(w[L]); $('p2Pips').innerHTML = pips(w[R]); });
    const t = Math.ceil(sim.time); hudSet('t', t, () => { $('timer').textContent = '0' + Math.floor(t / 60) + ':' + ('0' + (t % 60)).slice(-2); $('timer').classList.toggle('low', t <= 10); });
    hudSet('r', sim.round, () => { $('roundTxt').textContent = 'Rnd ' + sim.round; });
  }

  // ---------------- pausa / confirmações / saída ----------------
  let cfYes = null;
  function confirmBox(title, text, yes) { $('cfTitle').textContent = title; $('cfText').textContent = text; cfYes = yes; overlay('confirm', true); }
  function closeConfirm() { overlay('confirm', false); cfYes = null; }
  function pauseGame(on) {
    const g = game; if (!g || g.mode !== 'solo' || g.over) return;
    g.paused = on; DK.Gfx.paused = on; overlay('pause', on); DK.Input.reset();
  }
  function askQuit() {
    const bt = game && game.mode !== 'solo';
    confirmBox('ABANDONAR PARTIDA?', bt ? 'A ligação Bluetooth será terminada e o adversário será avisado.' : 'O progresso desta partida será perdido.', () => { closeConfirm(); toMenu(); });
  }
  function onBack() {
    if (isOpen('confirm')) { closeConfirm(); return true; }
    if (isOpen('result')) { toMenu(); return true; }
    if (isOpen('disc')) { toMenu(); return true; }
    if (game) { if (isOpen('pause')) pauseGame(false); else if (game.mode === 'solo') pauseGame(true); else askQuit(); return true; }
    if (screen === 'menu') { confirmBox('SAIR DO JOGO?', 'Queres mesmo sair do Dark Kombat?', () => { closeConfirm(); const b = bridge(); if (b && b.exitApp) b.exitApp(); else toast('Fecha o separador para sair.'); }); return true; }
    if (screen === 'bt') { btLeave(); return true; }
    if (screen === 'settings' || screen === 'fighters') { DK.Settings.save(); go('menu'); return true; }
    return true;
  }

  // ---------------- definições ----------------
  function applyUi() { document.documentElement.style.setProperty('--ui', S.ui); }
  function syncSettings() {
    document.querySelectorAll('#sQuality button').forEach((b) => b.classList.toggle('on', b.dataset.q === S.quality));
    $('sMusic').value = Math.round(S.music * 100); $('sSfx').value = Math.round(S.sfx * 100); $('sJoy').value = Math.round(S.joy * 100); $('sUi').value = Math.round(S.ui * 100);
    const t = (id, on, a, b) => { $(id).textContent = on ? a : b; $(id).classList.toggle('on', on); };
    t('sVib', S.vibration, 'LIGADA', 'DESLIGADA'); t('sFx', S.reduceFx, 'LIGADO', 'DESLIGADO'); $('sName').value = S.name;
  }
  function bindSettings() {
    document.querySelectorAll('#sQuality button').forEach((b) => b.addEventListener('click', () => { click(); S.quality = b.dataset.q; DK.Gfx.setQuality(S.quality); syncSettings(); DK.Settings.save(); }));
    $('sMusic').addEventListener('input', (e) => { S.music = e.target.value / 100; DK.Audio.applyVolumes(); });
    $('sSfx').addEventListener('input', (e) => { S.sfx = e.target.value / 100; DK.Audio.applyVolumes(); });
    $('sSfx').addEventListener('change', () => DK.Audio.sfx('punch', 1));
    $('sJoy').addEventListener('input', (e) => { S.joy = e.target.value / 100; });
    $('sUi').addEventListener('input', (e) => { S.ui = e.target.value / 100; applyUi(); });
    $('sVib').addEventListener('click', () => { S.vibration = !S.vibration; syncSettings(); if (S.vibration) vib(40); click(); });
    $('sFx').addEventListener('click', () => { S.reduceFx = !S.reduceFx; DK.Gfx.setReduce(S.reduceFx); syncSettings(); click(); });
    $('sName').addEventListener('input', (e) => { const v = e.target.value.replace(/[^A-Za-z0-9 _\-]/g, '').slice(0, 16); if (v !== e.target.value) e.target.value = v; S.name = v || 'Jogador'; });
    ['sMusic', 'sSfx', 'sJoy', 'sUi', 'sName'].forEach((id) => $(id).addEventListener('change', () => DK.Settings.save()));
    $('setBack').addEventListener('click', () => { click(); DK.Settings.save(); go(game ? 'hud' : 'menu'); if (game) overlay('pause', true); });
  }
  setInterval(() => { if (screen === 'settings') $('perfInfo').textContent = 'Desempenho medido: ' + DK.Gfx.fps + ' FPS · Qualidade em uso: ' + ({ low: 'BAIXO', medium: 'MÉDIO', high: 'ALTO' })[DK.Gfx.levelName()]; }, 1000);

  // ---------------- Bluetooth: ecrãs e lobby ----------------
  const BT_SUBS = ['btHome', 'btHost', 'btScan', 'btLobby'];
  function btSub(n) { BT_SUBS.forEach((s) => $(s).classList.toggle('show', s === n)); $('btRetry').hidden = true; }
  function btStatus(role, text) { $('btRole').textContent = role || '—'; $('btState').textContent = text || ''; }
  function btError(msg, retry) {
    btSub(''); const e = $('btErr'); e.hidden = false; e.textContent = msg; $('btRetry').hidden = false; btLast = retry || btLast; btStatus(null, 'Erro');
  }
  function btClearErr() { $('btErr').hidden = true; $('btRetry').hidden = true; }
  function openBt() {
    if (!DK.Net.available()) { toast('O Bluetooth só funciona na app Android instalada.', 3500); return; }
    btClearErr(); btSub('btHome'); btStatus(null, 'Pronto'); go('bt');
  }
  function btHostStart() { btClearErr(); btLast = { t: 'host' }; btStatus('ANFITRIÃO', 'A preparar…'); btSub('btHost'); $('btHostMsg').textContent = 'A preparar…'; DK.Net.host(); }
  function btScanStart() {
    btClearErr(); btLast = { t: 'scan' }; btStatus('CLIENTE', 'A procurar…'); btSub('btScan'); $('btList').innerHTML = ''; $('btScanMsg').textContent = 'A procurar partidas…'; DK.Net.scan();
  }
  function btLeave() { DK.Net.disconnect(true); if (game) { stopGame(); setupMenuScene(); DK.Audio.music('music_menu'); } go('menu'); }
  function addDevice(ev) {
    const list = $('btList'); if (list.querySelector('[data-a="' + ev.addr + '"]')) return;
    const d = document.createElement('div'); d.className = 'dev'; d.dataset.a = ev.addr;
    d.innerHTML = '<span></span><small></small>'; d.firstChild.textContent = ev.name; d.lastChild.textContent = (ev.bonded ? 'emparelhado · ' : '') + ev.addr;
    d.addEventListener('click', () => { click(); lastBtAddr = ev.addr; btLast = { t: 'connect', addr: ev.addr }; btClearErr(); btStatus('CLIENTE', 'A ligar a ' + ev.name + '…'); DK.Net.connect(ev.addr); });
    if (ev.bonded) list.insertBefore(d, list.firstChild); else list.appendChild(d);
    $('btScanMsg').textContent = 'Escolhe o anfitrião:';
  }
  function onConnected(ev) {
    const host = ev.role === 'host';
    if (game) { stopGame(); setupMenuScene(); }
    btClearErr(); go('bt'); btSub('btLobby'); btStatus(host ? 'ANFITRIÃO' : 'CLIENTE', 'Ligado a ' + DK.Net.remoteName);
    lobby = { oppReady: false, oppFighter: null, meReady: false, host };
    $('lbMe').textContent = S.name; $('lbOpp').textContent = DK.Net.remoteName;
    buildCards($('btCards'), S.fighter, (id) => { S.fighter = id; DK.Settings.save(); markSelected($('btCards'), id); lobby.meReady = false; sendReady(0); lobbyUpdate(); });
    DK.Net.send('HELLO', { name: S.name, v: 1 }); sendReady(0); lobbyUpdate();
    DK.Audio.music('music_menu');
  }
  function sendReady(r) { DK.Net.send('READY', { f: S.fighter, r }); }
  function lobbyUpdate() {
    if (!lobby) return; const go_ = $('lbGo'), msg = $('lbMsg');
    if (lobby.host) {
      go_.textContent = 'INICIAR PARTIDA'; go_.disabled = !lobby.oppReady;
      msg.textContent = lobby.oppReady ? 'O adversário está pronto (' + (lobby.oppFighter || '').toUpperCase() + '). Podes iniciar.' : 'À espera que o adversário escolha e confirme PRONTO.';
    } else {
      go_.textContent = lobby.meReady ? 'CANCELAR PRONTO' : 'PRONTO'; go_.disabled = false;
      msg.textContent = lobby.meReady ? 'À espera que o anfitrião inicie a partida…' : 'Escolhe o teu lutador e carrega em PRONTO.';
    }
  }
  function onNetMsg(m) {
    if (m.t === 'HELLO') { $('lbOpp').textContent = m.name; DK.Net.remoteName = m.name; if (screen === 'bt') btStatus(null, 'Ligado a ' + m.name); }
    else if (m.t === 'READY') { if (lobby) { lobby.oppFighter = m.f; lobby.oppReady = !!m.r; lobbyUpdate(); } }
    else if (m.t === 'START') { if (!lobby || lobby.host) return; startGame({ mode: 'client', p1: m.hf, p2: m.cf }); }
    else if (m.t === 'INPUT') { if (game && game.mode === 'host') { game.remote.mx = m.mx; game.remote.a |= m.a; game.remote.b = m.b; } }
    else if (m.t === 'STATE') { if (game && game.mode === 'client' && !game.netLost) game.sim.apply(m); }
    else if (m.t === 'HIT') { if (game && game.mode === 'client') onEvent({ t: 'hit', who: m.v, dmg: m.d, blocked: m.b, k: m.k, c: m.c, name: '' }); }
    else if (m.t === 'ROUND_END') { if (game && game.mode === 'client') onEvent({ t: 'round', win: m.win, ko: m.ko, w: m.w }); }
    else if (m.t === 'MATCH_END') { if (game && game.mode === 'client') onEvent({ t: 'match', win: m.win, dur: Math.round(m.dur), st: m.st }); }
    else if (m.t === 'DISCONNECT') { onClosed('O adversário terminou a ligação.'); }
  }
  function onClosed(msg) {
    const wasGame = !!game && game.mode !== 'solo';
    DK.Net.stopTimers();
    if (wasGame) {
      game.netLost = true; DK.Input.enabled = false; overlay('result', false); overlay('pause', false); overlay('confirm', false);
      $('discMsg').textContent = msg || 'A ligação Bluetooth foi interrompida.'; $('discRetry').textContent = game.mode === 'client' ? 'TENTAR RELIGAR' : 'AGUARDAR NOVA LIGAÇÃO'; overlay('disc', true);
    } else if (screen === 'bt') { btError(msg || 'Ligação terminada.', btLast); lobby = null; }
  }
  function bindNet() {
    DK.Net.on('state', (s, msg, ev) => {
      if (s === 'preparing') { btStatus(ev.role === 'host' ? 'ANFITRIÃO' : 'CLIENTE', msg || 'A preparar…'); }
      else if (s === 'hosting') { btSub('btHost'); btStatus('ANFITRIÃO', 'À espera'); $('btHostMsg').textContent = msg; $('btMyName').textContent = ev.name || 'este telemóvel'; }
      else if (s === 'scanning') { btStatus('CLIENTE', 'A procurar…'); }
      else if (s === 'connecting') { btStatus('CLIENTE', msg || 'A ligar…'); }
      else if (s === 'connected') onConnected(ev);
      else if (s === 'closed') onClosed(msg);
      else if (s === 'error') { if (game && game.mode !== 'solo') onClosed(msg); else btError(msg || 'Erro Bluetooth.', btLast); }
    });
    DK.Net.on('device', addDevice);
    DK.Net.on('scanEnd', () => { if (!$('btList').children.length) $('btScanMsg').textContent = 'Nenhuma partida encontrada. Confirma que o outro telemóvel criou a partida e está visível.'; else $('btScanMsg').textContent = 'Escolhe o anfitrião:'; });
    DK.Net.on('msg', onNetMsg);
  }
  function retryBt() {
    if (!btLast) { btSub('btHome'); btClearErr(); return; }
    if (btLast.t === 'host') btHostStart(); else if (btLast.t === 'scan') btScanStart();
    else { btClearErr(); btStatus('CLIENTE', 'A ligar…'); DK.Net.connect(btLast.addr); }
  }

  // ---------------- ligações dos botões ----------------
  function bindUi() {
    const on = (id, fn) => $(id).addEventListener('click', (e) => { e.preventDefault(); fn(); });
    on('mSolo', () => { click(); openFighters('solo'); });
    on('mBt', () => { click(); openBt(); });
    on('mFighters', () => { click(); openFighters('view'); });
    on('mSettings', () => { click(); syncSettings(); go('settings'); });
    on('mExit', () => { click(); onBack(); });
    on('fgBack', () => { click(); DK.Settings.save(); go('menu'); });
    on('fgGo', () => { click(); DK.Settings.save(); if (fgMode === 'solo') startGame({ mode: 'solo', p1: S.fighter, p2: other(S.fighter), diff: S.diff }); else go('menu'); });
    document.querySelectorAll('#diffRow button').forEach((b) => b.addEventListener('click', () => { click(); S.diff = b.dataset.d; refreshDiff(); DK.Settings.save(); }));
    bindSettings();
    // pausa
    on('pauseBtn', () => { click(); pauseGame(true); });
    on('paResume', () => { click(); pauseGame(false); });
    on('paSettings', () => { click(); overlay('pause', false); syncSettings(); go('settings'); });
    on('paQuit', () => { click(); askQuit(); });
    on('cfNo', () => { click(); closeConfirm(); });
    on('cfYes', () => { click(); const f = cfYes; if (f) f(); });
    // resultado
    on('resAgain', () => {
      click(); const g = game; if (!g) return;
      if (g.mode === 'solo') startGame({ mode: 'solo', p1: g.defs[0].id, p2: g.defs[1].id, diff: g.diff });
      else if (g.mode === 'host') { if (DK.Net.send('START', { hf: g.defs[0].id, cf: g.defs[1].id })) startGame({ mode: 'host', p1: g.defs[0].id, p2: g.defs[1].id }); else onClosed('Ligação perdida.'); }
    });
    on('resMenu', () => { click(); toMenu(); });
    // ligação perdida
    on('discRetry', () => {
      click(); const g = game; if (!g) return;
      overlay('disc', false); go('bt'); const client = g.mode === 'client'; stopGame();
      if (client && lastBtAddr) { btLast = { t: 'connect', addr: lastBtAddr }; btClearErr(); btSub(''); btStatus('CLIENTE', 'A religar…'); DK.Net.connect(lastBtAddr); }
      else if (!client) btHostStart(); else btSub('btHome');
    });
    on('discMenu', () => { click(); toMenu(); });
    // Bluetooth
    on('btCreate', () => { click(); btHostStart(); });
    on('btSearch', () => { click(); btScanStart(); });
    on('btCancelHome', () => { click(); go('menu'); });
    on('btHostCancel', () => { click(); DK.Net.disconnect(false); btClearErr(); btSub('btHome'); btStatus(null, 'Pronto'); });
    on('btRescan', () => { click(); btScanStart(); });
    on('btScanCancel', () => { click(); DK.Net.stopScan(); DK.Net.disconnect(false); btClearErr(); btSub('btHome'); btStatus(null, 'Pronto'); });
    on('lbLeave', () => { click(); btLeave(); });
    on('lbGo', () => {
      click(); if (!lobby) return;
      if (lobby.host) {
        if (!lobby.oppReady || !lobby.oppFighter) return;
        if (DK.Net.send('START', { hf: S.fighter, cf: lobby.oppFighter })) startGame({ mode: 'host', p1: S.fighter, p2: lobby.oppFighter }); else onClosed('Ligação perdida.');
      } else { lobby.meReady = !lobby.meReady; sendReady(lobby.meReady ? 1 : 0); lobbyUpdate(); }
    });
    on('btRetryBtn', () => { click(); retryBt(); });
    on('btRetryCancel', () => { click(); DK.Net.disconnect(false); btClearErr(); btSub('btHome'); btStatus(null, 'Pronto'); });
  }

  // ---------------- ciclo principal ----------------
  function frame(ts) {
    requestAnimationFrame(frame);
    if (appPaused) return;
    const raw = last ? (ts - last) / 1000 : 0.016; last = ts; const dt = Math.min(0.05, raw);
    DK.Gfx.perfTick(Math.min(raw, 0.5));
    try {
      if (game) { updateGame(dt); if (game) { updateHud(); DK.Gfx.draw(dt, game.sim, 'game'); } }
      else DK.Gfx.draw(dt, menuView || { f: [] }, 'menu');
    } catch (e) { console.error(e); if (!frame.err) { frame.err = true; toast('Erro interno: ' + e.message, 5000); } }
  }

  globalThis.DKApp = {
    onBack,
    onPause() {
      appPaused = true; DK.Gfx.paused = true; DK.Audio.suspend();
      if (game && game.mode === 'solo' && !game.over) { game.paused = true; overlay('pause', true); }
      DK.Input.reset();
    },
    onResume() { appPaused = false; last = 0; DK.Gfx.paused = !!(game && game.paused); DK.Audio.resume(); DK.Gfx.perfSkip = 2; }
  };

  function boot() {
    DK.Settings.load();
    if (!globalThis.THREE) { fatal('Falta o ficheiro js/three.min.js. Volte a compilar (a tarefa Gradle "fetchThree" descarrega-o) ou copie-o para app/src/main/assets/game/js/.'); return; }
    try { DK.Gfx.init($('gl')); } catch (e) { fatal('Não foi possível iniciar os gráficos 3D (WebGL): ' + e.message); return; }
    applyUi(); DK.Gfx.setReduce(S.reduceFx);
    DK.Input.init(); bindUi(); bindNet(); syncSettings();
    requestAnimationFrame(frame);   // arena vazia até os modelos 3D reais estarem prontos (evita mostrar o boneco simples)
    const tap = $('tapTxt'); if (tap) tap.textContent = 'A PREPARAR OS LUTADORES…';
    const modelsReady = (DK.Models ? DK.Models.load() : Promise.resolve(false)).catch(() => false).then(() => {
      setupMenuScene(); if (tap) tap.textContent = 'TOQUE PARA INICIAR';
    });
    let started = false;
    $('splash').addEventListener('pointerdown', () => {
      if (started) return; started = true; DK.Audio.unlock(); go('loading');
      // áudio (WAV) e modelos 3D (GLB) carregam em paralelo; a barra mostra o progresso combinado
      const prog = { a: 0, m: 0 };
      const upd = () => { $('loadFill').style.width = Math.round((prog.a * 0.75 + prog.m * 0.25) * 100) + '%'; };
      Promise.all([
        DK.Audio.load((p) => { prog.a = p; upd(); }),
        modelsReady.then(() => { prog.m = 1; upd(); })
      ]).then(() => {
        if (!menuView) setupMenuScene();
        go('menu'); DK.Audio.music('music_menu'); DK.Gfx.perfSkip = 2;
      });
    });
    // desbloqueio de áudio em qualquer toque (alguns WebViews suspendem o contexto)
    document.addEventListener('pointerdown', () => DK.Audio.unlock(), { passive: true });
    document.addEventListener('contextmenu', (e) => e.preventDefault());
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
