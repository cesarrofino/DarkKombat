/* Dark Kombat - carregador de modelos GLB dos lutadores.
   Lê os GLB articulados gerados por tools/build_glb.py (hierarquia de ossos + malhas com normais + materiais PBR).
   Não usa GLTFLoader: assim o jogo não depende de ficheiros externos e funciona 100 % offline.
   Suporta só o que esses ficheiros usam: nós com translação/escala/extras, malhas triangulares (POSITION, NORMAL, índices
   de 16 bits), materiais pbrMetallicRoughness (+ emissiveFactor) e, nos lutadores texturados (tools/build_textured_glb.py),
   TEXCOORD_0, JOINTS_0/WEIGHTS_0 (malha com skinning suave), `skins` e uma textura PNG/JPEG embutida. */
(function () {
  const DK = (globalThis.DK = globalThis.DK || {});
  const FILES = ['kira_lod0', 'kira_lod1', 'ren_lod0', 'ren_lod1'];
  const CT = { 5120: Int8Array, 5121: Uint8Array, 5122: Int16Array, 5123: Uint16Array, 5125: Uint32Array, 5126: Float32Array };
  const NC = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4 };
  const store = {};   // 'kira_lod0' -> modelo analisado

  /** Converte um ArrayBuffer GLB num "modelo" (dados puros, sem THREE). Lança erro se o ficheiro for inválido. */
  function parse(ab) {
    const dv = new DataView(ab);
    if (dv.byteLength < 20 || dv.getUint32(0, true) !== 0x46546c67) throw new Error('GLB inválido (cabeçalho)');
    if (dv.getUint32(4, true) !== 2) throw new Error('GLB: só a versão 2 é suportada');
    let off = 12, json = null, bin = null;
    while (off + 8 <= dv.byteLength) {
      const len = dv.getUint32(off, true), type = dv.getUint32(off + 4, true);
      off += 8;
      if (off + len > dv.byteLength) throw new Error('GLB truncado');
      if (type === 0x4e4f534a) json = JSON.parse(new TextDecoder().decode(new Uint8Array(ab, off, len)));
      else if (type === 0x004e4942) bin = ab.slice(off, off + len);   // cópia: garante o alinhamento
      off += len;
    }
    if (!json || !bin) throw new Error('GLB sem JSON ou sem dados binários');

    const acc = (i) => {
      const a = json.accessors[i], bv = json.bufferViews[a.bufferView], n = NC[a.type], C = CT[a.componentType];
      if (!C || !n) throw new Error('GLB: acessor não suportado');
      const o = (bv.byteOffset || 0) + (a.byteOffset || 0);
      return o % C.BYTES_PER_ELEMENT === 0 ? new C(bin, o, a.count * n) : new C(bin.slice(o, o + a.count * n * C.BYTES_PER_ELEMENT));
    };
    const meshes = json.meshes.map((m) => m.primitives.map((p) => {
      if (p.mode !== undefined && p.mode !== 4) throw new Error('GLB: só triângulos');
      const o = { pos: acc(p.attributes.POSITION), nor: acc(p.attributes.NORMAL), idx: acc(p.indices), mat: p.material || 0, geo: null };
      if (p.attributes.TEXCOORD_0 !== undefined) o.uv = acc(p.attributes.TEXCOORD_0);
      if (p.attributes.JOINTS_0 !== undefined && p.attributes.WEIGHTS_0 !== undefined) {
        const w = acc(p.attributes.WEIGHTS_0);
        if (!(w instanceof Float32Array)) throw new Error('GLB: WEIGHTS_0 tem de ser float');
        o.joints = Uint16Array.from(acc(p.attributes.JOINTS_0)); o.weights = w;   // 4 influências por vértice
      }
      return o;
    }));
    const image = (texIndex) => {   // bytes da imagem embutida (JPEG/PNG) de uma textura, ou null
      const t = json.textures && json.textures[texIndex], im = t && json.images && json.images[t.source];
      if (!im || im.bufferView === undefined) return null;
      const bv = json.bufferViews[im.bufferView], o = bv.byteOffset || 0;
      return { bytes: new Uint8Array(bin.slice(o, o + bv.byteLength)), mime: im.mimeType || 'image/png' };
    };
    let tris = 0; meshes.forEach((ps) => ps.forEach((p) => { tris += p.idx.length / 3; }));
    const materials = (json.materials || []).map((m) => {
      const pb = m.pbrMetallicRoughness || {}, c = pb.baseColorFactor || [1, 1, 1, 1];
      return { color: [c[0], c[1], c[2]], emissive: !!(m.emissiveFactor && Math.max.apply(null, m.emissiveFactor) > 0.05),
        metal: pb.metallicFactor === undefined ? 1 : pb.metallicFactor, rough: pb.roughnessFactor === undefined ? 1 : pb.roughnessFactor,
        img: pb.baseColorTexture ? image(pb.baseColorTexture.index) : null, texture: null };
    });
    const sc = json.scenes[json.scene || 0];
    if (!sc || !sc.nodes.length) throw new Error('GLB sem cena');
    const skin = json.skins && json.skins[0] ? json.skins[0].joints : null;   // índices dos nós que são ossos
    return { nodes: json.nodes, meshes, materials, root: sc.nodes[0], tris, extras: json.extras || {}, skin };
  }

  const hex = (c) => (Math.round(c[0] * 255) << 16) | (Math.round(c[1] * 255) << 8) | Math.round(c[2] * 255);

  function geometry(p) {
    if (!p.geo) {
      const T = globalThis.THREE, g = new T.BufferGeometry();
      g.setAttribute('position', new T.BufferAttribute(p.pos, 3));
      g.setAttribute('normal', new T.BufferAttribute(p.nor, 3));
      if (p.uv) g.setAttribute('uv', new T.BufferAttribute(p.uv, 2));
      if (p.joints) { g.setAttribute('skinIndex', new T.BufferAttribute(p.joints, 4)); g.setAttribute('skinWeight', new T.BufferAttribute(p.weights, 4)); }
      g.setIndex(new T.BufferAttribute(p.idx, 1));
      g.computeBoundingSphere();
      p.geo = g;   // partilhada entre instâncias (não se liberta ao remover um lutador)
    }
    return p.geo;
  }

  /** Cria os objectos THREE de uma instância do modelo. Devolve { root, bones, extras, mats }.
      Materiais são próprios de cada instância (libertam-se em dispose); as geometrias são partilhadas. */
  function instantiate(model) {
    const T = globalThis.THREE, mats = [], local = {}, bones = {}, extras = {}, byNode = {}, skinned = [];
    const jointSet = model.skin && T.Bone && T.SkinnedMesh && T.Skeleton ? new Set(model.skin) : null;
    const material = (i) => {
      if (!local[i]) {
        const d = model.materials[i];
        if (d.img) {   // lutador texturado: usa a textura (partilhada, já descodificada) ou, se falhou, uma cor escura neutra
          local[i] = d.texture
            ? new T.MeshStandardMaterial({ map: d.texture, emissiveMap: d.texture, emissive: 0x555555, metalness: 0.1, roughness: 0.7 })
            : new T.MeshStandardMaterial({ color: 0x2a2a3a, metalness: 0.3, roughness: 0.6 });
          mats.push(local[i]); return local[i];
        }
        local[i] = d.emissive
          ? new T.MeshBasicMaterial({ color: hex(d.color) })                                   // néon: não depende da luz
          : new T.MeshStandardMaterial({ color: hex(d.color), metalness: Math.min(d.metal, 0.55), roughness: Math.max(d.rough, 0.3) });
        mats.push(local[i]);
      }
      return local[i];
    };
    const build = (ni) => {
      const nd = model.nodes[ni], g = jointSet && jointSet.has(ni) ? new T.Bone() : new T.Group();
      byNode[ni] = g;
      g.name = nd.name || ('n' + ni);
      if (nd.translation) g.position.set(nd.translation[0], nd.translation[1], nd.translation[2]);
      if (nd.scale) g.scale.set(nd.scale[0], nd.scale[1], nd.scale[2]);
      bones[g.name] = g; extras[g.name] = nd.extras || {};
      if (nd.mesh !== undefined) {
        model.meshes[nd.mesh].forEach((p) => {
          if (nd.skin !== undefined && jointSet && p.joints) { const m = new T.SkinnedMesh(geometry(p), material(p.mat)); m.frustumCulled = false; g.add(m); skinned.push(m); }
          else g.add(new T.Mesh(geometry(p), material(p.mat)));
        });
      }
      (nd.children || []).forEach((c) => g.add(build(c)));
      return g;
    };
    const root = build(model.root);
    if (skinned.length) {   // liga a malha ao esqueleto na pose de repouso (todas as rotações nulas) e só depois aplica as escalas de execução
      root.updateMatrixWorld(true);
      const list = model.skin.map((ni) => byNode[ni]);
      skinned.forEach((m) => m.bind(new T.Skeleton(list)));
      for (const n in bones) { const s = extras[n] && extras[n].runScale; if (s) bones[n].scale.set(s, s, s); }
    }
    return { root, bones, extras, mats };
  }

  /** Descodifica a textura embutida (JPEG/PNG) numa THREE.Texture partilhada. Devolve null se o ambiente não suportar (testes em Node). */
  async function makeTexture(img) {
    const T = globalThis.THREE;
    if (!T || !T.Texture || typeof Blob === 'undefined') return null;
    const blob = new Blob([img.bytes], { type: img.mime });
    let src;
    try { src = await createImageBitmap(blob); }
    catch (e) {
      src = await new Promise((ok, no) => { const im = new Image(); im.onload = () => ok(im); im.onerror = no; im.src = URL.createObjectURL(blob); });
    }
    const t = new T.Texture(src);
    t.flipY = false;   // glTF: origem das UV no canto superior esquerdo
    if ('colorSpace' in t) t.colorSpace = 'srgb'; else t.encoding = T.sRGBEncoding;
    t.userData = { shared: true };   // pertence à cache de modelos: os lutadores não a libertam
    t.needsUpdate = true;
    return t;
  }

  const Models = {
    /** Devolve o modelo do lutador `id` para a qualidade pedida ('low' usa o LOD1, o resto o LOD0), ou null. */
    get(id, quality) {
      return (quality === 'low' && store[id + '_lod1']) || store[id + '_lod0'] || null;
    },
    has(id) { return !!store[id + '_lod0']; },
    set(name, model) { store[name] = model; },
    parse, instantiate, makeTexture,
    /** Descarrega todos os GLB do APK (assets/game/models). Nunca rejeita: se falhar, o jogo usa os modelos procedurais. */
    async load(onProgress) {
      let n = 0;
      for (const name of FILES) {
        try {
          if (typeof fetch === 'function') {
            const r = await fetch('models/' + name + '.glb');
            if (!r.ok) throw new Error('HTTP ' + r.status);
            const model = parse(await r.arrayBuffer());
            for (const m of model.materials) if (m.img) { try { m.texture = await makeTexture(m.img); } catch (e) { m.texture = null; } }
            store[name] = model;
          }
        } catch (e) { if (globalThis.console) console.warn('Modelo ' + name + ' indisponível:', e && e.message); }
        n++; if (onProgress) onProgress(n / FILES.length);
      }
      return Models.has('kira') && Models.has('ren');
    }
  };
  DK.Models = Models;
})();
