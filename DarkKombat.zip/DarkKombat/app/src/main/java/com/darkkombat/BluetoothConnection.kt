package com.darkkombat

import android.bluetooth.BluetoothSocket
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * Ligação RFCOMM já estabelecida. Mensagens de texto terminadas em '\n' (uma linha JSON).
 * Leitura e escrita decorrem sempre fora da thread principal.
 */
class BluetoothConnection(
    private val socket: BluetoothSocket,
    private val listener: Listener
) {
    interface Listener {
        fun onLine(line: String)
        fun onClosed(reason: String)
    }

    private val closed = AtomicBoolean(false)
    private val pending = AtomicInteger(0)
    private val writer: ExecutorService = Executors.newSingleThreadExecutor { r ->
        Thread(r, "dk-bt-write").apply { isDaemon = true }
    }

    fun start() {
        Thread({ readLoop() }, "dk-bt-read").apply { isDaemon = true }.start()
    }

    private fun readLoop() {
        var reason = "Ligação terminada"
        try {
            val input = socket.inputStream
            val buf = ByteArray(1024)
            val line = ByteArrayOutputStream()
            var overflow = false
            while (!closed.get()) {
                val n = input.read(buf)
                if (n < 0) break
                for (i in 0 until n) {
                    val b = buf[i].toInt()
                    if (b == '\n'.code) {
                        if (!overflow && line.size() > 0) {
                            listener.onLine(String(line.toByteArray(), Charsets.UTF_8))
                        }
                        line.reset()
                        overflow = false
                    } else if (!overflow) {
                        if (line.size() >= MAX_LINE) {
                            overflow = true // descarta a linha demasiado grande
                            line.reset()
                        } else {
                            line.write(b)
                        }
                    }
                }
            }
        } catch (e: IOException) {
            if (!closed.get()) reason = "Ligação perdida"
        } catch (e: Exception) {
            reason = "Erro de comunicação"
        }
        close(reason)
    }

    /** Devolve false se a linha for descartada (fila cheia ou ligação fechada). */
    fun send(line: String): Boolean {
        if (closed.get()) return false
        if (pending.get() > MAX_PENDING) return false
        pending.incrementAndGet()
        try {
            writer.execute {
                try {
                    if (!closed.get()) {
                        val out = socket.outputStream
                        out.write((line + "\n").toByteArray(Charsets.UTF_8))
                        out.flush()
                    }
                } catch (e: IOException) {
                    close("Falha ao enviar")
                } finally {
                    pending.decrementAndGet()
                }
            }
        } catch (e: Exception) {
            pending.decrementAndGet()
            return false
        }
        return true
    }

    fun close(reason: String) {
        if (!closed.compareAndSet(false, true)) return
        try { socket.close() } catch (_: IOException) {}
        try { writer.shutdownNow() } catch (_: Exception) {}
        listener.onClosed(reason)
    }

    val isOpen: Boolean get() = !closed.get()

    companion object {
        const val MAX_LINE = 2048
        private const val MAX_PENDING = 64
    }
}
