package com.darkkombat

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import androidx.core.content.ContextCompat

/** Procura de dispositivos Bluetooth Classic próximos (inclui não emparelhados). */
@SuppressLint("MissingPermission")
class BluetoothDiscovery(
    private val context: Context,
    private val adapter: BluetoothAdapter,
    private val listener: Listener
) {
    interface Listener {
        fun onDevice(name: String, address: String, bonded: Boolean)
        fun onFinished()
    }

    private var registered = false
    private val seen = HashSet<String>()

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, intent: Intent) {
            when (intent.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33) {
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    }
                    if (device != null) report(device)
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    unregister()
                    listener.onFinished()
                }
            }
        }
    }

    private fun report(device: BluetoothDevice) {
        val addr = device.address ?: return
        if (!seen.add(addr)) return
        val name = try { device.name } catch (e: SecurityException) { null }
        listener.onDevice(name?.takeIf { it.isNotBlank() } ?: "Dispositivo Bluetooth", addr,
            device.bondState == BluetoothDevice.BOND_BONDED)
    }

    fun start(): Boolean {
        stop()
        seen.clear()
        try {
            // Dispositivos já emparelhados aparecem logo
            adapter.bondedDevices?.forEach { report(it) }
            val filter = IntentFilter().apply {
                addAction(BluetoothDevice.ACTION_FOUND)
                addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            }
            ContextCompat.registerReceiver(context, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
            registered = true
            if (!adapter.startDiscovery()) {
                unregister()
                return false
            }
            return true
        } catch (e: SecurityException) {
            unregister()
            return false
        }
    }

    fun stop() {
        try { if (adapter.isDiscovering) adapter.cancelDiscovery() } catch (_: SecurityException) {}
        unregister()
    }

    private fun unregister() {
        if (registered) {
            try { context.unregisterReceiver(receiver) } catch (_: IllegalArgumentException) {}
            registered = false
        }
    }
}
