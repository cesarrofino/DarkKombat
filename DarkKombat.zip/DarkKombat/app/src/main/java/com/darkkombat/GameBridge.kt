package com.darkkombat

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.webkit.JavascriptInterface

/**
 * Ponte mínima Kotlin <-> JavaScript. Só expõe o que o jogo precisa e valida os argumentos.
 * Os métodos são chamados numa thread da WebView, nunca bloqueiam (o Bluetooth corre noutras threads).
 */
class GameBridge(
    private val activity: MainActivity,
    private val bt: BtManager,
    private val settings: GameSettings
) {
    private val macRegex = Regex("^([0-9A-F]{2}:){5}[0-9A-F]{2}$")

    @JavascriptInterface fun btAvailable(): Boolean = bt.isAvailable()

    @JavascriptInterface fun btHost() { bt.startHosting() }

    @JavascriptInterface fun btScan() { bt.startScan() }

    @JavascriptInterface fun btStopScan() { bt.stopScan() }

    @JavascriptInterface fun btConnect(address: String?) {
        val a = address?.trim()?.uppercase() ?: return
        if (macRegex.matches(a)) bt.connectTo(a)
    }

    @JavascriptInterface fun btSend(json: String?): Boolean {
        if (json == null || json.length > BluetoothConnection.MAX_LINE) return false
        return bt.send(json)
    }

    @JavascriptInterface fun btDisconnect() { bt.disconnect() }

    @JavascriptInterface fun getSettings(): String = settings.load()

    @JavascriptInterface fun saveSettings(json: String?): Boolean = json != null && settings.save(json)

    @JavascriptInterface fun vibrate(ms: Int) {
        val d = ms.coerceIn(10, 250).toLong()
        try {
            @Suppress("DEPRECATION")
            val v = activity.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
            if (!v.hasVibrator()) return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(d, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(d)
            }
        } catch (_: Exception) {
        }
    }

    @JavascriptInterface fun exitApp() { activity.runOnUiThread { activity.finish() } }
}
