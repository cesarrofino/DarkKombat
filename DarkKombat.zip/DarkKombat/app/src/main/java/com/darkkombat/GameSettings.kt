package com.darkkombat

import android.content.Context
import org.json.JSONObject

/** Guarda as preferências do jogo (JSON) em SharedPreferences, localmente. */
class GameSettings(context: Context) {
    private val prefs = context.getSharedPreferences("dark_kombat", Context.MODE_PRIVATE)

    fun load(): String = prefs.getString(KEY, "") ?: ""

    /** Aceita apenas um objecto JSON pequeno; devolve false se for inválido. */
    fun save(json: String): Boolean {
        if (json.length > MAX_LEN) return false
        return try {
            JSONObject(json)
            prefs.edit().putString(KEY, json).apply()
            true
        } catch (e: Exception) {
            false
        }
    }

    companion object {
        private const val KEY = "settings_json"
        private const val MAX_LEN = 4096
    }
}
