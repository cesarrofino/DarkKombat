package com.darkkombat

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Context
import org.json.JSONObject
import java.io.IOException
import java.util.UUID
import kotlin.concurrent.thread

/** O que o Bluetooth precisa da Activity (permissões, ligar Bluetooth, visibilidade, enviar ao JS). */
interface BtHost {
    fun ensurePermissions(forHosting: Boolean, forScanning: Boolean, done: (Boolean) -> Unit)
    fun ensureEnabled(done: (Boolean) -> Unit)
    fun requestDiscoverable(seconds: Int, done: (Boolean) -> Unit)
    fun postToJs(json: String)
}

/** Validação do protocolo (ver docs/PROTOCOLO.md). Mensagens inválidas são descartadas. */
object BtProtocol {
    val TYPES = setOf(
        "HELLO", "READY", "START", "INPUT", "STATE", "HIT",
        "ROUND_END", "MATCH_END", "PING", "DISCONNECT"
    )

    fun isValid(line: String): Boolean {
        if (line.isEmpty() || line.length > BluetoothConnection.MAX_LINE) return false
        return try {
            val o = JSONObject(line)
            val t = o.optString("t", "")
            t in TYPES && o.optLong("q", 0L) >= 0L
        } catch (e: Exception) {
            false
        }
    }
}

/**
 * Bluetooth Classic (RFCOMM) com papéis anfitrião/cliente.
 * Usa sockets "insecure" para não exigir emparelhamento prévio (os dados do jogo não são sensíveis).
 */
@SuppressLint("MissingPermission")
class BtManager(private val context: Context, private val ui: BtHost) {

    private val adapter: BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as? android.bluetooth.BluetoothManager)?.adapter

    private val lock = Any()
    @Volatile private var epoch = 0
    private var discovery: BluetoothDiscovery? = null
    private var server: BluetoothServerSocket? = null
    private var connection: BluetoothConnection? = null
    private var dropped = 0

    fun isAvailable(): Boolean = adapter != null

    // ---------- eventos para o JavaScript ----------
    private fun emit(build: JSONObject.() -> Unit) {
        val o = JSONObject()
        o.build()
        ui.postToJs(o.toString())
    }

    private fun state(s: String, role: String? = null, msg: String? = null, name: String? = null, addr: String? = null) {
        emit {
            put("e", "state"); put("s", s)
            if (role != null) put("role", role)
            if (msg != null) put("msg", msg)
            if (name != null) put("name", name)
            if (addr != null) put("addr", addr)
        }
    }

    private fun fail(my: Int, msg: String, role: String?) {
        if (my != epoch) return
        state("error", role = role, msg = msg)
    }

    // ---------- anfitrião ----------
    fun startHosting() {
        val ad = adapter
        if (ad == null) { state("error", msg = "Este dispositivo não tem Bluetooth."); return }
        val my = beginSession()
        state("preparing", role = "host", msg = "A preparar…")
        ui.ensurePermissions(true, false) { ok ->
            if (my != epoch) return@ensurePermissions
            if (!ok) { fail(my, "Permissões Bluetooth recusadas.", "host"); return@ensurePermissions }
            ui.requestDiscoverable(300) { visible ->
                if (my != epoch) return@requestDiscoverable
                if (!ad.isEnabled) { fail(my, "O Bluetooth está desligado.", "host"); return@requestDiscoverable }
                listen(ad, my, visible)
            }
        }
    }

    private fun listen(ad: BluetoothAdapter, my: Int, visible: Boolean) {
        thread(name = "dk-bt-accept", isDaemon = true) {
            var opened: BluetoothServerSocket? = null
            try {
                val ss = ad.listenUsingInsecureRfcommWithServiceRecord(SERVICE_NAME, APP_UUID)
                opened = ss
                val stale = synchronized(lock) {
                    if (my != epoch) true else { server = ss; false }
                }
                if (stale) { ss.close(); return@thread }
                val myName = try { ad.name ?: "" } catch (e: SecurityException) { "" }
                state(
                    "hosting", role = "host", name = myName,
                    msg = if (visible) "À espera do adversário…"
                    else "À espera do adversário… (o dispositivo não está visível; emparelhe-o primeiro)"
                )
                val sock = ss.accept()
                try { ss.close() } catch (_: IOException) {}
                synchronized(lock) { server = null }
                if (my != epoch) { try { sock.close() } catch (_: IOException) {}; return@thread }
                attach(sock, "host", my)
            } catch (e: IOException) {
                try { opened?.close() } catch (_: IOException) {}
                fail(my, "Não foi possível aguardar ligações.", "host")
            } catch (e: SecurityException) {
                fail(my, "Sem permissão Bluetooth.", "host")
            }
        }
    }

    // ---------- cliente ----------
    fun startScan() {
        val ad = adapter
        if (ad == null) { state("error", msg = "Este dispositivo não tem Bluetooth."); return }
        val my = beginSession()
        state("preparing", role = "client", msg = "A preparar…")
        ui.ensurePermissions(false, true) { ok ->
            if (my != epoch) return@ensurePermissions
            if (!ok) { fail(my, "Permissões Bluetooth recusadas.", "client"); return@ensurePermissions }
            ui.ensureEnabled { on ->
                if (my != epoch) return@ensureEnabled
                if (!on) { fail(my, "O Bluetooth está desligado.", "client"); return@ensureEnabled }
                val d = BluetoothDiscovery(context, ad, object : BluetoothDiscovery.Listener {
                    override fun onDevice(name: String, address: String, bonded: Boolean) {
                        if (my != epoch) return
                        emit { put("e", "device"); put("name", name); put("addr", address); put("bonded", bonded) }
                    }
                    override fun onFinished() {
                        if (my != epoch) return
                        emit { put("e", "scan_end") }
                    }
                })
                synchronized(lock) { discovery = d }
                if (d.start()) state("scanning", role = "client", msg = "A procurar partidas…")
                else fail(my, "Não foi possível iniciar a procura. No Android 11 ou anterior ligue a localização.", "client")
            }
        }
    }

    fun stopScan() {
        synchronized(lock) { discovery?.stop(); discovery = null }
    }

    fun connectTo(address: String) {
        val ad = adapter
        if (ad == null) { state("error", msg = "Este dispositivo não tem Bluetooth."); return }
        val my = beginSession()
        state("connecting", role = "client", msg = "A ligar…", addr = address)
        ui.ensurePermissions(false, true) { ok ->
            if (my != epoch) return@ensurePermissions
            if (!ok) { fail(my, "Permissões Bluetooth recusadas.", "client"); return@ensurePermissions }
            ui.ensureEnabled { on ->
                if (my != epoch) return@ensureEnabled
                if (!on) { fail(my, "O Bluetooth está desligado.", "client"); return@ensureEnabled }
                thread(name = "dk-bt-connect", isDaemon = true) { connectBlocking(ad, address, my) }
            }
        }
    }

    private fun connectBlocking(ad: BluetoothAdapter, address: String, my: Int) {
        try {
            try { if (ad.isDiscovering) ad.cancelDiscovery() } catch (_: SecurityException) {}
            val device = ad.getRemoteDevice(address)
            var lastErr: Exception? = null
            for (attempt in 1..2) {
                if (my != epoch) return
                var sock: BluetoothSocket? = null
                try {
                    sock = device.createInsecureRfcommSocketToServiceRecord(APP_UUID)
                    sock.connect()
                    if (my != epoch) { try { sock.close() } catch (_: IOException) {}; return }
                    attach(sock, "client", my)
                    return
                } catch (e: IOException) {
                    lastErr = e
                    try { sock?.close() } catch (_: IOException) {}
                    try { Thread.sleep(600) } catch (_: InterruptedException) {}
                }
            }
            fail(my, "Não foi possível ligar. Confirme que o anfitrião criou a partida e tente de novo.", "client")
            if (lastErr != null) lastErr.printStackTrace()
        } catch (e: IllegalArgumentException) {
            fail(my, "Endereço Bluetooth inválido.", "client")
        } catch (e: SecurityException) {
            fail(my, "Sem permissão Bluetooth.", "client")
        }
    }

    // ---------- ligação estabelecida ----------
    private fun attach(sock: BluetoothSocket, role: String, my: Int) {
        val remoteName = try { sock.remoteDevice.name ?: "Adversário" } catch (e: SecurityException) { "Adversário" }
        val remoteAddr = try { sock.remoteDevice.address } catch (e: SecurityException) { null }
        val conn = BluetoothConnection(sock, object : BluetoothConnection.Listener {
            override fun onLine(line: String) {
                if (my != epoch) return
                if (!BtProtocol.isValid(line)) { dropped++; return }
                emit { put("e", "msg"); put("d", line) }
            }
            override fun onClosed(reason: String) {
                if (my != epoch) return
                synchronized(lock) { connection = null }
                state("closed", role = role, msg = reason)
            }
        })
        synchronized(lock) {
            if (my != epoch) { conn.close("cancelado"); return }
            connection = conn
        }
        conn.start()
        state("connected", role = role, name = remoteName, addr = remoteAddr, msg = "Ligado")
    }

    fun send(line: String): Boolean {
        if (!BtProtocol.isValid(line)) return false
        val c = synchronized(lock) { connection } ?: return false
        return c.send(line)
    }

    // ---------- encerramento ----------
    private fun beginSession(): Int {
        closeAll()
        synchronized(lock) { epoch += 1; return epoch }
    }

    private fun closeAll() {
        synchronized(lock) {
            epoch += 1
            try { discovery?.stop() } catch (_: Exception) {}
            discovery = null
            try { server?.close() } catch (_: IOException) {}
            server = null
            connection?.close("Desligado")
            connection = null
        }
    }

    fun disconnect() {
        closeAll()
        state("idle")
    }

    fun shutdown() {
        closeAll()
    }

    companion object {
        private const val SERVICE_NAME = "DarkKombat"
        val APP_UUID: UUID = UUID.fromString("8f1c2a56-5d3e-4b7a-9c21-6d1a0b7e44f3")
    }
}
