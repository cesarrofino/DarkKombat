package com.darkkombat

import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.os.Bundle
import android.view.WindowManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader

class MainActivity : ComponentActivity(), BtHost {

    private lateinit var webView: WebView
    private lateinit var bt: BtManager
    private lateinit var perms: PermissionManager
    private var enableCb: ((Boolean) -> Unit)? = null
    private var discoverableCb: ((Boolean) -> Unit)? = null

    private val enableLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val cb = enableCb; enableCb = null
        cb?.invoke(r.resultCode == Activity.RESULT_OK)
    }
    private val discoverableLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val cb = discoverableCb; discoverableCb = null
        cb?.invoke(r.resultCode != Activity.RESULT_CANCELED)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        perms = PermissionManager(this)
        bt = BtManager(applicationContext, this)

        webView = WebView(this)
        webView.setBackgroundColor(Color.BLACK)
        setContentView(webView)
        hideSystemBars()

        val debuggable = (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        WebView.setWebContentsDebuggingEnabled(debuggable)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mediaPlaybackRequiresUserGesture = false
            setSupportZoom(false)
            builtInZoomControls = false
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        webView.overScrollMode = WebView.OVER_SCROLL_NEVER
        webView.isVerticalScrollBarEnabled = false
        webView.isHorizontalScrollBarEnabled = false
        webView.setOnLongClickListener { true }
        webView.isHapticFeedbackEnabled = false

        // Todos os recursos vêm do APK (offline) através de um domínio virtual local.
        val assetLoader = WebViewAssetLoader.Builder()
            .setDomain(HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                request.url.host != HOST

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                runOnUiThread { recreate() }
                return true
            }
        }

        webView.addJavascriptInterface(GameBridge(this, bt, GameSettings(applicationContext)), "AndroidBridge")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript(
                    "(window.DKApp&&window.DKApp.onBack)?String(window.DKApp.onBack()):'false'"
                ) { r -> if (r == null || !r.contains("true")) finish() }
            }
        })

        webView.loadUrl("https://$HOST/assets/game/index.html")
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onPause() {
        // Interrupção (chamada, ecrã bloqueado, mudar de app): o jogo pausa sozinho.
        webView.evaluateJavascript("window.DKApp&&window.DKApp.onPause&&window.DKApp.onPause()", null)
        webView.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
        webView.evaluateJavascript("window.DKApp&&window.DKApp.onResume&&window.DKApp.onResume()", null)
    }

    override fun onDestroy() {
        bt.shutdown()
        webView.removeJavascriptInterface("AndroidBridge")
        webView.destroy()
        super.onDestroy()
    }

    // ---------- BtHost ----------
    override fun ensurePermissions(forHosting: Boolean, forScanning: Boolean, done: (Boolean) -> Unit) {
        runOnUiThread { perms.request(forHosting, forScanning, done) }
    }

    @SuppressLint("MissingPermission")
    override fun ensureEnabled(done: (Boolean) -> Unit) {
        runOnUiThread {
            val adapter = BluetoothAdapter.getDefaultAdapter()
            if (adapter == null) { done(false); return@runOnUiThread }
            if (adapter.isEnabled) { done(true); return@runOnUiThread }
            enableCb = done
            try {
                enableLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
            } catch (e: Exception) {
                enableCb = null
                done(false)
            }
        }
    }

    override fun requestDiscoverable(seconds: Int, done: (Boolean) -> Unit) {
        runOnUiThread {
            discoverableCb = done
            try {
                val i = Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                i.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, seconds)
                discoverableLauncher.launch(i)
            } catch (e: Exception) {
                discoverableCb = null
                done(false)
            }
        }
    }

    override fun postToJs(json: String) {
        val safe = json.replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
        runOnUiThread {
            if (!isDestroyed) webView.evaluateJavascript("window.NativeBT&&window.NativeBT.on($safe)", null)
        }
    }

    companion object {
        private const val HOST = "appassets.androidplatform.net"
    }
}
