package com.darkkombat

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

/** Pede as permissões Bluetooth certas para cada versão do Android. */
class PermissionManager(private val activity: ComponentActivity) {

    private var callback: ((Boolean) -> Unit)? = null

    private val launcher = activity.registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val cb = callback
        callback = null
        cb?.invoke(result.isNotEmpty() && result.values.all { it })
    }

    fun required(forHosting: Boolean, forScanning: Boolean): Array<String> {
        val list = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            list.add(Manifest.permission.BLUETOOTH_CONNECT)
            if (forScanning) list.add(Manifest.permission.BLUETOOTH_SCAN)
            if (forHosting) list.add(Manifest.permission.BLUETOOTH_ADVERTISE)
        } else if (forScanning) {
            // Android 11 e anterior: a procura de dispositivos exige localização
            list.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        return list.toTypedArray()
    }

    fun hasAll(perms: Array<String>): Boolean = perms.all {
        ContextCompat.checkSelfPermission(activity, it) == PackageManager.PERMISSION_GRANTED
    }

    fun request(forHosting: Boolean, forScanning: Boolean, done: (Boolean) -> Unit) {
        val perms = required(forHosting, forScanning)
        if (perms.isEmpty() || hasAll(perms)) {
            done(true)
            return
        }
        callback = done
        launcher.launch(perms)
    }
}
