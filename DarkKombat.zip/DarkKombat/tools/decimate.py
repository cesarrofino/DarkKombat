"""Dark Kombat - redução de polígonos (colapso de arestas com métrica de quádricas, QEM), só numpy.
Preserva as costuras de UV (vértices nas costuras e no bordo da malha nunca são removidos), por isso a textura não deforma.
decimar(P, UV, I, fracao) -> (P, UV, I) com ~fracao dos triângulos originais."""
import heapq
import numpy as np


def _soldar(P):
    _, inv = np.unique(np.round(P * 1e5).astype(np.int64), axis=0, return_inverse=True)
    return inv.reshape(-1)


def decimar(P, UV, I, fracao=0.5, min_normal=0.35):
    W = _soldar(P)
    nw = int(W.max()) + 1
    Pw = np.zeros((nw, 3)); Pw[W] = P
    F = [list(map(int, W[t])) for t in I]                      # faces em índices soldados
    U = [[tuple(UV[i]) for i in t] for t in I]                  # uv de cada canto
    alive = [True] * len(F)
    # costuras: vértice soldado com mais do que um uv
    uvs = [set() for _ in range(nw)]
    for f, uf in zip(F, U):
        for k in range(3): uvs[f[k]].add(tuple(np.round(uf[k], 6)))
    seam = [len(s) > 1 for s in uvs]
    # bordo da malha (arestas com 1 só face)
    ec = {}
    for fi, f in enumerate(F):
        for a, b in ((f[0], f[1]), (f[1], f[2]), (f[2], f[0])):
            key = (a, b) if a < b else (b, a); ec[key] = ec.get(key, 0) + 1
    lock = seam[:]
    for (a, b), c in ec.items():
        if c != 2: lock[a] = lock[b] = True
    vf = [set() for _ in range(nw)]
    for fi, f in enumerate(F):
        for v in f: vf[v].add(fi)

    def normal(fi, over=None):
        f = F[fi]; p = [Pw[over[0]] if over and f[k] == over[1] else Pw[f[k]] for k in range(3)] if over else [Pw[v] for v in f]
        return np.cross(p[1] - p[0], p[2] - p[0])
    Q = np.zeros((nw, 4, 4))
    for fi in range(len(F)):
        n = normal(fi); ar = np.linalg.norm(n)
        if ar < 1e-14: continue
        n = n / ar; d = -n @ Pw[F[fi][0]]; pl = np.append(n, d)
        K = np.outer(pl, pl) * ar
        for v in F[fi]: Q[v] += K

    def nbrs(v):
        s = set()
        for fi in vf[v]: s.update(F[fi])
        s.discard(v); return s

    def cost(v, u):
        x = np.append(Pw[u], 1.0); return float(x @ Q[v] @ x)

    ver = [0] * nw; heap = []

    def push(v):
        if lock[v] or not vf[v]: return
        best = None
        for u in nbrs(v):
            c = cost(v, u)
            if best is None or c < best[0]: best = (c, u)
        if best: heapq.heappush(heap, (best[0], v, best[1], ver[v]))
    for v in range(nw): push(v)

    ntris = len(F); alvo = int(len(F) * fracao)
    while heap and ntris > alvo:
        c, v, u, vv = heapq.heappop(heap)
        if vv != ver[v] or not vf[v] or not vf[u]: continue
        Nv = nbrs(v)
        if u not in Nv: push(v); continue
        shared = [fi for fi in vf[v] if u in F[fi]]
        if len(shared) != 2 or len(Nv & nbrs(u)) != 2: ver[v] += 1; continue      # condição topológica
        ok = True
        for fi in vf[v]:
            if fi in shared: continue
            n0 = normal(fi); n1 = normal(fi, (u, v))
            l0, l1 = np.linalg.norm(n0), np.linalg.norm(n1)
            if l1 < 1e-12 or (n0 @ n1) / max(l0 * l1, 1e-30) < min_normal: ok = False; break
        if not ok: ver[v] += 1; continue
        # uv que o canto de u assume nas faces que ficam
        for fi in list(vf[v]):
            if fi in shared: continue
            f = F[fi]; k = f.index(v)
            if seam[u]:
                cand = [tuple(x) for x in uvs[u]]; cur = np.array(U[fi][k])
                U[fi][k] = min(cand, key=lambda q: (q[0] - cur[0]) ** 2 + (q[1] - cur[1]) ** 2)
            else: U[fi][k] = next(iter(uvs[u]))
            f[k] = u; vf[u].add(fi)
        for fi in shared:
            alive[fi] = False; ntris -= 1
            for w in F[fi]: vf[w].discard(fi)
        vf[v].clear(); Q[u] += Q[v]
        affected = nbrs(u) | {u}
        for w in affected: ver[w] += 1; push(w)
    # reconstrução com vértices (posição, uv) únicos
    out_P, out_UV, idx, out_I = [], [], {}, []
    for fi, f in enumerate(F):
        if not alive[fi] or len(set(f)) < 3: continue
        tri = []
        for k in range(3):
            key = (f[k], round(U[fi][k][0], 6), round(U[fi][k][1], 6))
            if key not in idx:
                idx[key] = len(out_P); out_P.append(Pw[f[k]]); out_UV.append(U[fi][k])
            tri.append(idx[key])
        out_I.append(tri)
    return np.array(out_P), np.array(out_UV), np.array(out_I, dtype=np.int64)
