#!/usr/bin/env python3
"""Dark Kombat - converte os lutadores TEXTURADOS (malha única, sem esqueleto) em GLB articulados para o jogo.
Só precisa de Python 3 + numpy + Pillow.

Entrada : tools/source_models/KIRA_textured.glb, REN_textured.glb
          (1 malha com ~5 000 triângulos + textura 1024x1024, lutador em posição de guarda, 1 m de altura)
Saída   : app/src/main/assets/game/models/<id>_lod0.glb  (textura 1024, qualidade média/alta)
          app/src/main/assets/game/models/<id>_lod1.glb  (textura  512, qualidade baixa)

O que faz:
  1. Descarta fragmentos soltos (pedaços de chão/sombra), espelha o REN (a perna da frente passa a ser a esquerda,
     como no motor), centra nos quadris, põe os pés em y = 0 e escala para a altura do personagem.
  2. Define o esqueleto de 21 ossos (pelvis, torso, chest, neck, head, clavicle_R/L, shoulder_R/L, elbow_R/L, hand_R/L,
     thigh_R/L, knee_R/L, foot_R/L, toe_R/L) a partir das articulações medidas na malha (tabela CONFIG).
     Os 11 primeiros são os originais (mesma ordem); os 10 novos dão coluna em duas partes, pescoço, clavículas,
     pulsos, tornozelos e dedos dos pés.
  3. Calcula pesos de skinning suaves: distância a cápsulas por osso + difusão pela malha -> dobras sem rasgos.
  4. Mede os ângulos de repouso (braços e pernas) e o comprimento das pernas e guarda-os em `extras`.
  5. Escreve o GLB (malha skinned + normais + UV + JOINTS_0/WEIGHTS_0 + textura embutida).

Uso:  python3 tools/build_textured_glb.py   (gera os quatro GLB; depois corre `node tests/run.js`)
"""
import io
import json
import math
import os
import struct
import sys

import numpy as np
from PIL import Image

AQUI = os.path.dirname(os.path.abspath(__file__))
ENTRADA = os.path.join(AQUI, 'source_models')
SAIDA = os.path.join(AQUI, '..', 'app', 'src', 'main', 'assets', 'game', 'models')

BONES = ['pelvis', 'torso', 'head', 'shoulder_R', 'elbow_R', 'shoulder_L', 'elbow_L', 'thigh_R', 'knee_R', 'thigh_L', 'knee_L',
         'chest', 'neck', 'clavicle_R', 'clavicle_L', 'hand_R', 'hand_L', 'foot_R', 'foot_L', 'toe_R', 'toe_L', 'spine']
PARENT = {'pelvis': None, 'spine': 'pelvis', 'torso': 'spine', 'chest': 'torso', 'neck': 'chest', 'head': 'neck',
          'clavicle_R': 'chest', 'clavicle_L': 'chest',
          'shoulder_R': 'clavicle_R', 'elbow_R': 'shoulder_R', 'hand_R': 'elbow_R',
          'shoulder_L': 'clavicle_L', 'elbow_L': 'shoulder_L', 'hand_L': 'elbow_L',
          'thigh_R': 'pelvis', 'knee_R': 'thigh_R', 'foot_R': 'knee_R', 'toe_R': 'foot_R',
          'thigh_L': 'pelvis', 'knee_L': 'thigh_L', 'foot_L': 'knee_L', 'toe_L': 'foot_L'}
BI = {b: i for i, b in enumerate(BONES)}

# --------------------------------------------------------------------------------------------------------------
# CONFIGURAÇÃO POR PERSONAGEM. Coordenadas do modelo original (1 m de altura, pés em y = -0.5, frente = +Z, R = -X, L = +X).
# Para o REN as coordenadas já são as do modelo ESPELHADO (mirror = True): perna da frente = esquerda (+X).
# --------------------------------------------------------------------------------------------------------------
CONFIG = {
    'kira': {
        'src': 'KIRA_textured.glb', 'mirror': False, 'height': 1.92, 'arm_scale': 1.18,
        'J': {
            'waist': (0.00, 0.11, 0.00), 'neck': (0.00, 0.33, 0.03), 'head_top': (0.015, 0.47, 0.06),
            'hip_R': (-0.085, -0.04, -0.05), 'knee_R': (-0.100, -0.20, -0.095), 'ankle_R': (-0.080, -0.43, -0.24),
            'heel_R': (-0.080, -0.465, -0.285), 'toe_R': (-0.070, -0.470, -0.175),
            'hip_L': (0.070, -0.04, 0.05), 'knee_L': (0.060, -0.19, 0.17), 'ankle_L': (0.120, -0.43, 0.165),
            'heel_L': (0.120, -0.465, 0.125), 'toe_L': (0.120, -0.470, 0.245),
            'sh_R': (-0.10, 0.29, -0.03), 'el_R': (-0.16, 0.17, -0.04), 'wr_R': (-0.13, 0.285, 0.05), 'fist_R': (-0.12, 0.30, 0.09),
            'sh_L': (0.11, 0.30, -0.02), 'el_L': (0.16, 0.19, 0.07), 'wr_L': (0.12, 0.255, 0.25), 'fist_L': (0.12, 0.26, 0.30),
        },
        'R': {'pelvis': 0.13, 'torso': 0.115, 'head': 0.075, 'ua': 0.05, 'fa': 0.04, 'fist': 0.05, 'th': 0.085, 'sh': 0.06, 'ft': 0.05},
    },
    'ren': {
        'src': 'REN_textured.glb', 'mirror': True, 'height': 2.02, 'arm_scale': 1.12,
        'J': {
            'waist': (0.00, 0.10, 0.00), 'neck': (0.00, 0.37, 0.05), 'head_top': (0.02, 0.49, 0.13),
            'hip_R': (-0.095, -0.04, -0.05), 'knee_R': (-0.130, -0.20, -0.11), 'ankle_R': (-0.100, -0.43, -0.29),
            'heel_R': (-0.100, -0.465, -0.355), 'toe_R': (-0.090, -0.470, -0.225),
            'hip_L': (0.100, -0.04, 0.05), 'knee_L': (0.110, -0.20, 0.18), 'ankle_L': (0.155, -0.43, 0.155),
            'heel_L': (0.170, -0.465, 0.075), 'toe_L': (0.170, -0.470, 0.245),
            'sh_R': (-0.15, 0.31, 0.00), 'el_R': (-0.21, 0.19, 0.00), 'wr_R': (-0.14, 0.26, 0.10), 'fist_R': (-0.14, 0.27, 0.14),
            'sh_L': (0.15, 0.31, 0.06), 'el_L': (0.18, 0.20, 0.16), 'wr_L': (0.11, 0.27, 0.32), 'fist_L': (0.11, 0.27, 0.37),
        },
        'R': {'pelvis': 0.15, 'torso': 0.15, 'head': 0.085, 'ua': 0.075, 'fa': 0.06, 'fist': 0.07, 'th': 0.10, 'sh': 0.075, 'ft': 0.06},
    },
}

from decimate import decimar
ALVO_TRIANGULOS = 0.4   # fracção dos triângulos originais (o mínimo possível sem tocar nas costuras de UV é ~47 %)
TAU = 0.012          # largura (m do modelo) da mistura entre ossos vizinhos antes da difusão
DIFUSAO = (0.55, 6)  # (fracção vizinhos, iterações) de suavização dos pesos sobre a malha


# ---------------------------------------------------------------- leitura do GLB de origem
def ler_glb(path):
    d = open(path, 'rb').read()
    n = struct.unpack('<I', d[12:16])[0]
    j = json.loads(d[20:20 + n])
    off = 20 + n + 8

    def acc(i):
        a = j['accessors'][i]
        bv = j['bufferViews'][a['bufferView']]
        o = off + bv.get('byteOffset', 0) + a.get('byteOffset', 0)
        dt = {5126: '<f4', 5123: '<u2', 5125: '<u4'}[a['componentType']]
        k = {'VEC3': 3, 'VEC2': 2, 'SCALAR': 1}[a['type']]
        return np.frombuffer(d, dt, a['count'] * k, o).reshape(-1, k)

    pr = j['meshes'][0]['primitives'][0]
    bv = j['bufferViews'][j['images'][0]['bufferView']]
    o = off + bv.get('byteOffset', 0)
    tex = Image.open(io.BytesIO(d[o:o + bv['byteLength']])).convert('RGB')
    return (acc(pr['attributes']['POSITION']).astype(np.float64), acc(pr['attributes']['TEXCOORD_0']).astype(np.float64),
            acc(pr['indices']).reshape(-1, 3).astype(np.int64), tex)


def soldar(P):
    """índice de vértice soldado (mesma posição = mesmo vértice, ignora costuras de UV)"""
    _, inv = np.unique(np.round(P * 1e5).astype(np.int64), axis=0, return_inverse=True)
    return inv.reshape(-1)


def componentes(W, I):
    n = W.max() + 1
    pai = list(range(n))

    def f(a):
        while pai[a] != a:
            pai[a] = pai[pai[a]]
            a = pai[a]
        return a
    for a, b, c in W[I]:
        for u, v in ((a, b), (b, c)):
            ru, rv = f(u), f(v)
            if ru != rv:
                pai[ru] = rv
    return np.array([f(W[I[t, 0]]) for t in range(len(I))])


def preparar(cfg):
    """lê, limpa fragmentos, espelha, centra e escala. Devolve P (final), UV, I, tex e a função de transformação de pontos."""
    P, UV, I, tex = ler_glb(os.path.join(ENTRADA, cfg['src']))
    W = soldar(P)
    comp = componentes(W, I)
    ids, cont = np.unique(comp, return_counts=True)
    manter = ids[np.argmax(cont)]
    I = I[comp == manter]                       # só o corpo principal (descarta fragmentos soltos)
    usados = np.unique(I.ravel())
    novo = -np.ones(len(P), dtype=np.int64)
    novo[usados] = np.arange(len(usados))
    P, UV, I = P[usados], UV[usados], novo[I]
    if cfg['mirror']:
        P = P * np.array([-1.0, 1.0, 1.0])
        I = I[:, [0, 2, 1]]                     # inverte o enrolamento dos triângulos
    J = {k: np.array(v, dtype=np.float64) for k, v in cfg['J'].items()}
    chao = P[:, 1].min()                        # pés em y = 0
    hips = (J['hip_R'] + J['hip_L']) / 2
    c = np.array([hips[0], chao, hips[2]])
    s = cfg['height'] / (P[:, 1].max() - chao)
    P = (P - c) * s
    J = {k: (v - c) * s for k, v in J.items()}
    return P, UV, I, tex, J, s


# ---------------------------------------------------------------- esqueleto
def colar(J):
    """base do pescoço (pivô do osso neck): abaixo da articulação da cabeça"""
    return J['neck'] + np.array([0.0, -0.07, -0.02])


def bola(J, s):
    """articulação da frente do pé (onde os dedos dobram): entre o tornozelo e a ponta"""
    a, t = J['ankle_' + s], J['toe_' + s]
    return a + (t - a) * 0.62


def esqueleto(J):
    """posição de cada osso (pivô) no repouso, e ângulos de repouso (graus; 0 = membro a pender, + = para a frente)"""
    hipc = (J['hip_R'] + J['hip_L']) / 2
    collar = colar(J)
    pos = {'pelvis': hipc, 'spine': hipc + (J['waist'] - hipc) * 0.5, 'torso': J['waist'], 'chest': (J['waist'] + collar) / 2, 'neck': collar, 'head': J['neck']}
    for s in 'RL':
        pos['clavicle_' + s] = collar + np.array([0.02 if s == 'L' else -0.02, 0.0, 0.0])
        pos['shoulder_' + s] = J['sh_' + s]
        pos['elbow_' + s] = J['el_' + s]
        pos['hand_' + s] = J['wr_' + s]
        pos['thigh_' + s] = J['hip_' + s]
        pos['knee_' + s] = J['knee_' + s]
        pos['foot_' + s] = J['ankle_' + s]
        pos['toe_' + s] = bola(J, s)

    def ang(a, b):
        return math.degrees(math.atan2(b[2] - a[2], -(b[1] - a[1])))
    rest, comp = {}, {}
    for s in 'RL':
        ua, fa = ang(J['sh_' + s], J['el_' + s]), ang(J['el_' + s], J['wr_' + s])
        th, sh = ang(J['hip_' + s], J['knee_' + s]), ang(J['knee_' + s], J['ankle_' + s])
        rest['shoulder_' + s], rest['elbow_' + s] = ua, fa - ua
        rest['thigh_' + s], rest['knee_' + s] = th, sh - th
        comp[s] = (float(np.linalg.norm(J['knee_' + s][1:] - J['hip_' + s][1:])), th, sh - th)
    return pos, rest, comp


def capsulas(J, R):
    """lista (osso, a, b, raio) por osso"""
    hipc = (J['hip_R'] + J['hip_L']) / 2
    col = colar(J)
    mid = (J['waist'] + col) / 2
    sp = hipc + (J['waist'] - hipc) * 0.5
    C = [('pelvis', hipc, sp, R['pelvis']), ('spine', sp, J['waist'], R['pelvis'] * 0.95), ('torso', J['waist'], mid, R['torso']), ('chest', mid, col, R['torso']),
         ('neck', col, J['neck'], R['head'] * 0.55), ('head', J['neck'], J['head_top'], R['head'])]
    for s in 'RL':
        cl = col + np.array([0.02 if s == 'L' else -0.02, 0.0, 0.0])
        C += [('clavicle_' + s, cl, J['sh_' + s], R['ua'] * 0.9),
              ('shoulder_' + s, J['sh_' + s], J['el_' + s], R['ua']),
              ('elbow_' + s, J['el_' + s], J['wr_' + s], R['fa']), ('hand_' + s, J['wr_' + s], J['fist_' + s], R['fist']),
              ('thigh_' + s, J['hip_' + s], J['knee_' + s], R['th']),
              ('knee_' + s, J['knee_' + s], J['ankle_' + s], R['sh']),
              ('foot_' + s, J['ankle_' + s], J['heel_' + s], R['ft']), ('foot_' + s, J['ankle_' + s], bola(J, s), R['ft']),
              ('toe_' + s, bola(J, s), J['toe_' + s], R['ft'] * 0.9)]
    return C


def dist_segmento(P, a, b):
    ab = b - a
    t = np.clip(((P - a) @ ab) / max(ab @ ab, 1e-12), 0, 1)
    return np.linalg.norm(P - (a + t[:, None] * ab), axis=1)


# ---------------------------------------------------------------- pesos de skinning
def pesos(P, I, J, R):
    W = soldar(P)
    nw = W.max() + 1
    Pw = np.zeros((nw, 3))
    Pw[W] = P
    sd = np.full((nw, len(BONES)), 1e9)
    for osso, a, b, r in capsulas(J, R):
        d = dist_segmento(Pw, a, b) - r
        sd[:, BI[osso]] = np.minimum(sd[:, BI[osso]], d)
    sd -= sd.min(axis=1, keepdims=True)
    w = np.exp(-sd / TAU)
    w /= w.sum(axis=1, keepdims=True)
    # difusão pelas arestas da malha: tira ruído e suaviza as transições
    e = np.concatenate([W[I[:, [0, 1]]], W[I[:, [1, 2]]], W[I[:, [2, 0]]]])
    e = np.concatenate([e, e[:, ::-1]])
    e = np.unique(e, axis=0)
    grau = np.bincount(e[:, 0], minlength=nw).astype(np.float64)
    alfa, it = DIFUSAO
    for _ in range(it):
        viz = np.zeros_like(w)
        np.add.at(viz, e[:, 0], w[e[:, 1]])
        viz /= np.maximum(grau, 1)[:, None]
        w = (1 - alfa) * w + alfa * viz
    w = w[W]                                    # volta aos vértices originais (com costuras de UV)
    # 4 influências no máximo
    idx = np.argsort(-w, axis=1)[:, :4]
    top = np.take_along_axis(w, idx, axis=1)
    top[top < 0.02] = 0
    top /= top.sum(axis=1, keepdims=True)
    return idx.astype(np.uint8), top.astype(np.float32)


def normais(P, I):
    W = soldar(P)
    fn = np.cross(P[I[:, 1]] - P[I[:, 0]], P[I[:, 2]] - P[I[:, 0]])
    acc = np.zeros((W.max() + 1, 3))
    for k in range(3):
        np.add.at(acc, W[I[:, k]], fn)
    n = acc[W]
    return n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)


# ---------------------------------------------------------------- cinemática (igual à do jogo; usada na verificação)
def rx(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[1, 0, 0, 0], [0, c, -s, 0], [0, s, c, 0], [0, 0, 0, 1.0]])


def ry(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, 0, s, 0], [0, 1, 0, 0], [-s, 0, c, 0], [0, 0, 0, 1.0]])


def tr(v):
    m = np.eye(4)
    m[:3, 3] = v
    return m


def sc(s):
    m = np.eye(4)
    m[0, 0] = m[1, 1] = m[2, 2] = s
    return m


def ordem_hierarquia():
    """ossos com o pai sempre antes dos filhos"""
    out = []
    while len(out) < len(BONES):
        for b in BONES:
            if b not in out and (PARENT[b] is None or PARENT[b] in out):
                out.append(b)
    return out


def matrizes(pos, local_rot, escala_braco=1.0):
    """matriz de mundo de cada osso. local_rot[osso] = matriz de rotação 4x4 local"""
    M = {}
    for b in ordem_hierarquia():
        p = PARENT[b]
        off = pos[b] - (pos[p] if p else np.zeros(3))
        L = tr(off) @ local_rot.get(b, np.eye(4))
        if b.startswith('shoulder_'):
            L = L @ sc(escala_braco)
        M[b] = (M[p] if p else np.eye(4)) @ L
    return M


def posar(P, idx, w, pos, rest, comp, c, escala_braco, rest_y):
    """aplica uma pose do jogo (chaves de model.js) ao modelo. Devolve os vértices deformados"""
    d = math.radians
    rot = {'pelvis': ry(d(c['by'])), 'torso': rx(-d(c['tz'])) @ ry(d(c['ty'])), 'head': rx(-d(c['hz']))}
    for k, v in (c.get('extra') or {}).items():      # rotações dos ossos novos: {'foot_R': graus, ...} (eixo X)
        rot[k] = rx(-d(v)) @ rot.get(k, np.eye(4))
    for s, k in (('R', 'r'), ('L', 'l')):
        rot['shoulder_' + s] = rx(-d(c[k + 'UA'] - rest['shoulder_' + s]))
        rot['elbow_' + s] = rx(-d(c[k + 'FA'] - rest['elbow_' + s]))
        rot['thigh_' + s] = rx(-d(c[k + 'Th'] - rest['thigh_' + s]))
        rot['knee_' + s] = rx(-d(c[k + 'Sh'] - rest['knee_' + s]))
    ext = []
    for s, k in (('R', 'r'), ('L', 'l')):
        A, th, sh = comp[s]
        B = (rest_y - A * math.cos(d(th))) / math.cos(d(th + sh))
        ext.append(A * math.cos(d(c[k + 'Th'])) + B * math.cos(d(c[k + 'Th'] + c[k + 'Sh'])))
    y = max(ext) + c['hip']        # = rest_y + (ext - rest_y): cada perna dá rest_y em repouso
    M0 = matrizes(pos, {}, 1.0)
    # o osso pelvis em repouso fica em pos['pelvis'] (altura rest_y); na pose desloca-se para a altura y
    M1 = {b: tr(np.array([0, y - pos['pelvis'][1], 0])) @ m for b, m in matrizes(pos, rot, escala_braco).items()}
    Ph = np.hstack([P, np.ones((len(P), 1))])
    out = np.zeros_like(P)
    for k in range(4):
        for b in range(len(BONES)):
            m = idx[:, k] == b
            if not m.any():
                continue
            T = M1[BONES[b]] @ np.linalg.inv(M0[BONES[b]])
            out[m] += w[m, k][:, None] * (Ph[m] @ T.T)[:, :3]
    return out


# ---------------------------------------------------------------- escrita do GLB
def jpeg(tex, lado, q=90):
    t = tex.resize((lado, lado), Image.LANCZOS) if tex.size[0] != lado else tex
    b = io.BytesIO()
    t.save(b, 'JPEG', quality=q, optimize=True)
    return b.getvalue()


def escrever(path, P, UV, I, idx, w, pos, rest, comp, rest_y, cfg, jpg, J, nome):
    escala = escalas_bracos(J, cfg)
    N = normais(P, I)
    sem = {}
    for s in 'RL':
        A, th, shr = comp[s]
        sem[s] = A
    nb = len(BONES)
    nos = [{'name': 'root', 'children': [1, nb + 1]}]
    glow = {s: (J['wr_' + s] * 0.5 + J['fist_' + s] * 0.5 - pos['elbow_' + s]) for s in 'RL'}
    for b in BONES:
        p = PARENT[b]
        off = pos[b] - (pos[p] if p else np.zeros(3))
        nd = {'name': b, 'translation': [round(float(v), 5) for v in off]}
        ex = {'rest': round(float(rest.get(b, 0.0)), 3)}
        if b.startswith('shoulder_'):
            ex['runScale'] = round(float(escala[b[-1]]), 3)
        if b.startswith('elbow_'):
            ex['glow'] = [round(float(v), 4) for v in glow[b[-1]]]
        if b == 'pelvis':
            legs = {}
            for s in 'RL':
                A, th, shr = comp[s]
                B = (rest_y - A * math.cos(math.radians(th))) / math.cos(math.radians(th + shr))
                legs[s] = [round(A, 4), round(B, 4)]
            ex.update({'restY': round(float(rest_y), 4), 'legs': legs, 'legA': legs['R'][0], 'legB': legs['R'][1]})
        nd['extras'] = ex
        kids = [BI[c] + 1 for c in BONES if PARENT[c] == b]
        if kids:
            nd['children'] = kids
        nos.append(nd)
    nos[1]['translation'] = [round(float(v), 5) for v in pos['pelvis']]
    nos.append({'name': 'body', 'mesh': 0, 'skin': 0})

    blobs, views, accs = [], [], []

    def add(arr, comp_type, tipo, target, minmax=False):
        raw = np.ascontiguousarray(arr).tobytes()
        pad = (-sum(len(x) for x in blobs)) % 4
        if pad:
            blobs.append(b'\0' * pad)
        views.append({'buffer': 0, 'byteOffset': sum(len(x) for x in blobs), 'byteLength': len(raw), 'target': target} if target else
                     {'buffer': 0, 'byteOffset': sum(len(x) for x in blobs), 'byteLength': len(raw)})
        blobs.append(raw)
        a = {'bufferView': len(views) - 1, 'componentType': comp_type, 'count': int(len(arr)), 'type': tipo}
        if minmax:
            a['min'] = [float(v) for v in arr.min(axis=0)]
            a['max'] = [float(v) for v in arr.max(axis=0)]
        accs.append(a)
        return len(accs) - 1
    aP = add(P.astype('<f4'), 5126, 'VEC3', 34962, True)
    aN = add(N.astype('<f4'), 5126, 'VEC3', 34962)
    aT = add(UV.astype('<f4'), 5126, 'VEC2', 34962)
    aJ = add(idx.astype('<u1'), 5121, 'VEC4', 34962)
    aW = add(w.astype('<f4'), 5126, 'VEC4', 34962)
    aI = add(I.astype('<u2').reshape(-1), 5123, 'SCALAR', 34963)
    ibm = []
    for b in BONES:
        m = np.eye(4)
        m[:3, 3] = -world_rest(pos, b)
        ibm.append(m.T.reshape(-1))
    aB = add(np.array(ibm, dtype='<f4').reshape(-1, 16), 5126, 'MAT4', None)
    pad = (-sum(len(x) for x in blobs)) % 4
    if pad:
        blobs.append(b'\0' * pad)
    views.append({'buffer': 0, 'byteOffset': sum(len(x) for x in blobs), 'byteLength': len(jpg)})
    blobs.append(jpg)
    tris = len(I)
    j = {'asset': {'version': '2.0', 'generator': 'Dark Kombat tools/build_textured_glb.py'},
         'extras': {'triangles': tris, 'textured': True, 'skinned': True, 'character': nome},
         'scene': 0, 'scenes': [{'nodes': [0]}], 'nodes': nos,
         'skins': [{'joints': list(range(1, nb + 1)), 'inverseBindMatrices': aB, 'skeleton': 1}],
         'meshes': [{'primitives': [{'attributes': {'POSITION': aP, 'NORMAL': aN, 'TEXCOORD_0': aT, 'JOINTS_0': aJ, 'WEIGHTS_0': aW},
                                      'indices': aI, 'material': 0, 'mode': 4}]}],
         'materials': [{'name': nome, 'pbrMetallicRoughness': {'baseColorTexture': {'index': 0}, 'metallicFactor': 0.1, 'roughnessFactor': 0.7}}],
         'textures': [{'source': 0}], 'images': [{'bufferView': len(views) - 1, 'mimeType': 'image/jpeg'}],
         'accessors': accs, 'bufferViews': views, 'buffers': [{'byteLength': sum(len(x) for x in blobs)}]}
    js = json.dumps(j, separators=(',', ':')).encode()
    js += b' ' * ((-len(js)) % 4)
    bn = b''.join(blobs)
    bn += b'\0' * ((-len(bn)) % 4)
    total = 12 + 8 + len(js) + 8 + len(bn)
    with open(path, 'wb') as f:
        f.write(struct.pack('<4sII', b'glTF', 2, total))
        f.write(struct.pack('<I4s', len(js), b'JSON') + js)
        f.write(struct.pack('<I4s', len(bn), b'BIN\0') + bn)
    return tris, total


def escalas_bracos(J, cfg):
    """escala de execução de cada braço: o jogo precisa de alcance de golpe parecido nos dois; o braço mais curto
    (ex.: o da guarda, dobrado no modelo) cresce até igualar o outro (no máximo +30 %)"""
    ln = {s: float(np.linalg.norm(J['el_' + s] - J['sh_' + s]) + np.linalg.norm(J['wr_' + s] - J['el_' + s])) for s in 'RL'}
    mx = max(ln.values())
    return {s: cfg['arm_scale'] * min(mx / ln[s], 1.3) for s in 'RL'}


def world_rest(pos, b):
    return pos[b]          # em repouso todas as rotações são nulas: a posição de mundo é a própria posição do pivô


def construir(nome, preview=False):
    cfg = CONFIG[nome]
    P, UV, I, tex, J, s = preparar(cfg)
    n0 = len(I)
    P, UV, I = decimar(P, UV, I, ALVO_TRIANGULOS)   # menos polígonos (jogo leve); costuras de UV preservadas
    print('   decimação:', n0, '->', len(I), 'triângulos')
    pos, rest, comp = esqueleto(J)
    R = cfg['R']
    idx, w = pesos(P, I, J, R)
    rest_y = float(pos['pelvis'][1])
    res = []
    for lod, lado in (('lod0', 1024), ('lod1', 512)):
        out = os.path.join(SAIDA, '%s_%s.glb' % (nome, lod))
        tris, tam = escrever(out, P, UV, I, idx, w, pos, rest, comp, rest_y, cfg, jpeg(tex, lado), J, nome)
        res.append('%s: %d triângulos, %.0f KB' % (os.path.basename(out), tris, tam / 1024))
    return dict(P=P, UV=UV, I=I, tex=tex, J=J, pos=pos, rest=rest, comp=comp, idx=idx, w=w, rest_y=rest_y, cfg=cfg, log=res)


if __name__ == '__main__':
    os.makedirs(SAIDA, exist_ok=True)
    for n in CONFIG:
        r = construir(n)
        print(n, '| repouso (graus):', {k: round(v, 1) for k, v in r['rest'].items()})
        print('   ', '; '.join(r['log']))
