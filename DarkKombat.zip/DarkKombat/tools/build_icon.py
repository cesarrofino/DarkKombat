"""Gera o ícone do Dark Kombat: vectores adaptativos (Android 8+) e PNG para versões antigas + 512 px da Play Store.
Uso: python3 tools/build_icon.py  (precisa de Pillow). Geometria no espaço 108x108 do ícone adaptativo (zona segura 21..87)."""
import os
from PIL import Image, ImageDraw, ImageFilter, ImageChops
R = os.path.join(os.path.dirname(__file__), '..', 'app', 'src', 'main', 'res')
CY, MG, BG = '#00E5FF', '#FF2BD6', '#070A18'
K = [  # letra K em polígonos (haste + braço + perna)
    [(33, 30), (46, 30), (46, 78), (33, 78)],
    [(44, 52), (64, 30), (79, 30), (53, 59), (44, 62)],
    [(48, 55), (57, 51), (81, 78), (65, 78)],
]
SLASH = [(22, 74), (27, 68), (88, 38), (84, 45)]            # golpe magenta atrás da letra (diagonal)
RING_R, RING_W = 34, 2.6
def path(poly): return 'M' + 'L'.join('%g,%g' % p for p in poly) + 'z'

def write(p, s):
    os.makedirs(os.path.dirname(p), exist_ok=True); open(p, 'w', encoding='utf-8').write(s)
H = '<?xml version="1.0" encoding="utf-8"?>\n'
VEC = '<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">\n'
def p(color, d, alpha=None, extra=''):
    return '  <path android:fillColor="%s"%s android:pathData="%s"%s/>\n' % (color, (' android:fillAlpha="%s"' % alpha) if alpha else '', d, extra)

# fundo: azul-noite com brilhos ciano/magenta
bg = H + VEC + p(BG, 'M0,0h108v108h-108z')
bg += p(MG, 'M-10,100a52,52 0 1,0 104,0a52,52 0 1,0 -104,0z', '0.16') + p(CY, 'M30,0a40,40 0 1,0 80,0a40,40 0 1,0 -80,0z', '0.14')
bg += p('#0D1433', 'M54,14l36,20v40l-36,20l-36,-20v-40z', '0.9') + '</vector>\n'
write(R + '/drawable/ic_launcher_background.xml', bg)

# primeiro plano: anel néon, golpe, K com contorno de brilho
ring = 'M54,%g a%g,%g 0 1,0 0,%g a%g,%g 0 1,0 0,-%g z' % (54 - RING_R, RING_R, RING_R, 2 * RING_R, RING_R, RING_R, 2 * RING_R)
fg = H + VEC
fg += '  <path android:strokeColor="%s" android:strokeWidth="%g" android:pathData="%s"/>\n' % (CY, RING_W, ring)
fg += p(MG, path(SLASH))
for k in K: fg += p('#FFFFFF', path(k))
fg += p(CY, path([(33, 30), (46, 30), (46, 34), (33, 34)]), '0.9')
fg += '</vector>\n'
write(R + '/drawable/ic_launcher_foreground.xml', fg)
mono = fg.replace(CY, '#FFFFFF').replace(MG, '#FFFFFF')
write(R + '/drawable/ic_launcher_monochrome.xml', mono)
ad = H + '<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n  <background android:drawable="@drawable/ic_launcher_background"/>\n  <foreground android:drawable="@drawable/ic_launcher_foreground"/>\n  <monochrome android:drawable="@drawable/ic_launcher_monochrome"/>\n</adaptive-icon>\n'
write(R + '/mipmap-anydpi-v26/ic_launcher.xml', ad); write(R + '/mipmap-anydpi-v26/ic_launcher_round.xml', ad)

# PNG (mesma composição, desenhada com sobre-amostragem)
S = 1080   # 10 px por unidade
def pts(poly): return [(x * 10, y * 10) for x, y in poly]
def master():
    im = Image.new('RGB', (S, S), BG); d = ImageDraw.Draw(im, 'RGBA')
    d.ellipse([-100, 480, 840, 1420], fill=(255, 43, 214, 40)); d.ellipse([300, -400, 1100, 400], fill=(0, 229, 255, 36))
    d.polygon(pts([(54, 14), (90, 34), (90, 74), (54, 94), (18, 74), (18, 34)]), fill=(13, 20, 51, 230))
    glow = Image.new('RGB', (S, S), (0, 0, 0)); g = ImageDraw.Draw(glow)
    g.ellipse([540 - RING_R * 10, 540 - RING_R * 10, 540 + RING_R * 10, 540 + RING_R * 10], outline=(0, 229, 255), width=int(RING_W * 10))
    g.polygon(pts(SLASH), fill=(255, 43, 214))
    for k in K: g.polygon(pts(k), fill=(120, 230, 255))
    im = ImageChops.add(im, glow.filter(ImageFilter.GaussianBlur(26)))
    d = ImageDraw.Draw(im)
    d.ellipse([540 - RING_R * 10, 540 - RING_R * 10, 540 + RING_R * 10, 540 + RING_R * 10], outline=(0, 229, 255), width=int(RING_W * 10))
    d.polygon(pts(SLASH), fill=(255, 43, 214))
    for k in K: d.polygon(pts(k), fill=(255, 255, 255))
    d.polygon(pts([(33, 30), (46, 30), (46, 34), (33, 34)]), fill=(0, 229, 255))
    return im
M = master().crop((100, 100, 980, 980))   # recorte central (versões sem ícone adaptativo)
def icon(px, round_):
    im = M.resize((px, px), Image.LANCZOS).convert('RGBA'); m = Image.new('L', (px * 4, px * 4), 0); d = ImageDraw.Draw(m)
    if round_: d.ellipse([0, 0, px * 4 - 1, px * 4 - 1], fill=255)
    else: d.rounded_rectangle([0, 0, px * 4 - 1, px * 4 - 1], radius=px * 4 * 0.22, fill=255)
    im.putalpha(m.resize((px, px), Image.LANCZOS)); return im
for name, px in [('mdpi', 48), ('hdpi', 72), ('xhdpi', 96), ('xxhdpi', 144), ('xxxhdpi', 192)]:
    os.makedirs(R + '/mipmap-' + name, exist_ok=True)
    icon(px, False).save(R + '/mipmap-%s/ic_launcher.png' % name); icon(px, True).save(R + '/mipmap-%s/ic_launcher_round.png' % name)
M.resize((512, 512), Image.LANCZOS).save(os.path.join(R, '..', '..', '..', 'icon-512.png'))   # Play Store (sem máscara)
print('ícones gerados')
