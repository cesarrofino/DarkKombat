#!/usr/bin/env python3
"""Gera todos os sons e músicas do Dark Kombat (síntese própria, sem amostras de terceiros).
Requer Python 3 + numpy + scipy. Os ficheiros resultantes são originais deste projecto (CC0).

Efeitos: 44,1 kHz mono, em camadas (grave + estalo + ruído filtrado + reverberação curta) para terem corpo.
Músicas: 32 kHz estéreo, synthwave (bateria, baixo, pads, arpejo com eco, melodia), com 'sidechain' no pad/baixo."""
import os, wave
import numpy as np
from scipy import signal as sg

SR = 44100            # efeitos
MSR = 32000           # músicas
OUT = os.path.join(os.path.dirname(__file__), '..', 'app', 'src', 'main', 'assets', 'game', 'audio')
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(11)


# ---------------------------------------------------------------- utilitários
def T(d, sr=SR): return np.arange(int(sr * d)) / sr
def noise(d, sr=SR): return rng.uniform(-1, 1, int(sr * d))
def env(d, rate, sr=SR): return np.exp(-T(d, sr) * rate)
def midi(n): return 440.0 * 2 ** ((np.asarray(n, dtype=float) - 69) / 12)

def sos(kind, fc, sr, order=2):
    fc = np.atleast_1d(fc).astype(float)
    fc = np.clip(fc, 20, sr * 0.45)
    return sg.butter(order, fc / (sr / 2) if len(fc) > 1 else fc[0] / (sr / 2), kind, output='sos')
def lp(x, fc, sr=SR, order=2): return sg.sosfilt(sos('low', fc, sr, order), x)
def hp(x, fc, sr=SR, order=2): return sg.sosfilt(sos('high', fc, sr, order), x)
def bp(x, lo, hi, sr=SR, order=2): return sg.sosfilt(sos('band', [lo, hi], sr, order), x)

def swept(x, fcs, kind='low', q=1.0, sr=SR, block=128):
    """Filtro de frequência variável no tempo (bloco a bloco, mantendo o estado). fcs: frequência por amostra."""
    y = np.zeros_like(x); zi = None; s = None
    for i in range(0, len(x), block):
        fc = float(np.clip(fcs[min(i, len(fcs) - 1)], 40, sr * 0.45))
        if kind == 'band': s = sg.butter(2, [fc * 0.7 / (sr / 2), min(0.99, fc * 1.4 / (sr / 2))], 'band', output='sos')
        else: s = sg.butter(2, fc / (sr / 2), kind, output='sos')
        if zi is None or zi.shape[0] != s.shape[0]: zi = np.zeros((s.shape[0], 2))
        seg, zi = sg.sosfilt(s, x[i:i + block], zi=zi); y[i:i + block] = seg
    return y

def conv(x, ir, n):
    y = sg.fftconvolve(x, ir)[:n]
    return np.pad(y, (0, n - len(y)))

def sat(x, drive=2.0): return np.tanh(x * drive) / np.tanh(drive)

def reverb(x, t=0.6, wet=0.2, sr=SR, seed=3, stereo=False):
    r = np.random.default_rng(seed); n = int(sr * t)
    def ir():
        i = r.uniform(-1, 1, n) * np.exp(-np.arange(n) / sr * (6.9 / t)); i = lp(i, 5500, sr); i[0] = 0; return i / np.sqrt(np.sum(i * i))
    if stereo:
        return [np.pad(x, (0, n)) * (1 - wet) + wet * conv(x, ir(), len(x) + n) for _ in range(2)]
    y = np.pad(x, (0, n)); return y * (1 - wet) + wet * conv(x, ir(), len(y))

def save(name, x, gain=0.9, sr=SR):
    x = np.asarray(x, dtype=np.float64)
    if x.ndim == 1: x = x[:, None]
    peak = max(1e-9, np.max(np.abs(x))); x = x / peak * gain
    # fade-in/out curtos (evita cliques)
    if sr == SR:   # só nos efeitos; as músicas fazem loop contínuo
        f = min(len(x) // 4, int(sr * 0.004)); x[:f] *= np.linspace(0, 1, f)[:, None]
        g = min(len(x) // 4, int(sr * 0.02)); x[-g:] *= np.linspace(1, 0, g)[:, None]
    with wave.open(os.path.join(OUT, name + '.wav'), 'wb') as w:
        w.setnchannels(x.shape[1]); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes((np.clip(x, -1, 1) * 32767).astype('<i2').tobytes())

def sweep(f0, f1, d, rate, sr=SR):
    t = T(d, sr); f = f1 + (f0 - f1) * np.exp(-t * rate)
    return np.sin(2 * np.pi * np.cumsum(f) / sr)

def saw_w(f, d, sr=SR, detune=0.0):
    t = T(d, sr); f = np.broadcast_to(f, t.shape) if np.ndim(f) else f
    ph = np.cumsum(np.broadcast_to(f, t.shape)) / sr if np.ndim(f) else t * f
    out = 2 * (ph % 1.0) - 1
    if detune:
        ph2 = ph * (1 + detune); out = (out + 2 * (ph2 % 1.0) - 1) * 0.5
    return out

def sq_w(f, d, sr=SR, duty=0.5):
    t = T(d, sr); ph = (t * f) % 1.0; return np.where(ph < duty, 1.0, -1.0)

def swish(d, f0, f1, f2, q=1.0, sr=SR):
    """ruído com banda a deslizar f0 -> f1 -> f2 (assobio de golpe no ar)"""
    n = int(sr * d); t = np.linspace(0, 1, n)
    fc = np.where(t < 0.5, f0 + (f1 - f0) * (t / 0.5) ** 1.5, f1 + (f2 - f1) * ((t - 0.5) / 0.5))
    x = swept(noise(d, sr), fc, 'band', sr=sr)
    return x


# ---------------------------------------------------------------- efeitos
def fx_punch():
    d = 0.3
    thump = sweep(190, 62, d, 55) * env(d, 30)
    slap = bp(noise(d), 700, 4500) * env(d, 70) * 0.9
    crack = hp(noise(d), 3500) * env(d, 160) * 0.5
    x = sat(thump * 1.2 + slap + crack, 2.2); x = hp(x, 45)
    return reverb(x, 0.25, 0.1)

def fx_kick():
    d = 0.38
    thump = sweep(150, 42, d, 28) * env(d, 14) * 1.2
    sub = np.sin(2 * np.pi * 48 * T(d)) * env(d, 9) * 0.6
    slap = bp(noise(d), 500, 3200) * env(d, 38) * 1.0
    crack = hp(noise(d), 2500) * env(d, 120) * 0.55
    x = sat(thump + sub + slap + crack, 2.6); x = hp(x, 35)
    return reverb(x, 0.35, 0.14)

def fx_hit():
    d = 0.6
    boom = sweep(110, 28, d, 16) * env(d, 8) * 1.3
    body = lp(noise(d), 1400) * env(d, 12) * 0.9
    crunch = sat(bp(noise(d), 300, 2500) * np.sin(2 * np.pi * 170 * T(d)), 3) * env(d, 20) * 0.8
    crack = hp(noise(d), 3000) * env(d, 110) * 0.6
    x = sat(boom + body + crunch + crack, 2.8); x = hp(x, 30)
    return reverb(x, 0.6, 0.22)

def fx_block():
    d = 0.5; t = T(d)
    x = np.zeros(len(t))
    for f, a, r in [(880, 1.0, 11), (1334, 0.7, 14), (2310, 0.55, 18), (3420, 0.4, 26), (5100, 0.25, 34)]:
        x += np.sin(2 * np.pi * f * t) * np.exp(-t * r) * a
    x *= 0.55
    x += bp(noise(d), 1500, 6500) * env(d, 90) * 0.9 + sweep(210, 90, d, 40) * env(d, 40) * 0.5
    return reverb(sat(x, 1.6), 0.4, 0.16)

def fx_special():
    d = 1.6; n = int(SR * d); t = T(d); x = np.zeros(n)
    rise = 0.58; nr = int(SR * rise); u = np.linspace(0, 1, nr)
    f = 110 * (8 ** u)                                          # sobe 110 -> 880 Hz
    ph = np.cumsum(f) / SR; stack = (2 * (ph % 1) - 1) + 0.8 * (2 * ((ph * 1.007) % 1) - 1) + 0.6 * (2 * ((ph * 0.5) % 1) - 1)
    stack = swept(stack, 300 + 5000 * u ** 2, 'low') * (u ** 1.3) * 0.5
    nz = swept(noise(rise), 400 + 6500 * u ** 2, 'band') * (u ** 1.5) * 0.9
    x[:nr] += stack + nz
    tb = t[nr:] - 0; m = len(tb)
    boom = sweep(140, 26, d - rise, 12) * np.exp(-np.arange(m) / SR * 5) * 1.5
    blast = lp(noise(d - rise), 2400) * np.exp(-np.arange(m) / SR * 7) * 1.0 + hp(noise(d - rise), 3500) * np.exp(-np.arange(m) / SR * 40) * 0.8
    shim = (np.sin(2 * np.pi * 1320 * np.arange(m) / SR) + 0.6 * np.sin(2 * np.pi * 1980 * np.arange(m) / SR) + 0.4 * np.sin(2 * np.pi * 2640 * np.arange(m) / SR)) * np.exp(-np.arange(m) / SR * 5) * 0.28
    x[nr:] += boom + blast + shim
    return reverb(sat(x, 1.8), 0.9, 0.22)

def fx_whoosh():
    d = 0.24; x = swish(d, 700, 3200, 1500) * np.sin(np.pi * np.linspace(0, 1, int(SR * d))) ** 1.5
    return x * 0.8

def fx_spin():
    d = 0.62; n = int(SR * d); u = np.linspace(0, 1, n)
    x = swish(d, 400, 2600, 600)
    wind = swept(noise(d), 500 + 900 * np.sin(np.pi * u), 'band') * 0.5
    x = (x + wind) * np.sin(np.pi * u) ** 1.2
    # dois 'sopros' (volta completa) com um toque tonal
    tone = np.sin(2 * np.pi * np.cumsum(260 + 520 * np.sin(np.pi * u)) / SR) * 0.08 * np.sin(np.pi * u)
    return reverb(x + tone, 0.3, 0.1)

def voice(freq, d, cutoff=3500, wave='saw', atk=0.004, decay=6.0, sr=SR):
    f = freq
    if wave == 'saw': s = saw_w(f, d, sr, 0.006)
    else: s = 0.6 * sq_w(f, d, sr, 0.5) + 0.4 * saw_w(f, d, sr, 0.004)
    s = lp(s, cutoff, sr); e = np.exp(-T(d, sr) * decay) * np.minimum(1, T(d, sr) / atk)
    return s * e

def mix_at(buf, sig, start, sr=SR):
    s = int(sr * start); e = min(len(buf), s + len(sig)); buf[s:e] += sig[:e - s]

def fx_win():
    d = 2.0; x = np.zeros(int(SR * d))
    for i, n in enumerate([72, 76, 79, 84]): mix_at(x, voice(midi(n), 0.9, 5000, 'saw', decay=3.5), 0.11 * i)
    for n in [72, 76, 79, 84, 88]: mix_at(x, voice(midi(n), 1.5, 4200, 'saw', decay=2.2) * 0.55, 0.5)
    mix_at(x, sweep(120, 55, 0.5, 20) * env(0.5, 8) * 0.5, 0.5)
    return reverb(x, 1.2, 0.28)

def fx_lose():
    d = 2.2; x = np.zeros(int(SR * d))
    for i, n in enumerate([67, 63, 60, 55]): mix_at(x, voice(midi(n), 1.0, 1800, 'saw', decay=2.8) * 0.9, 0.3 * i)
    for n in [43, 50, 55]: mix_at(x, voice(midi(n), 1.4, 900, 'saw', decay=2.0) * 0.6, 0.9)
    return reverb(x, 1.3, 0.32)

def fx_click():
    d = 0.08; x = np.sin(2 * np.pi * 2400 * T(d)) * env(d, 90) + hp(noise(d), 4000) * env(d, 300) * 0.4
    return x

def fx_beep():
    d = 0.24; t = T(d); x = (np.sin(2 * np.pi * 880 * t) + 0.35 * np.sin(2 * np.pi * 1760 * t) + 0.15 * sq_w(880, d)) * np.minimum(1, t / 0.004) * np.exp(-t * 8)
    return reverb(x, 0.2, 0.1)

def fx_go():
    d = 1.1; x = np.zeros(int(SR * d)); u = np.linspace(0, 1, int(SR * 0.35))
    sw = swept(noise(0.35), 600 + 5000 * u ** 2, 'band') * u * 0.7; mix_at(x, sw, 0)
    for n in [64, 68, 71, 76]: mix_at(x, voice(midi(n), 0.75, 6000, 'sq', decay=4.0) * 0.55, 0.3)
    mix_at(x, sweep(130, 50, 0.5, 14) * env(0.5, 7) * 0.8, 0.3)
    return reverb(sat(x, 1.5), 0.7, 0.2)

def fx_ko():
    d = 2.4; n = int(SR * d); t = T(d)
    x = sweep(120, 22, d, 3.5) * np.exp(-t * 2.2) * 1.6
    x += lp(noise(d), 1800) * np.exp(-t * 4.5) * 1.1 + hp(noise(d), 3000) * np.exp(-t * 40) * 0.8
    for f, a in [(180, 0.5), (271, 0.4), (433, 0.3), (702, 0.2)]: x += np.sin(2 * np.pi * f * t) * np.exp(-t * 5) * a * 0.5
    x += np.sin(2 * np.pi * np.cumsum(520 * np.exp(-t * 1.3)) / SR) * np.exp(-t * 2.5) * 0.25
    return reverb(sat(x, 2.0), 1.6, 0.3)

SFX = {'punch': fx_punch, 'kick': fx_kick, 'hit': fx_hit, 'block': fx_block, 'special': fx_special, 'whoosh': fx_whoosh, 'spin': fx_spin,
       'win': fx_win, 'lose': fx_lose, 'click': fx_click, 'beep': fx_beep, 'go': fx_go, 'ko': fx_ko}
for name, fn in SFX.items():
    save(name, fn(), 0.92)


# ---------------------------------------------------------------- músicas (estéreo, 32 kHz)
class Track:
    def __init__(self, bpm, bars):
        self.bpm = bpm; self.bars = bars; self.beat = 60.0 / bpm; self.total = int(MSR * self.beat * 4 * bars)
        self.L = np.zeros(self.total); self.R = np.zeros(self.total)
        self.busses = {k: [np.zeros(self.total), np.zeros(self.total)] for k in ('drums', 'bass', 'pad', 'arp', 'lead', 'fx')}
        self.kicks = []

    def put(self, bus, sig, start, pan=0.0, gain=1.0):
        s = int(MSR * start); idx = (np.arange(len(sig)) + s) % self.total
        l = gain * np.cos((pan + 1) * np.pi / 4); r = gain * np.sin((pan + 1) * np.pi / 4)
        np.add.at(self.busses[bus][0], idx, sig * l); np.add.at(self.busses[bus][1], idx, sig * r)

    def duck(self, depth=0.7, rel=0.16):
        d = np.ones(self.total); t = np.arange(self.total) / MSR
        for k in self.kicks:
            i = int(k * MSR); n = min(int(MSR * 0.5), self.total - i)
            if n > 0: d[i:i + n] = np.minimum(d[i:i + n], 1 - depth * np.exp(-np.arange(n) / MSR / rel) * (1 - np.exp(-np.arange(n) / MSR / 0.004)) )
        return d

    def echo(self, bus, delay, fb=0.38, taps=5, wet=0.5):
        l, r = self.busses[bus]; n = int(MSR * delay)
        el, er = np.zeros(self.total), np.zeros(self.total)
        sl, sr = l.copy(), r.copy()
        for k in range(1, taps + 1):
            a = wet * (fb ** (k - 1))
            for src, dst in ((sl, er if k % 2 else el), (sr, el if k % 2 else er)):
                sh = np.roll(src, n * k); dst += sh * a
        self.busses[bus][0] = l + lp(el, 4500, MSR); self.busses[bus][1] = r + lp(er, 4500, MSR)

    def rev(self, bus, t=1.2, wet=0.3, seed=5):
        for ch in (0, 1):
            x = self.busses[bus][ch]; r = np.random.default_rng(seed + ch); n = int(MSR * t)
            ir = r.uniform(-1, 1, n) * np.exp(-np.arange(n) / MSR * (6.9 / t)); ir = lp(ir, 4200, MSR); ir[0] = 0; ir /= np.sqrt(np.sum(ir * ir))
            tail = conv(np.concatenate([x, x]), ir, 2 * self.total)[self.total:]      # circular (loop contínuo)
            self.busses[bus][ch] = x * (1 - wet * 0.5) + wet * tail

    def render(self, name, levels, gain=0.88):
        L = np.zeros(self.total); R = np.zeros(self.total)
        for k, (l, r) in self.busses.items():
            g = levels.get(k, 0.0); L += l * g; R += r * g
        # compressão suave + limite
        for ch in (L, R):
            ch[:] = np.tanh(ch * 1.15) / np.tanh(1.15)
        peak = max(np.max(np.abs(L)), np.max(np.abs(R))); out = np.stack([L, R], 1) / peak * gain
        save(name, out, gain, sr=MSR)


def m_kick():
    d = 0.4; t = T(d, MSR); f = 48 + 120 * np.exp(-t * 38)
    x = np.sin(2 * np.pi * np.cumsum(f) / MSR) * np.exp(-t * 11) * 1.2 + hp(noise(d, MSR), 2500, MSR) * np.exp(-t * 200) * 0.35
    return sat(x, 1.8)

def m_snare():
    d = 0.35; t = T(d, MSR)
    x = bp(noise(d, MSR), 1200, 7500, MSR) * np.exp(-t * 17) * 0.9 + np.sin(2 * np.pi * (185 + 60 * np.exp(-t * 40)) * t) * np.exp(-t * 26) * 0.6
    x = sat(x, 1.6); n = int(MSR * 0.5); ir = np.random.default_rng(2).uniform(-1, 1, n) * np.exp(-np.arange(n) / MSR * 12); ir = lp(ir, 5000, MSR)
    return x + 0.35 * conv(x, ir / np.sqrt(np.sum(ir ** 2)), len(x))

def m_hat(open_=False):
    d = 0.28 if open_ else 0.07; t = T(d, MSR)
    return hp(noise(d, MSR), 7000, MSR) * np.exp(-t * (14 if open_ else 80)) * 0.5

def m_crash():
    d = 1.6; t = T(d, MSR); return hp(noise(d, MSR), 4500, MSR) * np.exp(-t * 3.2) * 0.45

def m_tom(f0):
    d = 0.3; t = T(d, MSR); return np.sin(2 * np.pi * np.cumsum(f0 * (1 + 0.9 * np.exp(-t * 30))) / MSR) * np.exp(-t * 12) * 0.9

def m_bass(f, d, cut=900, accent=1.0):
    t = T(d, MSR); s = (saw_w(f, d, MSR, 0.004) * 0.7 + sq_w(f, d, MSR) * 0.3)
    s = swept(s, cut * (0.35 + 1.6 * np.exp(-t * 22)), 'low', sr=MSR) + 0.55 * np.sin(2 * np.pi * f * t)
    return s * np.minimum(1, t / 0.004) * np.exp(-t * 3.5) * np.minimum(1, (d - t) / 0.02) * accent

def m_pad(notes, d, cut=2400):
    t = T(d, MSR); x = np.zeros(len(t))
    for n in notes:
        for dt in (-0.0045, 0.0, 0.0055): x += saw_w(midi(n) * (1 + dt), d, MSR) * 0.18
    x = lp(x, cut, MSR); return x * np.minimum(1, t / 0.25) * np.minimum(1, (d - t) / 0.35)

def m_pluck(f, d, cut=4200, pulse=True):
    s = (0.6 * sq_w(f, d, MSR, 0.35) + 0.4 * saw_w(f, d, MSR)) if pulse else saw_w(f, d, MSR, 0.003)
    t = T(d, MSR); s = swept(s, cut * (0.3 + 1.2 * np.exp(-t * 16)), 'low', sr=MSR)
    return s * np.exp(-t * 11) * np.minimum(1, t / 0.003)

def m_lead(f, d, cut=3800, vib=5.5):
    t = T(d, MSR); fm = f * (1 + 0.006 * np.sin(2 * np.pi * vib * t) * np.minimum(1, t / 0.2))
    s = saw_w(fm, d, MSR, 0.007) * 0.8 + sq_w(f, d, MSR, 0.5) * 0.25
    return lp(s, cut, MSR) * np.minimum(1, t / 0.01) * np.exp(-t * 2.2) * np.minimum(1, (d - t) / 0.05)

def fight_track():
    K = Track(140, 16); b = K.beat; s16 = b / 4
    roots = [45, 41, 48, 43]; triads = [[57, 60, 64], [53, 57, 60], [55, 60, 64], [55, 59, 62]]
    arp_seq = [0, 1, 2, 1, 0, 1, 2, 3, 2, 1, 0, 1, 2, 3, 4, 3]
    bass_pat = [1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0]
    mel = [  # compasso 9-16: (passo16, nota, duração em semicolcheias)
        [(0, 76, 3), (4, 79, 3), (8, 81, 4), (12, 79, 4)], [(0, 77, 3), (4, 81, 3), (8, 84, 4), (12, 81, 4)],
        [(0, 79, 3), (4, 76, 3), (8, 72, 4), (12, 76, 4)], [(0, 74, 3), (4, 79, 3), (8, 83, 6), (14, 81, 2)]] * 1
    for bar in range(16):
        t0 = bar * 4 * b; ci = bar % 4; root = roots[ci]; ch = triads[ci]
        # bateria
        for beat in range(4):
            tb = t0 + beat * b
            if bar >= 1 or beat >= 0: K.put('drums', m_kick(), tb, 0, 1.0); K.kicks.append(tb)
            if beat in (1, 3): K.put('drums', m_snare(), tb, 0.0, 0.95)
            for sub in range(4):
                v = [0.9, 0.5, 0.7, 0.5][sub]; K.put('drums', m_hat(False), tb + sub * s16, 0.25 if sub % 2 else -0.15, v * (0.7 if bar < 2 else 1))
            K.put('drums', m_hat(True), tb + b / 2, -0.3, 0.45)
        if bar in (0, 8): K.put('fx', m_crash(), t0, 0.0, 0.8)
        if bar in (7, 15):   # rolamento de caixa e toms no fim da frase
            for i in range(8): K.put('drums', m_snare(), t0 + 3 * b + i * b / 8, 0.0, 0.35 + 0.08 * i)
            for i, f0 in enumerate([180, 150, 120, 95]): K.put('drums', m_tom(f0), t0 + 2.5 * b + i * b / 4, -0.5 + i * 0.35, 0.8)
        # baixo
        for i, on in enumerate(bass_pat):
            if on:
                n = root + (12 if i in (3, 7, 11, 14) else 0); K.put('bass', m_bass(midi(n), s16 * 1.9, 950 + 500 * (bar >= 8), 1.0 if i % 4 == 0 else 0.8), t0 + i * s16, 0, 0.85)
        # pad
        K.put('pad', m_pad(ch + [ch[0] + 12], 4 * b + 0.2), t0 - 0.05, 0, 0.8)
        # arpejo (entra no compasso 3)
        if bar >= 2:
            for i in range(16):
                n = ch[arp_seq[i] % 3] + 12 * (arp_seq[i] // 3) + 12
                K.put('arp', m_pluck(midi(n), s16 * 1.6), t0 + i * s16, -0.55 + 1.1 * ((i % 4) / 3), 0.6)
        # melodia (compassos 9 a 16)
        if bar >= 8:
            for (st, n, dl) in mel[ci]: K.put('lead', m_lead(midi(n), dl * s16 * 0.97), t0 + st * s16, 0.1, 0.8)
    K.echo('arp', b * 0.75, 0.4, 5, 0.55); K.echo('lead', b * 0.75, 0.35, 4, 0.5)
    K.rev('pad', 1.6, 0.35); K.rev('lead', 1.3, 0.3); K.rev('arp', 1.0, 0.2)
    d = K.duck(0.65, 0.14)
    for bus in ('pad', 'bass'):
        K.busses[bus][0] *= d; K.busses[bus][1] *= d
    K.render('music_fight', {'drums': 0.95, 'bass': 0.95, 'pad': 0.55, 'arp': 0.5, 'lead': 0.5, 'fx': 0.5})

def menu_track():
    K = Track(90, 8); b = K.beat; s16 = b / 4
    roots = [38, 34, 41, 36]; triads = [[62, 65, 69, 72], [58, 62, 65, 69], [60, 65, 69, 72], [60, 64, 67, 71]]
    for bar in range(8):
        t0 = bar * 4 * b; ci = (bar // 2) % 4; ch = triads[ci]
        K.put('pad', m_pad(ch + [ch[0] - 12], 4 * b + 0.3, 1800), t0 - 0.1, 0, 0.9)
        for i in (0, 6, 10):
            K.put('bass', m_bass(midi(roots[ci]), s16 * 3.6, 520, 0.9), t0 + i * s16, 0, 0.8)
        for beat in (0, 2):
            tb = t0 + beat * b; K.put('drums', m_kick(), tb, 0, 0.8); K.kicks.append(tb)
        K.put('drums', m_snare(), t0 + 3 * b, 0, 0.45)
        for i in range(8): K.put('drums', m_hat(False), t0 + i * b / 2, 0.2 * (1 if i % 2 else -1), 0.35)
        for i in range(8):
            n = ch[[0, 2, 1, 3, 2, 1, 3, 2][i]] + 12; K.put('arp', m_pluck(midi(n), b * 0.9, 3000, False), t0 + i * b / 2, -0.6 + i * 0.17, 0.7)
        if bar % 4 == 0: K.put('fx', m_crash(), t0, 0, 0.35)
        if bar in (2, 6):
            for k, n in enumerate([81, 77, 74, 72]): K.put('lead', m_lead(midi(n), b * 1.7, 2600, 4.8), t0 + (1 + k * 0.5) * b, 0.2, 0.55)
    K.echo('arp', b * 0.75, 0.45, 6, 0.6); K.echo('lead', b * 0.75, 0.4, 5, 0.55)
    K.rev('pad', 2.2, 0.45); K.rev('arp', 1.6, 0.3); K.rev('lead', 1.8, 0.4)
    d = K.duck(0.45, 0.2)
    for bus in ('pad', 'bass'):
        K.busses[bus][0] *= d; K.busses[bus][1] *= d
    K.render('music_menu', {'drums': 0.7, 'bass': 0.9, 'pad': 0.75, 'arp': 0.55, 'lead': 0.5, 'fx': 0.5})

fight_track(); menu_track()
print('áudio gerado em', os.path.abspath(OUT))
