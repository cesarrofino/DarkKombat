#!/usr/bin/env python3
"""Gera todos os sons e músicas do Dark Kombat (síntese própria, sem amostras de terceiros).
Os ficheiros resultantes são originais deste projecto e ficam disponíveis sob CC0 (domínio público)."""
import os, wave
import numpy as np

SR = 22050
OUT = os.path.join(os.path.dirname(__file__), '..', 'app', 'src', 'main', 'assets', 'game', 'audio')
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(7)

def save(name, x, gain=0.9):
    x = np.asarray(x, dtype=np.float64)
    peak = max(1e-9, np.max(np.abs(x)))
    x = x / peak * gain
    with wave.open(os.path.join(OUT, name + '.wav'), 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((x * 32767).astype('<i2').tobytes())

def t_(d): return np.arange(int(SR * d)) / SR
def noise(d): return rng.uniform(-1, 1, int(SR * d))
def lowpass(x, k):
    y = np.zeros_like(x); a = 0.0
    for i, v in enumerate(x):
        a += k * (v - a); y[i] = a
    return y
def sweep(f0, f1, d):
    t = t_(d); f = f0 * (f1 / f0) ** (t / d)
    return np.sin(2 * np.pi * np.cumsum(f) / SR)
def adsr_exp(d, rate): return np.exp(-t_(d) * rate)
def saw(f, d):
    t = t_(d); return 2 * ((t * f) % 1.0) - 1

# ---------- efeitos ----------
save('punch', noise(0.14) * adsr_exp(0.14, 38) * 0.8 + sweep(160, 55, 0.14) * adsr_exp(0.14, 22))
save('kick', lowpass(noise(0.22), 0.18) * adsr_exp(0.22, 22) + sweep(120, 38, 0.22) * adsr_exp(0.22, 14) * 1.2)
d = 0.35; t = t_(d)
save('block', (np.sin(2*np.pi*880*t) + 0.7*np.sin(2*np.pi*1320*t) + 0.5*np.sin(2*np.pi*1980*t)) * adsr_exp(d, 14)
     + noise(d) * adsr_exp(d, 90) * 0.8)
save('hit', lowpass(noise(0.3), 0.3) * adsr_exp(0.3, 16) * 0.9 + sweep(220, 45, 0.3) * adsr_exp(0.3, 10) * 1.1
     + np.sin(2*np.pi*1400*t_(0.3)) * adsr_exp(0.3, 60) * 0.3)
d = 0.8; t = t_(d)
save('special', sweep(180, 1500, d) * np.minimum(1, t / 0.05) * np.exp(-np.maximum(0, t - 0.45) * 7) * 0.7
     + lowpass(noise(d), 0.12) * adsr_exp(d, 4) * 0.5 + sweep(90, 35, d) * adsr_exp(d, 5))
d = 0.2; t = t_(d)
save('whoosh', lowpass(noise(d), 0.35) * np.sin(np.pi * t / d) ** 2 * 0.6, 0.45)
d = 0.9; t = t_(d); n = 0.12; w = np.zeros(int(SR * d))
for i, f in enumerate([523.25, 659.25, 783.99, 1046.5]):
    s = int(SR * n * i); seg = np.sign(np.sin(2*np.pi*f*t_(0.5))) * 0.5 + np.sin(2*np.pi*f*t_(0.5))
    seg = seg * adsr_exp(0.5, 6); w[s:s+len(seg)] += seg[:len(w) - s]
save('win', w)
w = np.zeros(int(SR * 1.2))
for i, f in enumerate([392.0, 349.23, 311.13, 261.63]):
    s = int(SR * 0.22 * i); seg = (saw(f, 0.6) * 0.6 + np.sin(2*np.pi*f*t_(0.6))) * adsr_exp(0.6, 5)
    w[s:s+len(seg)] += seg[:len(w) - s]
save('lose', w)
t = t_(0.06); save('click', np.sin(2*np.pi*1500*t) * adsr_exp(0.06, 60), 0.6)
t = t_(0.16); save('beep', np.sin(2*np.pi*880*t) * np.minimum(1, t/0.005) * adsr_exp(0.16, 10), 0.7)
t = t_(0.5); save('go', (np.sin(2*np.pi*1320*t) + 0.5*np.sin(2*np.pi*1980*t) + 0.3*saw(660, 0.5)) * adsr_exp(0.5, 5), 0.8)
d = 1.1; t = t_(d)
save('ko', sweep(140, 30, d) * adsr_exp(d, 3) * 1.2 + lowpass(noise(d), 0.1) * adsr_exp(d, 5) * 0.8)

# ---------- música ----------
def midi(n): return 440.0 * 2 ** ((n - 69) / 12)

def render_track(bpm, bars, chords, arp_pattern, drums, bass_style, name, arp_gain=0.35, pad_gain=0.25):
    beat = 60.0 / bpm; total = int(SR * beat * 4 * bars)
    out = np.zeros(total)
    def put(sig, start):
        s = int(SR * start)
        n = len(sig)
        # com "wrap" para o loop ser contínuo
        idx = (np.arange(n) + s) % total
        np.add.at(out, idx, sig)
    for bar in range(bars):
        root, notes = chords[(bar // 2) % len(chords)]
        t0 = bar * 4 * beat
        # pad
        dpad = beat * 4
        pad = sum(np.sin(2*np.pi*midi(n)*t_(dpad) + k) for k, n in enumerate(notes))
        pad = pad * np.minimum(1, t_(dpad) / 0.3) * np.minimum(1, (dpad - t_(dpad)) / 0.3) * pad_gain / len(notes)
        put(pad, t0)
        # baixo
        steps = 8
        for i in range(steps):
            if bass_style == 'drive' or i % 2 == 0:
                n = root - 12 + (12 if (bass_style == 'drive' and i % 4 == 3) else 0)
                d = beat / 2 * 0.95
                sig = (saw(midi(n), d) * 0.6 + np.sin(2*np.pi*midi(n)*t_(d))) * adsr_exp(d, 7) * 0.5
                put(sig, t0 + i * beat / 2)
        # arpejo
        for i in range(16):
            if arp_pattern[i % len(arp_pattern)]:
                n = notes[(i * 3 + bar) % len(notes)] + 12 * ((i // 4) % 2)
                d = beat / 4 * 1.6
                sig = (np.sign(np.sin(2*np.pi*midi(n)*t_(d))) * 0.35 + np.sin(2*np.pi*midi(n)*t_(d))) * adsr_exp(d, 14)
                put(sig * arp_gain, t0 + i * beat / 4)
        # bateria
        for b in range(4):
            tb = t0 + b * beat
            if drums.get('kick', [1, 0, 1, 0])[b]:
                put(sweep(150, 45, 0.25) * adsr_exp(0.25, 12) * 0.9, tb)
            if drums.get('snare', [0, 1, 0, 1])[b]:
                put((noise(0.18) * adsr_exp(0.18, 24) * 0.5 + np.sin(2*np.pi*190*t_(0.18)) * adsr_exp(0.18, 30) * 0.4), tb)
            if drums.get('hat', True):
                for h in range(2):
                    put(noise(0.05) * adsr_exp(0.05, 70) * 0.18, tb + h * beat / 2)
    save(name, out, 0.8)

# Lá menor: Am - F - C - G
render_track(138, 8, [(57, [57, 60, 64]), (53, [53, 57, 60]), (48, [48, 52, 55]), (55, [55, 59, 62])],
             [1, 0, 1, 1, 0, 1, 1, 0], {'kick': [1, 0, 1, 0], 'snare': [0, 1, 0, 1], 'hat': True}, 'drive', 'music_fight')
# Ré menor, mais lenta e atmosférica
render_track(92, 8, [(50, [50, 53, 57]), (46, [46, 50, 53]), (53, [53, 57, 60]), (48, [48, 52, 55])],
             [1, 0, 0, 1, 0, 0, 1, 0], {'kick': [1, 0, 0, 0], 'snare': [0, 0, 1, 0], 'hat': False}, 'soft', 'music_menu',
             arp_gain=0.28, pad_gain=0.5)
print('áudio gerado em', os.path.abspath(OUT))
