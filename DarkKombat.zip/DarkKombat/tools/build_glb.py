#!/usr/bin/env python3
"""Dark Kombat - prepara os GLB dos lutadores para o jogo (só precisa de Python 3 + numpy).

Entrada : tools/source_models/*.glb  (69 peças soltas por personagem, sem esqueleto, ~15 mil triângulos)
Saída   : app/src/main/assets/game/models/<id>_lod0.glb  (qualidade média/alta)
          app/src/main/assets/game/models/<id>_lod1.glb  (qualidade baixa)

O que faz:
  1. Reduz os polígonos de cada peça (decimação por quádricas) segundo um orçamento por peça.
  2. Calcula normais com ângulo de vinco (esferas suaves, caixas/tampas com arestas vivas).
  3. Agrupa as peças em ossos (pélvis, tronco, cabeça, ombros, cotovelos, coxas, joelhos) e
     junta as peças de cada osso por material -> poucas chamadas de desenho.
  4. Converte para o eixo glTF (Y para cima, frente em +Z), pés no chão (y = 0).
  5. Escreve a hierarquia de nós com o pivô de cada articulação e o ângulo de repouso em `extras`.

Uso: python3 tools/build_glb.py
"""
import heapq
import json
import math
import os
import re
import struct
import sys

import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__))
ENTRADA = os.path.join(AQUI, 'source_models')
# LEGADO: os modelos ativos vêm de build_textured_glb.py. Este script escreve noutra pasta para não os sobrescrever.
SAIDA = os.path.join(AQUI, 'legacy_output')
PERSONAGENS = {'kira': 'KIRA_Cyber_Fighter.glb', 'ren': 'REN_Cyber_Fighter.glb'}

# ---------------------------------------------------------------------------------------------
# Orçamento de triângulos por peça: (padrão do nome sem prefixo L_/R_, LOD0, LOD1)
# ---------------------------------------------------------------------------------------------
ORCAMENTO = [
    (r'^face$', 320, 80),
    (r'^hair_cap$', 80, 20),
    (r'^jaw$', 20, 8),
    (r'^torso$', 180, 80),
    (r'^chest_armor$', 80, 20),
    (r'^pectoral$', 20, 8),
    (r'^chest_accent$', 20, 8),
    (r'^waist$', 80, 20),
    (r'^hip$', 80, 20),
    (r'^knee$', 80, 20),
    (r'^shin_plate$', 20, 8),
    (r'^toe$', 80, 20),
    (r'^shoulder$', 180, 80),
    (r'^shoulder_light$', 20, 8),
    (r'^elbow$', 80, 20),
    (r'^forearm_guard$', 80, 20),
    (r'^glove$', 180, 80),
    (r'^knuckle\d$', 20, 8),
    (r'^eye', 20, 8),
    (r'^ear_module', 20, 8),
    (r'(light|glow)', 16, 12),           # tiras luminosas finas (cilindros de 4 ou 3 lados)
    (r'^hair_lock', 24, 16),
    (r'^(thigh|shin|upperarm|forearm|neck)$', 32, 24),   # cilindros dos membros (8 ou 6 lados)
]
ESCALA_BRACO = 1.2                       # os braços do modelo são ~28 % mais curtos do que o alcance dos golpes do jogo
ALVO_PADRAO = (12, 12)                   # caixas (12 triângulos) ficam como estão

# ---------------------------------------------------------------------------------------------
# Ossos: pivô (coordenadas da origem: X lado, Y frente, Z cima) e peças de cada um
# ---------------------------------------------------------------------------------------------
def lado(p, s):
    return (p[0] * s, p[1], p[2])

PIVOS = {
    'pelvis': (0.0, 0.0, 1.12),
    'torso': (0.0, 0.0, 1.22),
    'head': (0.0, 0.0, 1.64),
}
for _n, _s in (('R', 1), ('L', -1)):
    PIVOS['shoulder_' + _n] = lado((0.34, 0.0, 1.58), _s)
    PIVOS['elbow_' + _n] = lado((0.48, 0.10, 1.38), _s)
    PIVOS['thigh_' + _n] = lado((0.19, 0.0, 1.12), _s)
    PIVOS['knee_' + _n] = lado((0.23, 0.02, 0.72), _s)

PAI = {
    'pelvis': 'root', 'torso': 'pelvis', 'head': 'torso',
    'shoulder_R': 'torso', 'elbow_R': 'shoulder_R', 'shoulder_L': 'torso', 'elbow_L': 'shoulder_L',
    'thigh_R': 'pelvis', 'knee_R': 'thigh_R', 'thigh_L': 'pelvis', 'knee_L': 'thigh_L',
}
ORDEM_OSSOS = ['pelvis', 'torso', 'head', 'shoulder_R', 'elbow_R', 'shoulder_L', 'elbow_L',
               'thigh_R', 'knee_R', 'thigh_L', 'knee_L']


def osso_da_peca(nome):
    m = re.match(r'^([LR])_(.*)$', nome)
    s, base = (m.group(1), m.group(2)) if m else (None, nome)
    if s:
        if base in ('shoulder', 'shoulder_light', 'upperarm'): return 'shoulder_' + s
        if base in ('elbow', 'forearm', 'forearm_guard', 'arm_light', 'glove') or base.startswith('knuckle'): return 'elbow_' + s
        if base in ('thigh', 'hip'): return 'thigh_' + s
        if base in ('knee', 'shin', 'shin_plate', 'shin_light', 'boot', 'toe'): return 'knee_' + s
        if base in ('pectoral', 'chest_glow', 'chest_accent'): return 'torso'
    if base in ('waist', 'belt_core') or base.startswith(('skirt_panel', 'panel_light')): return 'pelvis'
    if base in ('torso', 'chest_armor', 'backpack') or base.startswith('back_glow'): return 'torso'
    return 'head'   # neck, face, jaw, cabelo, olhos, orelhas, viseira


def sem_lado(nome):
    return re.sub(r'^[LR]_', '', nome)


def alvo_triangulos(nome, lod, n_atual):
    base = sem_lado(nome)
    for padrao, a, b in ORCAMENTO:
        if re.search(padrao, base):
            return min(n_atual, (a, b)[lod])
    return min(n_atual, ALVO_PADRAO[lod])


# ---------------------------------------------------------------------------------------------
# GLB de entrada
# ---------------------------------------------------------------------------------------------
def ler_glb(caminho):
    b = open(caminho, 'rb').read()
    clen = struct.unpack('<I', b[12:16])[0]
    j = json.loads(b[20:20 + clen])
    off = 20 + clen
    blen = struct.unpack('<I', b[off:off + 4])[0]
    dados = b[off + 8:off + 8 + blen]

    def acessor(i):
        a = j['accessors'][i]
        bv = j['bufferViews'][a['bufferView']]
        ct = {5126: np.float32, 5123: np.uint16, 5125: np.uint32}[a['componentType']]
        n = {'SCALAR': 1, 'VEC3': 3}[a['type']]
        o = bv.get('byteOffset', 0) + a.get('byteOffset', 0)
        arr = np.frombuffer(dados, dtype=ct, count=a['count'] * n, offset=o)
        return arr.reshape(-1, n) if n > 1 else arr

    pecas = []
    for nd in j['nodes']:
        if 'mesh' not in nd:
            continue
        p = j['meshes'][nd['mesh']]['primitives'][0]
        V = acessor(p['attributes']['POSITION']).astype(np.float64)
        F = acessor(p['indices']).astype(np.int64).reshape(-1, 3)
        if volume_assinado(V, F) < 0:      # enrolamento invertido -> corrige
            F = F[:, ::-1].copy()
        pecas.append({'nome': nd['name'], 'V': V, 'F': F, 'mat': p['material']})
    return j, pecas


def volume_assinado(V, F):
    return float(np.einsum('ij,ij->i', V[F[:, 0]], np.cross(V[F[:, 1]], V[F[:, 2]])).sum() / 6.0)


# ---------------------------------------------------------------------------------------------
# Elipsoides: as peças "redondas" do modelo são elipsoides exactos -> re-tesselam-se com esferas
# geodésicas regulares (mais limpas do que decimar) e normais analíticas.
# ---------------------------------------------------------------------------------------------
CONTAGENS_ESFERA = {8: 0, 20: 1, 80: 2, 180: 3, 320: 4, 500: 5}   # triângulos -> frequência (0 = octaedro)


def esfera_unitaria(tris):
    """Devolve (vértices unitários, faces) com `tris` triângulos (8 octaedro; 20n² geodésica)."""
    if tris not in CONTAGENS_ESFERA:
        raise ValueError('contagem de esfera inválida: %d' % tris)
    n = CONTAGENS_ESFERA[tris]
    if n == 0:
        V = np.array([[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]], float)
        F = [(0, 2, 4), (2, 1, 4), (1, 3, 4), (3, 0, 4), (2, 0, 5), (1, 2, 5), (3, 1, 5), (0, 3, 5)]
        return V, np.array(F)
    t = (1 + 5 ** 0.5) / 2
    B = np.array([[-1, t, 0], [1, t, 0], [-1, -t, 0], [1, -t, 0], [0, -1, t], [0, 1, t], [0, -1, -t], [0, 1, -t],
                  [t, 0, -1], [t, 0, 1], [-t, 0, -1], [-t, 0, 1]], float)
    B /= np.linalg.norm(B, axis=1)[:, None]
    BF = [(0, 11, 5), (0, 5, 1), (0, 1, 7), (0, 7, 10), (0, 10, 11), (1, 5, 9), (5, 11, 4), (11, 10, 2), (10, 7, 6), (7, 1, 8),
          (3, 9, 4), (3, 4, 2), (3, 2, 6), (3, 6, 8), (3, 8, 9), (4, 9, 5), (2, 4, 11), (6, 2, 10), (8, 6, 7), (9, 8, 1)]
    verts, chave, faces = [], {}, []

    def vid(p):
        k = tuple(np.round(p, 6))
        if k not in chave:
            chave[k] = len(verts); verts.append(p)
        return chave[k]

    for a, b, c in BF:
        A, Bv, C = B[a], B[b], B[c]
        def pt(i, j):
            q = A + (Bv - A) * (i / n) + (C - A) * (j / n)
            return vid(q / np.linalg.norm(q))
        for i in range(n):
            for j in range(n - i):
                faces.append((pt(i, j), pt(i + 1, j), pt(i, j + 1)))
                if i + j < n - 1:
                    faces.append((pt(i + 1, j), pt(i + 1, j + 1), pt(i, j + 1)))
    V = np.array(verts)
    F = np.array(faces)
    cen = V[F].mean(1)
    nrm = np.cross(V[F[:, 1]] - V[F[:, 0]], V[F[:, 2]] - V[F[:, 0]])
    inv = (nrm * cen).sum(1) < 0
    F[inv] = F[inv][:, ::-1]
    return V, F


def ajustar_elipsoide(V):
    """Se V for um elipsoide, devolve (centro, M) com V = c + M·u (|u| = 1); senão None."""
    c = V.mean(0)
    X = V - c
    w, U = np.linalg.eigh(3 * (X.T @ X) / len(V))
    M = U @ np.diag(np.sqrt(np.maximum(w, 1e-12))) @ U.T
    r = np.linalg.norm(X @ np.linalg.inv(M).T, axis=1)
    return (c, M) if r.std() < 2e-3 and abs(r.mean() - 1) < 2e-3 else None


def recriar_cilindro(V, F, lados):
    """Refaz um cilindro/tronco de cone (2 anéis de 12 + 2 centros) com `lados` lados, a partir dos anéis
    originais (respeita inclinação, conicidade e secção). Devolve (V, F) ou None se não for um cilindro."""
    val = np.zeros(len(V), int)
    for f in F:
        for v in f:
            val[v] += 1
    centros = [int(i) for i in np.where(val == 12)[0]]
    if len(centros) != 2:
        return None

    def anel(c):
        prox = {}
        for f in F:
            f = list(f)
            if c in f:
                k = f.index(c)
                prox[f[(k + 1) % 3]] = f[(k + 2) % 3]
        ordem, atual = [], next(iter(prox))
        for _ in range(len(prox)):
            ordem.append(atual); atual = prox[atual]
        return ordem if len(ordem) == 12 and atual == ordem[0] else None

    r0, r1 = anel(centros[0]), anel(centros[1])
    if r0 is None or r1 is None:
        return None
    c0, c1 = V[centros[0]], V[centros[1]]
    eixo = (c1 - c0) / np.linalg.norm(c1 - c0)

    def dirs(c, ordem):
        d = V[ordem] - c
        d -= np.outer(d @ eixo, eixo)
        return d / np.linalg.norm(d, axis=1)[:, None]

    d0, d1 = dirs(c0, r0), dirs(c1, r1)
    # alinha o anel 1 com o 0 (maior alinhamento angular), nos dois sentidos de percurso
    melhor = None
    for sentido in (1, -1):
        for desl in range(12):
            idx = [(desl + sentido * k) % 12 for k in range(12)]
            sc = float((d0 * d1[idx]).sum())
            if melhor is None or sc > melhor[0]:
                melhor = (sc, idx)
    r1 = [r1[i] for i in melhor[1]]

    def reamostrar(c, ordem):
        P = V[ordem]
        rad = np.linalg.norm(P - c, axis=1)
        out = []
        for k in range(lados):
            t = k * 12.0 / lados
            i = int(math.floor(t)) % 12; j = (i + 1) % 12; f = t - math.floor(t)
            q = P[i] * (1 - f) + P[j] * f
            d = q - c; d /= np.linalg.norm(d)
            out.append(c + d * (rad[i] * (1 - f) + rad[j] * f))
        return out

    A, B = reamostrar(c0, r0), reamostrar(c1, r1)
    NV = np.array(A + B + [c0, c1])
    ca, cb = 2 * lados, 2 * lados + 1
    F2 = []
    for k in range(lados):
        k2 = (k + 1) % lados
        F2 += [(ca, k, k2), (cb, lados + k2, lados + k),
               (k, lados + k, lados + k2), (k, lados + k2, k2)]
    F2 = np.array(F2)
    cen = NV.mean(0)
    nrm = np.cross(NV[F2[:, 1]] - NV[F2[:, 0]], NV[F2[:, 2]] - NV[F2[:, 0]])
    inv = (nrm * (NV[F2].mean(1) - cen)).sum(1) < 0
    F2[inv] = F2[inv][:, ::-1]
    return NV, F2


# ---------------------------------------------------------------------------------------------
# Decimação por quádricas (colapso de arestas) - malhas fechadas e pequenas
# ---------------------------------------------------------------------------------------------
def decimar(V, F, alvo):
    if len(F) <= alvo:
        return V.copy(), F.copy()
    V = np.array(V, float)
    F = [tuple(int(x) for x in f) for f in F]
    n = len(V)
    Q = np.zeros((n, 4, 4))
    for a, b, c in F:
        nr = np.cross(V[b] - V[a], V[c] - V[a])
        ar = np.linalg.norm(nr)
        if ar < 1e-14:
            continue
        nr /= ar
        p = np.append(nr, -nr @ V[a])
        K = np.outer(p, p) * ar * 0.5
        Q[a] += K; Q[b] += K; Q[c] += K
    viva = [True] * len(F)
    vf = [set() for _ in range(n)]
    for i, f in enumerate(F):
        for v in f:
            vf[v].add(i)
    vvivo = [True] * n
    ver = [0] * n

    def vizinhos(v):
        s = set()
        for fi in vf[v]:
            s.update(F[fi])
        s.discard(v)
        return s

    def custo(a, b):
        Qs = Q[a] + Q[b]
        A = Qs.copy(); A[3] = [0, 0, 0, 1]
        cand = [(V[a] + V[b]) / 2, V[a], V[b]]
        if abs(np.linalg.det(A)) > 1e-12:
            cand.insert(0, np.linalg.solve(A, [0, 0, 0, 1])[:3])
        melhor = None
        for p in cand:
            h = np.append(p, 1.0)
            c = float(h @ Qs @ h)
            if melhor is None or c < melhor[0]:
                melhor = (c, p)
        return melhor

    heap = []
    def empurrar(a, b):
        c, p = custo(a, b)
        heapq.heappush(heap, (c, a, b, ver[a], ver[b], tuple(p)))

    arestas = set()
    for a, b, c in F:
        for u, w in ((a, b), (b, c), (c, a)):
            arestas.add((min(u, w), max(u, w)))
    for a, b in arestas:
        empurrar(a, b)

    n_vivas = len(F)
    while n_vivas > alvo and heap:
        c, a, b, va, vb, p = heapq.heappop(heap)
        if not (vvivo[a] and vvivo[b]) or ver[a] != va or ver[b] != vb:
            continue
        p = np.array(p)
        partilhadas = [fi for fi in vf[a] if b in F[fi]]
        if not partilhadas:
            continue
        opostos = {w for fi in partilhadas for w in F[fi] if w not in (a, b)}
        if (vizinhos(a) & vizinhos(b)) != opostos:      # condição de ligação (topologia)
            continue
        invalido = False
        for fi in vf[a] ^ vf[b]:
            f = F[fi]
            antes = [V[x] for x in f]
            depois = [p if x in (a, b) else V[x] for x in f]
            n0 = np.cross(antes[1] - antes[0], antes[2] - antes[0])
            n1 = np.cross(depois[1] - depois[0], depois[2] - depois[0])
            l0, l1 = np.linalg.norm(n0), np.linalg.norm(n1)
            if l1 < 1e-12 or (l0 > 1e-12 and (n0 @ n1) / (l0 * l1) < 0.25):   # inverteria a face
                invalido = True
                break
        if invalido:
            continue
        # colapsa b em a
        for fi in list(vf[b]):
            if fi in partilhadas:
                viva[fi] = False
                for x in F[fi]:
                    vf[x].discard(fi)
                n_vivas -= 1
            else:
                F[fi] = tuple(a if x == b else x for x in F[fi])
                vf[a].add(fi)
        vf[b].clear()
        vvivo[b] = False
        V[a] = p
        Q[a] += Q[b]
        ver[a] += 1
        for w in vizinhos(a):
            empurrar(min(a, w), max(a, w))

    usados = sorted({v for i, f in enumerate(F) if viva[i] for v in f})
    mapa = {v: i for i, v in enumerate(usados)}
    novaF = np.array([[mapa[x] for x in F[i]] for i in range(len(F)) if viva[i] and len(set(F[i])) == 3], dtype=np.int64)
    return V[usados], novaF


# ---------------------------------------------------------------------------------------------
# Normais com ângulo de vinco (divide vértices nas arestas vivas)
# ---------------------------------------------------------------------------------------------
def normais_vinco(V, F, ang=50.0):
    p0, p1, p2 = V[F[:, 0]], V[F[:, 1]], V[F[:, 2]]
    nf = np.cross(p1 - p0, p2 - p0)           # comprimento = 2 x área (pesa por área)
    ln = np.linalg.norm(nf, axis=1)
    un = nf / np.maximum(ln, 1e-12)[:, None]
    lim = math.cos(math.radians(ang))
    vf = [[] for _ in range(len(V))]
    for i, f in enumerate(F):
        for v in f:
            vf[v].append(i)
    Vn, Nn, Fn = [], [], np.zeros_like(F)
    for i, f in enumerate(F):
        for k, v in enumerate(f):
            soma = np.zeros(3)
            for j in vf[v]:
                if un[i] @ un[j] >= lim:
                    soma += nf[j]
            L = np.linalg.norm(soma)
            Nn.append(soma / L if L > 1e-12 else un[i])
            Vn.append(V[v])
            Fn[i, k] = len(Vn) - 1
    # junta vértices iguais (mesma posição e normal) -> menos vértices na GPU e ficheiros mais pequenos
    Vn, Nn = np.array(Vn), np.array(Nn)
    chave = np.round(np.hstack([Vn, Nn * 0.5]), 4)
    _, primeiro, inverso = np.unique(chave, axis=0, return_index=True, return_inverse=True)
    inverso = inverso.reshape(-1)
    return Vn[primeiro], Nn[primeiro], inverso[Fn]


# ---------------------------------------------------------------------------------------------
# Escrita do GLB
# ---------------------------------------------------------------------------------------------
def alinhar(b, n=4):
    return b + b'\x00' * ((-len(b)) % n)


def escrever_glb(caminho, ossos, materiais, extras_raiz):
    """ossos: {nome: {'pos': (x,y,z) relativa ao pai, 'extras': {...}, 'prims': [(mat, V, N, F)]}}"""
    buf = bytearray()
    views, accs, meshes, nodes = [], [], [], []

    def add_view(dados, alvo=None):
        while len(buf) % 4: buf.append(0)
        v = {'buffer': 0, 'byteOffset': len(buf), 'byteLength': len(dados)}
        if alvo: v['target'] = alvo
        buf.extend(dados)
        views.append(v)
        return len(views) - 1

    def add_acc(view, ct, count, tipo, mn=None, mx=None):
        a = {'bufferView': view, 'componentType': ct, 'count': count, 'type': tipo}
        if mn is not None: a['min'], a['max'] = mn, mx
        accs.append(a)
        return len(accs) - 1

    nodes.append({'name': 'root', 'children': []})
    indice = {'root': 0}
    for nome in ORDEM_OSSOS:
        o = ossos[nome]
        nd = {'name': nome, 'translation': [round(float(x), 5) for x in o['pos']]}
        if o.get('extras'): nd['extras'] = o['extras']
        if o.get('scale'): nd['scale'] = [o['scale']] * 3
        prims = []
        for mat, V, N, F in o['prims']:
            V32, N32 = V.astype('<f4'), N.astype('<f4')
            vp = add_view(V32.tobytes(), 34962)
            vn = add_view(N32.tobytes(), 34962)
            vi = add_view(F.astype('<u2').reshape(-1).tobytes(), 34963)
            prims.append({'attributes': {
                'POSITION': add_acc(vp, 5126, len(V32), 'VEC3', V32.min(0).tolist(), V32.max(0).tolist()),
                'NORMAL': add_acc(vn, 5126, len(N32), 'VEC3')},
                'indices': add_acc(vi, 5123, F.size, 'SCALAR'), 'material': mat, 'mode': 4})
        if prims:
            meshes.append({'name': nome, 'primitives': prims})
            nd['mesh'] = len(meshes) - 1
        nodes.append(nd)
        indice[nome] = len(nodes) - 1
        pai = nodes[indice[PAI[nome]]]
        pai.setdefault('children', []).append(indice[nome])

    gltf = {'asset': {'version': '2.0', 'generator': 'Dark Kombat tools/build_glb.py'},
            'scene': 0, 'scenes': [{'nodes': [0]}], 'nodes': nodes, 'meshes': meshes,
            'materials': materiais, 'accessors': accs, 'bufferViews': views,
            'buffers': [{'byteLength': len(buf)}], 'extras': extras_raiz}
    js = alinhar(json.dumps(gltf, separators=(',', ':')).encode('utf8'), 4).replace(b'\x00', b' ')
    bn = alinhar(bytes(buf), 4)
    total = 12 + 8 + len(js) + 8 + len(bn)
    with open(caminho, 'wb') as f:
        f.write(struct.pack('<4sII', b'glTF', 2, total))
        f.write(struct.pack('<I4s', len(js), b'JSON')); f.write(js)
        f.write(struct.pack('<I4s', len(bn), b'BIN\x00')); f.write(bn)
    return total


# ---------------------------------------------------------------------------------------------
def para_gltf(P, chao):
    """origem (X lado direito, Y frente, Z cima) -> glTF (X lado esquerdo, Y cima, Z frente), pés em y=0."""
    P = np.atleast_2d(P)
    return np.stack([-P[:, 0], P[:, 2] - chao, P[:, 1]], axis=1)


def ang_deg(frente, cima):
    """ângulo (graus) medido a partir de 'para baixo', positivo para a frente."""
    return math.degrees(math.atan2(frente, -cima))


def construir(id_, ficheiro, lod):
    j, pecas = ler_glb(os.path.join(ENTRADA, ficheiro))
    chao = min(float(p['V'][:, 2].min()) for p in pecas)
    centros = {p['nome']: (p['V'].min(0) + p['V'].max(0)) / 2 for p in pecas}

    # pivôs na origem -> glTF
    pv = {n: para_gltf(np.array(c), chao)[0] for n, c in PIVOS.items()}
    ossos = {}
    for nome in ORDEM_OSSOS:
        pai = PAI[nome]
        rel = pv[nome] - (pv[pai] if pai != 'root' else np.zeros(3))
        ossos[nome] = {'pos': rel, 'prims': {}, 'extras': {}, 'scale': ESCALA_BRACO if nome.startswith('shoulder_') else None}

    # ângulos de repouso (pose do modelo) e posição da luva (para o brilho do punho)
    for s in ('R', 'L'):
        ombro, cot = np.array(PIVOS['shoulder_' + s]), np.array(PIVOS['elbow_' + s])
        luva = centros[s + '_glove']
        queda = ombro[2] - cot[2]
        ua = math.degrees(math.atan2(cot[1] - ombro[1], queda))
        abs_fa = ang_deg(luva[1] - cot[1], luva[2] - cot[2])
        ossos['shoulder_' + s]['extras'] = {'rest': round(ua, 3)}
        glow = para_gltf(luva, chao)[0] - pv['elbow_' + s]
        ossos['elbow_' + s]['extras'] = {'rest': round(abs_fa - ua, 3), 'glow': [round(float(x), 4) for x in glow]}
    for s in ('R', 'L'):
        ossos['thigh_' + s]['extras'] = {'rest': 0.0}
        ossos['knee_' + s]['extras'] = {'rest': 0.0}
    ossos['pelvis']['extras'] = {'rest': 0.0, 'legA': round(float(np.linalg.norm(pv['knee_R'] - pv['thigh_R'])), 4),
                                  'legB': round(float(pv['knee_R'][1]), 4)}
    ossos['torso']['extras'] = {'rest': 0.0}
    ossos['head']['extras'] = {'rest': 0.0}

    total = 0
    grupos = {}   # (osso, material) -> listas
    for p in pecas:
        alvo = alvo_triangulos(p['nome'], lod, len(p['F']))
        osso = osso_da_peca(p['nome'])
        elip = ajustar_elipsoide(p['V']) if len(p['V']) in (162, 642) else None
        if elip is not None:
            c, M = elip
            U, F = esfera_unitaria(alvo)
            V = c + U @ M.T                                   # vértices na origem (X lado, Y frente, Z cima)
            N = U @ np.linalg.inv(M)                          # normal do elipsoide: M^-T · u (M é simétrica)
            Ng = para_gltf(N, 0.0)                            # só roda (sem deslocar)
            Ng /= np.linalg.norm(Ng, axis=1)[:, None]
            Vn, Nn, Fn = para_gltf(V, chao) - pv[osso], Ng, F
        else:
            cil = recriar_cilindro(p['V'], p['F'], max(3, alvo // 4)) if len(p['V']) == 26 and alvo < len(p['F']) else None
            V, F = cil if cil is not None else decimar(p['V'], p['F'], alvo)
            Vn, Nn, Fn = normais_vinco(para_gltf(V, chao) - pv[osso], F)
        grupos.setdefault((osso, p['mat']), []).append((Vn, Nn, Fn))
        total += len(Fn)

    for (osso, mat), listas in grupos.items():
        off, Vs, Ns, Fs = 0, [], [], []
        for V, N, F in listas:
            Vs.append(V); Ns.append(N); Fs.append(F + off); off += len(V)
        V, N, F = np.vstack(Vs), np.vstack(Ns), np.vstack(Fs)
        if len(V) > 65535:
            raise RuntimeError('demasiados vértices num osso/material')
        ossos[osso]['prims'][mat] = (mat, V, N, F)
    for o in ossos.values():
        o['prims'] = [o['prims'][k] for k in sorted(o['prims'])]

    materiais = []
    for m in j['materials']:
        pbr = m['pbrMetallicRoughness']
        d = {'name': 'mat', 'pbrMetallicRoughness': {
            'baseColorFactor': [round(x, 4) for x in pbr['baseColorFactor']],
            'metallicFactor': pbr.get('metallicFactor', 0), 'roughnessFactor': pbr.get('roughnessFactor', 1)}}
        if 'emissiveFactor' in m:
            d['emissiveFactor'] = m['emissiveFactor']
        materiais.append(d)

    caminho = os.path.join(SAIDA, '%s_lod%d.glb' % (id_, lod))
    extras = {'id': id_, 'lod': lod, 'triangles': total, 'height': round(float(max(p['V'][:, 2].max() for p in pecas) - chao), 3),
              'source': ficheiro}
    tam = escrever_glb(caminho, ossos, materiais, extras)
    return caminho, total, tam


def main():
    os.makedirs(SAIDA, exist_ok=True)
    for id_, fich in PERSONAGENS.items():
        for lod in (0, 1):
            c, tris, tam = construir(id_, fich, lod)
            print('%-5s LOD%d  %5d triângulos  %6.1f KB  -> %s' % (id_, lod, tris, tam / 1024, os.path.relpath(c)))
    return 0


if __name__ == '__main__':
    sys.exit(main())
