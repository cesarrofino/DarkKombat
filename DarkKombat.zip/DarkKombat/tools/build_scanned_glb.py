#!/usr/bin/env python3
"""Dark Kombat - converte modelos 3D "scan" (malha estática de 100-200 mil triângulos, textura fragmentada, sem esqueleto)
em lutadores articulados leves (Liam, Saray). Só precisa de numpy + scipy + Pillow.

Entrada : tools/source_models/LIAM_scan.glb, SARAY_scan.glb  (1 m de altura, pés em y = -0.5, frente = +Z, guarda de boxe/karaté)
Saída   : app/src/main/assets/game/models/<id>_lod0.glb (textura 1024) e <id>_lod1.glb (textura 512), esqueleto de 22 ossos.

Passos:
  1. limpa fragmentos, centra nos quadris, põe os pés em y = 0, escala para a altura do personagem;
  2. reduz para ~2 500 triângulos (QEM, ignora UV porque a textura original está partida em milhares de ilhas);
  3. calcula os pesos do esqueleto (mesmo método do build_textured_glb.py);
  4. COZE uma textura nova: cada triângulo recebe a sua célula no atlas e a cor vem do ponto mais próximo da malha original;
  5. escreve o GLB (mesmo formato dos outros lutadores).
Uso:  python3 tools/build_scanned_glb.py [liam|saray]   (depois: node tests/run.js)"""
import os
import sys
import time

import numpy as np
from PIL import Image
from scipy.spatial import cKDTree

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import build_textured_glb as B
from decimate import decimar
import struct, json, io

ENTRADA, SAIDA = B.ENTRADA, B.SAIDA
ALVO = 2500            # triângulos finais
CONFIG = {
    'liam': {
        'src': 'LIAM_scan.glb', 'height': 1.98, 'arm_scale': 1.15,
        'J': {
            'waist': (0.00, 0.10, 0.00), 'neck': (0.01, 0.35, 0.00), 'head_top': (0.00, 0.50, -0.01),
            'hip_R': (-0.07, -0.03, 0.00), 'knee_R': (-0.15, -0.23, 0.01), 'ankle_R': (-0.22, -0.43, -0.03),
            'heel_R': (-0.22, -0.47, -0.10), 'toe_R': (-0.22, -0.48, 0.04),
            'hip_L': (0.07, -0.03, 0.00), 'knee_L': (0.15, -0.23, 0.01), 'ankle_L': (0.21, -0.43, -0.03),
            'heel_L': (0.21, -0.47, -0.10), 'toe_L': (0.21, -0.48, 0.04),
            'sh_R': (-0.14, 0.29, -0.02), 'el_R': (-0.19, 0.14, -0.06), 'wr_R': (-0.19, 0.12, 0.04), 'fist_R': (-0.19, 0.12, 0.09),
            'sh_L': (0.14, 0.29, -0.02), 'el_L': (0.19, 0.17, 0.02), 'wr_L': (0.08, 0.29, 0.06), 'fist_L': (0.06, 0.32, 0.09),
        },
        'R': {'pelvis': 0.17, 'torso': 0.17, 'head': 0.10, 'ua': 0.08, 'fa': 0.065, 'fist': 0.075, 'th': 0.12, 'sh': 0.09, 'ft': 0.07},
    },
    'saray': {
        'src': 'SARAY_scan.glb', 'height': 1.82, 'arm_scale': 1.15,
        'J': {
            'waist': (0.01, 0.10, -0.02), 'neck': (0.02, 0.33, 0.02), 'head_top': (0.02, 0.50, -0.01),
            'hip_R': (-0.06, -0.03, -0.04), 'knee_R': (-0.10, -0.22, -0.09), 'ankle_R': (-0.14, -0.43, -0.13),
            'heel_R': (-0.15, -0.47, -0.18), 'toe_R': (-0.14, -0.485, -0.04),
            'hip_L': (0.06, -0.03, 0.04), 'knee_L': (0.10, -0.21, 0.11), 'ankle_L': (0.14, -0.43, 0.12),
            'heel_L': (0.14, -0.47, 0.08), 'toe_L': (0.14, -0.485, 0.20),
            'sh_R': (-0.11, 0.28, -0.03), 'el_R': (-0.15, 0.13, 0.00), 'wr_R': (-0.14, 0.23, 0.08), 'fist_R': (-0.13, 0.27, 0.11),
            'sh_L': (0.11, 0.28, 0.00), 'el_L': (0.15, 0.14, 0.07), 'wr_L': (0.12, 0.26, 0.15), 'fist_L': (0.12, 0.28, 0.20),
        },
        'R': {'pelvis': 0.14, 'torso': 0.12, 'head': 0.10, 'ua': 0.06, 'fa': 0.05, 'fist': 0.06, 'th': 0.10, 'sh': 0.075, 'ft': 0.06},
    },
}


def ler_scan(path):
    d = open(path, 'rb').read(); n = struct.unpack('<I', d[12:16])[0]; j = json.loads(d[20:20 + n]); off = 20 + n + 8

    def acc(i):
        a = j['accessors'][i]; bv = j['bufferViews'][a['bufferView']]; o = off + bv.get('byteOffset', 0) + a.get('byteOffset', 0)
        dt = {5126: '<f4', 5123: '<u2', 5125: '<u4'}[a['componentType']]; k = {'VEC3': 3, 'VEC2': 2, 'SCALAR': 1}[a['type']]
        return np.frombuffer(d, dt, a['count'] * k, o).reshape(-1, k)
    pr = j['meshes'][0]['primitives'][0]
    tx = j['textures'][j['materials'][pr['material']]['pbrMetallicRoughness']['baseColorTexture']['index']]
    src = tx.get('source', tx.get('extensions', {}).get('EXT_texture_webp', {}).get('source'))
    bv = j['bufferViews'][j['images'][src]['bufferView']]; o = off + bv.get('byteOffset', 0)
    tex = Image.open(io.BytesIO(d[o:o + bv['byteLength']])).convert('RGB')
    return acc(pr['attributes']['POSITION']).astype(np.float64), acc(pr['attributes']['TEXCOORD_0']).astype(np.float64), acc(pr['indices']).reshape(-1, 3).astype(np.int64), tex


def preparar(cfg):
    P, UV, I, tex = ler_scan(os.path.join(ENTRADA, cfg['src']))
    W = B.soldar(P); comp = B.componentes(W, I)
    ids, cont = np.unique(comp, return_counts=True); I = I[comp == ids[np.argmax(cont)]]
    J = {k: np.array(v, dtype=np.float64) for k, v in cfg['J'].items()}
    chao = P[:, 1].min(); hips = (J['hip_R'] + J['hip_L']) / 2
    c = np.array([hips[0], chao, hips[2]]); s = cfg['height'] / (P[:, 1].max() - chao)
    return (P - c) * s, UV, I, tex, {k: (v - c) * s for k, v in J.items()}


def remalhar(P, I, vox=0.011, fecho=2):
    """superfície limpa a partir da nuvem de pontos: voxeliza -> fecha buracos -> suaviza -> marching cubes (malha estanque e 2-variedade)"""
    from scipy import ndimage as ndi
    from skimage import measure
    rng = np.random.default_rng(1)
    A, Bv, C = P[I[:, 0]], P[I[:, 1]], P[I[:, 2]]
    pts = [P]
    for _ in range(3):
        u = rng.random((len(I), 2)); m = u.sum(1) > 1; u[m] = 1 - u[m]
        pts.append(A + u[:, :1] * (Bv - A) + u[:, 1:] * (C - A))
    pts = np.concatenate(pts)
    lo = pts.min(0) - vox * 6; n = np.ceil((pts.max(0) + vox * 6 - lo) / vox).astype(int)
    g = np.zeros(n, dtype=bool); q = ((pts - lo) / vox).astype(int); g[q[:, 0], q[:, 1], q[:, 2]] = True
    g = ndi.binary_closing(g, iterations=fecho, border_value=0)
    g = ndi.binary_fill_holes(g)
    lab, k = ndi.label(g)
    if k > 1: g = lab == (np.argmax(np.bincount(lab.ravel())[1:]) + 1)
    f = ndi.gaussian_filter(g.astype(np.float32), 1.0)
    V, F, _, _ = measure.marching_cubes(f, 0.5)
    V = V * vox + lo
    return V, F.astype(np.int64)


def amostrar(tex, uv):
    """cor bilinear da textura (UV com origem no topo, como no glTF)"""
    t = np.asarray(tex, dtype=np.float32); h, w = t.shape[:2]
    x = (uv[:, 0] % 1.0) * (w - 1); y = (uv[:, 1] % 1.0) * (h - 1)
    x0 = np.floor(x).astype(int); y0 = np.floor(y).astype(int); x1 = np.minimum(x0 + 1, w - 1); y1 = np.minimum(y0 + 1, h - 1)
    fx = (x - x0)[:, None]; fy = (y - y0)[:, None]
    return (t[y0, x0] * (1 - fx) * (1 - fy) + t[y0, x1] * fx * (1 - fy) + t[y1, x0] * (1 - fx) * fy + t[y1, x1] * fx * fy)


def cozer(Pn, In, Ps, UVs, tex, lado=1024, k=6):
    """textura nova: 2 triângulos por célula do atlas; cor = média das k amostras mais próximas da malha original"""
    n = len(In); g = int(np.ceil(np.sqrt(np.ceil(n / 2)))); cel = lado / g
    cor_v = amostrar(tex, UVs)
    arv = cKDTree(Ps)
    img = np.zeros((lado, lado, 3), dtype=np.float32)
    # texel -> célula, coordenadas locais (u, v) em [0,1] (com 1 px de margem)
    ys, xs = np.mgrid[0:lado, 0:lado]
    cx = np.minimum((xs / cel).astype(int), g - 1); cy = np.minimum((ys / cel).astype(int), g - 1)
    u = np.clip((xs + 0.5 - cx * cel - 1.0) / (cel - 2.0), -0.15, 1.15); v = np.clip((ys + 0.5 - cy * cel - 1.0) / (cel - 2.0), -0.15, 1.15)
    cell = cy * g + cx; low = (u + v) <= 1.0
    tri = cell * 2 + (~low).astype(int)
    valid = tri < n; tri = np.where(valid, tri, 0)
    wb = np.where(low, u, 1 - u); wc = np.where(low, v, 1 - v); wa = 1 - wb - wc
    w3 = np.stack([wa, wb, wc], -1); w3 = np.clip(w3, 0, None); w3 /= w3.sum(-1, keepdims=True)   # fora do triângulo: projecta para a aresta
    A = Pn[In[tri, 0]]; Bv = Pn[In[tri, 1]]; Cv = Pn[In[tri, 2]]
    X = w3[..., 0:1] * A + w3[..., 1:2] * Bv + w3[..., 2:3] * Cv
    flat = X.reshape(-1, 3)
    d, ii = arv.query(flat, k=k)
    wgt = 1.0 / (d + 2e-3); wgt /= wgt.sum(1, keepdims=True)
    img = (cor_v[ii] * wgt[..., None]).sum(1).reshape(lado, lado, 3)
    img[~valid] = 40
    # UV por canto (origem no topo): triângulo "baixo" = (0,0),(1,0),(0,1); "alto" = (1,1),(0,1),(1,0)
    cel_i = np.arange(n) // 2; alto = (np.arange(n) % 2).astype(bool)
    ox = (cel_i % g) * cel + 1.0; oy = (cel_i // g) * cel + 1.0; sp = cel - 2.0
    cu = np.where(alto[:, None], np.array([[1, 0, 1]]), np.array([[0, 1, 0]])); cv = np.where(alto[:, None], np.array([[1, 1, 0]]), np.array([[0, 0, 1]]))
    UV = np.stack([(ox[:, None] + cu * sp) / lado, (oy[:, None] + cv * sp) / lado], -1).reshape(-1, 2)
    return Image.fromarray(np.clip(img, 0, 255).astype(np.uint8)), UV


def construir(nome):
    cfg = CONFIG[nome]; t0 = time.time()
    Ps, UVs, Is, tex, J = preparar(cfg)
    cache = os.path.join(AQUI, '_cache_%s.npz' % nome)
    if os.path.exists(cache):
        z = np.load(cache); P, I = z['P'], z['I']
    else:
        P, I = remalhar(Ps, Is); print('     remalhada: %d triângulos (%.0fs)' % (len(I), time.time() - t0), flush=True)
        for mn in (0.35, 0.3, 0.2, 0.1, 0.0):   # várias passagens: cada uma refaz a vizinhança e destrava arestas bloqueadas
            if len(I) <= ALVO * 1.03: break
            P, _, I = decimar(P, np.zeros((len(P), 2)), I, max(ALVO / len(I), 0.25), mn)
            print('     passagem: %d triângulos (%.0fs)' % (len(I), time.time() - t0), flush=True)
        np.savez(cache, P=P, I=I)
    print('   %s: %d -> %d triângulos (%.0fs)' % (nome, len(Is), len(I), time.time() - t0))
    pos, rest, comp = B.esqueleto(J)
    idx_v, w_v = B.pesos(P, I, J, cfg['R'])
    # vértices soltos por triângulo (cada um com a sua UV de atlas)
    img0, UV = cozer(P, I, Ps, UVs, tex, 1024)
    Pc = P[I].reshape(-1, 3); idc = idx_v[I].reshape(-1, 4); wc = w_v[I].reshape(-1, 4); Ic = np.arange(len(Pc)).reshape(-1, 3)
    rest_y = float(pos['pelvis'][1]); res = []
    for lod, lado in (('lod0', 1024), ('lod1', 512)):
        out = os.path.join(SAIDA, '%s_%s.glb' % (nome, lod))
        tris, tam = B.escrever(out, Pc, UV, Ic, idc, wc, pos, rest, comp, rest_y, cfg, B.jpeg(img0, lado), J, nome)
        res.append('%s: %d triângulos, %.0f KB' % (os.path.basename(out), tris, tam / 1024))
    img0.save(os.path.join(AQUI, '_tex_%s.png' % nome))
    return dict(P=P, I=I, J=J, pos=pos, rest=rest, comp=comp, idx=idx_v, w=w_v, rest_y=rest_y, cfg=cfg, log=res)


AQUI = B.AQUI
if __name__ == '__main__':
    for n in (sys.argv[1:] or list(CONFIG)):
        r = construir(n)
        print(n, '| repouso (graus):', {k: round(v, 1) for k, v in r['rest'].items()}); print('   ', '; '.join(r['log']))
