# Licenças
- **Código do jogo e Kotlin:** original deste projecto.
- **Áudio (`assets/game/audio/*.wav`):** sintetizado por `tools/gen_audio.py`; sem amostras de terceiros; livre de utilização (CC0).
- **Three.js r149:** MIT (descarregado na compilação).
- **AndroidX / WebKit:** Apache 2.0.
- Os retratos e cenário são desenhados por código; a imagem de referência fornecida foi usada apenas como orientação de estilo (nenhum recurso dela foi incluído).
