# Manual de instalação

## Requisitos
Android 7.0 (API 24) ou superior, ecrã táctil, OpenGL ES 2.0. Para o modo Bluetooth: Bluetooth Classic nos dois telemóveis.

## Instalar o APK
1. Obtém o `app-debug.apk` (ver README → Compilar no GitHub).
2. Copia-o para o telemóvel (cabo, Drive, Bluetooth…).
3. Abre o ficheiro e autoriza "Instalar apps desconhecidas" para a app que o abriu.
4. Abre **Dark Kombat**. O jogo é apresentado em ecrã inteiro e horizontal.

O APK de depuração é assinado com a chave de depuração do Android e instala normalmente. Para publicar na Play Store é preciso um APK/AAB *release* assinado com a tua chave (fora do âmbito desta entrega).

## Permissões
- Android 12+: *Dispositivos próximos* (Bluetooth: procurar, ligar, ficar visível). Só são pedidas ao usar o modo Bluetooth.
- Android 11 ou anterior: *Localização* (exigência do Android para procurar dispositivos Bluetooth; a localização não é usada nem enviada). Liga também a localização do telemóvel.
- Vibração (opcional, desactivável nas definições).
O modo a solo não pede nenhuma permissão.
