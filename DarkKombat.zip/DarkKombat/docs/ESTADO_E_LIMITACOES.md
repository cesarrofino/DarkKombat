# Estado, testes e limitações (sem rodeios)

## O que foi executado (ambiente de desenvolvimento, Node 22)
`node tests/run.js` → **24/24 testes passam**:
- 21 testes automáticos da lógica: protocolo (válidas/inválidas/demasiado grandes), movimentação, limites da arena, não atravessar, alcance, dano único por golpe, recuperação, defesa, especial/energia, combos, KO, fim por tempo, empate, fim de partida, 3 IAs a jogar partidas completas (sem valores inválidos nem atravessar), sincronização (Mirror).
- 3 testes de fumo com DOM/THREE **simulados**: modelo 3D (procedural e GLB reais: orçamento de triângulos, todas as poses, cinemática de jab/direto/pontapés/queda/vitória, libertação de recursos), app inteira (arranque, menus, definições, 40 s de combate, pausa, saída), fluxo Bluetooth anfitrião/cliente **com uma ponte simulada** (lobby, START, INPUT/STATE, mensagens inválidas, desconexão).

## O que NÃO foi feito/testado
- **Compilação Android / APK:** o ambiente não tinha Android SDK nem Gradle nem rede. O Kotlin e o Gradle foram escritos com cuidado mas **nunca compilados**; pode haver erros de compilação a corrigir (o workflow do GitHub mostra-os nos logs). Nenhum APK foi gerado.
- **Gráficos reais (WebGL), desempenho (30/60 FPS) e memória:** nunca medidos num telemóvel. Os valores são objectivos, não garantias. A qualidade AUTO ajusta-se pelo FPS medido.
- **Bluetooth real:** implementado em Kotlin (RFCOMM, descoberta, sockets, threads), mas **não testado em dispositivos**. Segue `docs/MANUAL_TESTES_BLUETOOTH.md`.
- **Áudio:** ficheiros gerados e validados como WAV, mas não ouvidos por mim; ajusta à tua vontade.
- Personagens: GLB texturados com skinning (ver `docs/MODELOS.md`). Verificados só em Node com THREE falso (poses, ossos, triângulos); o desenho real em WebGL e o desempenho no telemóvel nunca foram medidos. O aspeto é estilizado, não realista.
- Sem previsão no cliente Bluetooth: a latência sente-se. Se a app for para segundo plano durante uma partida Bluetooth, o adversário vê a ligação perder-se.
- A app não tem pausa em Bluetooth, e o APK é de depuração (não assinado para a Play Store).
