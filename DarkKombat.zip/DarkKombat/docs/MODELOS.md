# Modelos 3D dos lutadores (GLB texturados com skinning)

**Atual:** KIRA e REN são as malhas texturadas (`tools/source_models/KIRA_textured.glb`, `REN_textured.glb`), convertidas por
`python3 tools/build_textured_glb.py` (Python 3 + numpy + Pillow) para `app/src/main/assets/game/models/`:

| Ficheiro | Triângulos | Textura | Quando é usado |
|---|---|---|---|
| `kira_lod0.glb`, `ren_lod0.glb` | 5 226 / 6 638 | JPEG 1024² | qualidade média/alta |
| `kira_lod1.glb`, `ren_lod1.glb` | 5 226 / 6 638 | JPEG 512² | qualidade BAIXA |

- **Uma só malha por lutador** (1 chamada de desenho) com *skinning* suave nos mesmos 11 ossos de antes
  (`pelvis, torso, head, shoulder_R/L, elbow_R/L, thigh_R/L, knee_R/L`). Os pesos vêm de cápsulas por osso + difusão pela malha.
- As juntas de cada personagem estão na tabela `CONFIG` do script (medidas na malha); se mudares o modelo, ajusta-as.
- O REN é **espelhado** (a perna da frente passa a ser a esquerda, como o motor assume). Fragmentos soltos junto aos pés foram removidos.
- Os ângulos de repouso (braços e pernas), o comprimento das pernas e a escala dos braços (`runScale`, para igualar o alcance dos golpes)
  ficam em `extras` de cada nó; `js/model.js` usa-os para converter as poses do motor em rotações dos ossos e assentar os pés no chão.
- `js/models.js` lê UV, JOINTS_0/WEIGHTS_0, `skins` e a textura embutida (sem GLTFLoader, 100 % offline) e cria `THREE.SkinnedMesh`.
  Se os GLB falharem, o jogo usa o modelo procedural (nunca fica sem lutadores).

## Trocar ou editar personagens
1. Coloca o novo GLB (malha única + textura, frente em +Z) em `tools/source_models/` e regista-o em `CONFIG` com as juntas.
2. `python3 tools/build_textured_glb.py` e `node tests/run.js`.

## Limites (sem rodeios)
- Verificado só em Node (THREE falso) e com renders próprios das poses em Python. **O aspeto real em WebGL (luz, brilho da textura,
  `emissive` dos néons) e o desempenho no telemóvel nunca foram medidos**: ajusta `metalness/roughness/emissive` em `models.js` se ficar escuro.
- Skinning linear: em dobras extremas (chute alto, queda) há ligeiro "colapso" na articulação. O braço da guarda do modelo é mais curto
  e é aumentado até 30 % no jogo.

## Modelos anteriores (legado)
Os GLB de 69 peças rígidas (`*_Cyber_Fighter.glb`) e o `tools/build_glb.py` foram mantidos, mas o script agora escreve em `tools/legacy_output/`.
