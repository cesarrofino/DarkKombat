# Manual de testes Bluetooth (2 telemóveis reais)

> Estes testes **ainda não foram realizados** pelo autor desta entrega (não havia dispositivos). Fazem parte do que precisas de validar.

Preparação: instala o mesmo APK nos dois telemóveis (A e B). Bluetooth ligado. Android ≤ 11: localização ligada. Fecha outras apps Bluetooth.

| # | Passo | Resultado esperado |
|---|-------|--------------------|
| 1 | A: MULTIJOGADOR → CRIAR PARTIDA; aceitar permissões e "tornar visível" | Estado "À espera do adversário…", mostra o nome do dispositivo |
| 2 | B: MULTIJOGADOR → PROCURAR PARTIDAS | A aparece na lista (sem emparelhamento prévio) |
| 3 | B: tocar em A | "A ligar…" e depois lobby nos dois, com o nome do outro |
| 4 | Ambos escolhem lutador; B carrega PRONTO | A: botão INICIAR PARTIDA fica activo |
| 5 | A: INICIAR PARTIDA | Contagem e combate nos dois; B vê-se à esquerda |
| 6 | Mover e atacar nos dois | Movimento/golpes aparecem no outro (pequeno atraso) |
| 7 | Defender um golpe | "🛡" e redução de dano nos dois ecrãs |
| 8 | Comparar barras de vida | Iguais nos dois (o anfitrião é a autoridade) |
| 9 | Jogar até ao fim | Resultado igual nos dois; A: JOGAR NOVAMENTE |
| 10 | Durante o combate desligar o Bluetooth de um | O outro mostra "LIGAÇÃO PERDIDA" em ≤ 6 s; VOLTAR AO MENU funciona; TENTAR RELIGAR |
| 11 | Afastar muito os telemóveis | Ligação perdida tratada sem fechar a app |
| 12 | Modo a solo com Bluetooth desligado | Funciona normalmente |

Anota: modelo/versão Android, passo que falhou, mensagem mostrada.
