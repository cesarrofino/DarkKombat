# Manual de utilização

## Menu
JOGAR SOZINHO · MULTIJOGADOR BLUETOOTH · LUTADORES · DEFINIÇÕES · SAIR. (O botão Voltar do Android também funciona em todos os ecrãs.)

## Lutadores
- **KIRA** — ágil: ataques rápidos, boa esquiva (recuperação da esquiva curta), vida 100.
- **REN** — forte: golpes poderosos, defesa resistente, vida 120.

## Controlos (ecrã horizontal, multi-toque)
- **Joystick (esquerda):** esquerda/direita para andar, aproximar-se e recuar.
- **SOCO** · **CHUTE** · **DEFESA** (segura) · **ESPECIAL** (gasta 50 de energia; azul-claro quando disponível).
- **Esquiva:** carrega em DEFESA enquanto empurras o joystick para longe do adversário (breve invulnerabilidade).
- **Combos** (carrega no golpe seguinte logo depois de acertar): Soco+Soco, Soco+Chute, Chute+Chute (2.º chute é alto), Soco+Soco+Especial (especial por 30 de energia e +50 % de dano).
- Teclado (testes em PC): A/D, J soco, K chute, U especial, L ou Espaço defesa.

## Regras
Melhor de 3 rondas (2 vitórias). 60 s por ronda. Ronda ganha por vida a zero ou, no fim do tempo, por mais vida (em percentagem). Empate dá ponto a ambos. A IA joga com as mesmas regras (tempos de recuperação, alcance, colisões).

## Definições
Qualidade gráfica (AUTO/BAIXO/MÉDIO/ALTO), volume da música e dos efeitos, vibração, sensibilidade do joystick, tamanho dos controlos, reduzir efeitos visuais, nome para o Bluetooth. Guardadas no telemóvel.

## Pausa
Botão **II** (a solo). Sair pede confirmação. Se a app for para segundo plano a solo, o jogo pausa sozinho. No modo Bluetooth não há pausa (a partida é partilhada).
