# Protocolo Bluetooth

Transporte: RFCOMM (Bluetooth Classic), UUID `8f1c2a56-5d3e-4b7a-9c21-6d1a0b7e44f3`, sockets *insecure* (não exige emparelhamento; os dados do jogo não são sensíveis).
Mensagens: uma linha JSON terminada em `\n`, máx. 2048 caracteres. Todas têm `t` (tipo) e `q` (nº de sequência crescente por emissor). Validação no Kotlin (tipo conhecido, tamanho) **e** no JavaScript (campos e intervalos). Mensagens inválidas são descartadas; `INPUT`/`STATE` com `q` antigo são ignoradas.

| Tipo | Sentido | Campos |
|------|---------|--------|
| HELLO | ambos | `name` (≤24, ASCII), `v` (versão) |
| READY | cliente→anfitrião | `f` lutador (`kira`/`ren`), `r` 0/1 |
| START | anfitrião→cliente | `hf` lutador do anfitrião, `cf` lutador do cliente |
| INPUT | cliente→anfitrião | `mx` -1/0/1 (eixo do mundo), `a` bits 1 soco 2 chute 4 especial (toques acumulados), `b` defesa 0/1 |
| STATE | anfitrião→cliente (20 Hz) | `ph` fase 0-3, `cd` contagem, `tm` tempo, `r` ronda, `w` [vitórias], `f` [[x,hp,en,estado,tempoEstado]×2] |
| HIT | anfitrião→cliente | `v` vítima, `d` dano, `b` bloqueado, `k` tipo de golpe, `c` combo |
| ROUND_END | anfitrião→cliente | `win` (-1 empate), `ko`, `w` |
| MATCH_END | anfitrião→cliente | `win`, `dur`, `st` estatísticas |
| PING | ambos (1 Hz) | `ts`, `r` 0 pedido / 1 resposta |
| DISCONNECT | ambos | — |

Autoridade: o anfitrião simula colisões, dano, vida, tempo, rondas e resultado. O cliente envia só entradas e aplica o `STATE` autoritativo (reconciliação: ajuste suave da posição, correcção imediata se o erro > 1,5 m). Não há previsão no cliente, por isso sente-se a latência da ligação (não prometemos latência zero). Sem mensagens em 6 s a ligação é dada como perdida.
